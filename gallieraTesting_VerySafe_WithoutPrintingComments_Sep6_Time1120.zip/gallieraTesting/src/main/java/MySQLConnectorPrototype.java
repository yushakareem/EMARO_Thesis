import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public interface MySQLConnectorPrototype {

    void startDBConnection(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void startDBConnectionOrCreateNew(String New_DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void getFromTableLatestBool(String Table_Name_In_DB);
    void getFromTableWithCustomQuery(String MySQLCustomQuery);
    Timestamp getItemTimeStamp();
    Boolean getItemValueBool();
    void setIntoTable(String Table_Name_InDB, String stringValue, Timestamp timeStamp);
    void stopDBConnection();
}
