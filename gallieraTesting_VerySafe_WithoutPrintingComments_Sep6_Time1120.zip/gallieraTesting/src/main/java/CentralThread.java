import it.emarolab.amor.owlDebugger.Logger;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 28/06/17.
 *
 * Thanks to: Prof. Fulvio Mastrogiovanni, Dr. Luca Buoncompagni
 *
 * What: Central thread for the system
 * Why: It has the main method, where the designer is able to create a connection between a MySQL-DB and network of ontologies, such that by communicating with
 *      eachother the system as a whole is context-aware and is able to detect 'tasks/activities' which the designer of the system is interested in.
 *
 * Legend:
 *          PO - Placing Ontology
 *          TO - Task Ontology
 *          Indiv - Individual in Ontology
 *          Onto - Ontology
 *          TS - TimeStamp
 *
 * Note:    Time_Now in temporal logic is a special individual, it holds the current time as timeStamp in the Ontology
 *
 * Upgrades in the future:
 *          #1
 *          hasDuration(inferenceOf(__,__),,) To hasDuration(inferenceOf(__,__,__),,)
 *          Where: the desired inference is compared with the real inference, if true then proceed else do not proceed.
 *
 *
 */
public class CentralThread {

    public static void main(String[] args) {
        System.out.println("Central thread begins");

        Logger.LoggerFlag.resetAllLoggingFlags();
//        System.out.println("Main thread begins, ID:" + Thread.currentThread().getId());
//
//        //***** Initialize PlacingOntology (PO)
//        PlacingOntology PO = new PlacingOntology();
//
//        //***** Initialize TaskOntologies (TOs)
//        TaskOntology1 TO1 = new TaskOntology1();    //Ontology infers: 'Person' "isStillIn" 'Room'
//        TaskOntology2 TO2 = new TaskOntology2();    //Ontology infers: 'Person' "isDoingActivity" 'WatchingTV'
//        //TaskOntology2 TO3 = new TaskOntology3();    //Ontology infers: 'Person' "isDoingActivity" 'Making_Breakfast/Lunch/Dinner'(LocationDependent)
//        //TaskOntology2 TO3 = new TaskOntology3();    //Ontology infers: 'Person' "isDoingActivity" 'Eating_Breakfast/Lunch/Dinner'(LocationInDependent)
//        //TaskOntology2 TO4 = new TaskOntology4();    //Ontology infers: 'Person' "isDoingActivity" 'Nap'//During Day
//        //TaskOntology2 TO5 = new TaskOntology5();    //Ontology infers: 'Person' "isDoingActivity" 'Sleeping'//During Night
//        //TaskOntology2 TO6 = new TaskOntology6();    //Ontology infers: 'Person' "isDoingActivity" 'DisturbedSleepInPrevious15Mins'
//        //TaskOntology2 TO7 = new TaskOntology7();    //Ontology infers: 'Person' "isDoingActivity" 'MorningBathRoomRoutine'//PerhapsBrushing&UsingToiletSeat
//        //TaskOntology2 TO8 = new TaskOntology8();    //Ontology infers: 'Person' "isDoingActivity" 'DidNotUseBathroomInPrev3Hours'
//        //TaskOntology2 TO9 = new TaskOntology9();    //Ontology infers: 'Person' "isDoingActivity" 'FrequencyOfVisitToBathRoomAtNight'
//        //TaskOntology2 TO10 = new TaskOntology10();    //Ontology infers: 'Person' "isDoingActivity" 'InRoomButNoMovementPrev3Hours'
//        //Sensors data Unavailable for these inferences
//        //TaskOntology2 TO11 = new TaskOntology11();    //Ontology infers: 'Person' "isDoingActivity" 'TookShowerDuringPrev30Mins'or'Showering'
//        //TaskOntology2 TO12 = new TaskOntology12();    //Ontology infers: 'Person' "isDoingActivity" 'Cooking'
//        //TaskOntology2 TO13 = new TaskOntology13();    //Ontology infers: 'Person' "isDoingActivity" 'WalkingTestDone'//CalculateAndSaveSpeedOfWalking
//
//        //***** Add the TOs as 'event-listeners' of 'event' happening in PO
//        PO.hasEventListener(TO1);
//        PO.hasEventListener(TO2);
//
//        //***** Periodically updating the PO with latest values from MySql DataBase
//        //***** Inside PO's run method:
//        //***** 1.UpdateOntology from MySQL DB
//        //***** 2.Reason with PO and activate TOs based on the context
//        Timer time = new Timer();
//        time.schedule(PO,0,10000);       //Period is in Millis (Only Method:startInputFromDBtoOnto in run())
//
//        //***** For TESTING: Periodically updating the PO by reading through the data base from the beginning to the end
//        //
//        //
//        //
//
//
//        //*****
//        //PO.inferThenInitiateTOs();
//
//        System.out.println("Main thread ends, ID:" + Thread.currentThread().getId());

//        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
//        scheduler.scheduleAtFixedRate(PO, 0, 10000, TimeUnit.MILLISECONDS);
        PlacingOntology PO = new PlacingOntology(
                "PO",
                "src/main/resources/PlacingOntology.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology",
                true
        );
        PO.setMySqlDBInputInfo("OpenHAB","openhab","nepo");

        PO.setInputLinkFromDBtoOnto("S_M_BathRoom","Item1");
        PO.setInputLinkFromDBtoOnto("S_M_Kitchen","Item2");
        PO.setInputLinkFromDBtoOnto("S_M_TableX","Item3");
        PO.setInputLinkFromDBtoOnto("S_M_Table","Item4");
        PO.setInputLinkFromDBtoOnto("S_M_LivingRoom","Item5");
        PO.setInputLinkFromDBtoOnto("S_M_KitchenCabinet","Item6");//We dont have this available in real experiments (Dated 23/24 March)
        PO.setInputLinkFromDBtoOnto("S_M_Bed","Item7");
        PO.setInputLinkFromDBtoOnto("S_B_TV","Item20");
        //NOTE: Memory brings temporal-logic into the picture. IOW(In Other Words) Temporal-logic requires memory. IOW Memory is Temporality On each update of PlacingOntology
        //Inferences of different objectProperties can be committed to memory
        PO.commitToActivateTemporalLogic("H_I_Habitant_1","isIn");//ACTIVATION CONDITION 'PO'
        TemporalLogic temporalObjPO = new TemporalLogic(
                "timeOntoPO",
                "src/main/resources/PlacingOntology.owl",
                "http://www.w3.org/2006/time",
                true
        );
        PO.setTemporalLogic(
                temporalObjPO.checkInTheDuration(temporalObjPO.inferenceOf("H_I_Habitant_1","isStillIn",null),"=",0, TimeUnit.MINUTES),
                temporalObjPO.isInTimeInterval(null,"Time_Now")
        );//Creates the relationship between temporal frames

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        TaskOntology TO1 = new TaskOntology(
                "TO1",
                "src/main/resources/TaskOntology1.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TaskOntology1",
                true
        );
        TO1.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_Kitchen");//ACTIVATION CONDITION 'TO'
        PO.hasEventListener(TO1);
        TO1.setInputLinkFromOntoToOnto("S_M_KitchenCabinet",PO);//Take all info of this indiv from PO and update in the TO1
        TemporalLogic temporalObjTO1 = new TemporalLogic(
                "timeOntoTO1",
                "src/main/resources/TaskOntology1.owl",
                "http://www.w3.org/2006/time",
                true
        );
        TO1.setTemporalLogic(
                temporalObjTO1.checkInTheDuration(temporalObjTO1.inferenceOf("H_I_Habitant_1","isUtilizing",null),"=",0, TimeUnit.MINUTES),
                temporalObjTO1.isInTimeInterval("Interval_IsIn_Kitchen","TI_IsIn_Kitchen_BeginTime","TI_IsIn_Kitchen_EndTime"),
                temporalObjTO1.isInABiggerTimeInterval("Interval_WholeDay")
        );
        TO1.setMySqlDBOutputInfo("GallieraActivityDB","root","nepo");
        TO1.setOutputLinkFromOntoToDB("H_I_Habitant_1","isDoingActivity");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        TaskOntology TO2 = new TaskOntology(
                "TO2",
                "src/main/resources/TaskOntology2.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TaskOntology2",
                true
        );
        TO2.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_LivingRoom");
        PO.hasEventListener(TO2);
        TO2.setInputLinkFromOntoToOnto("S_B_TV",PO);//Take all info of this indiv from PO and update in the TO2
        TO2.setInputLinkFromOntoToOnto("S_M_LivingRoom",PO);
        //TO2.setInputLinkFromOntoToOnto("S_E_AxisZ",PO);//Not integrated yet
        TemporalLogic temporalObjTO2 = new TemporalLogic(
                "timeOntoTO2",
                "src/main/resources/TaskOntology2.owl",
                "http://www.w3.org/2006/time",
                true
        );
        TO2.setTemporalLogic(
                temporalObjTO2.checkInTheDuration(temporalObjTO2.inferenceOf("H_I_Habitant_1","isUtilizing",null),"=",0, TimeUnit.MINUTES),
                temporalObjTO2.isInTimeInterval("Interval_IsIn_LivingRoom","TI_IsIn_LivingRoom_BeginTime","TI_IsIn_LivingRoom_EndTime"),
                temporalObjTO2.isInABiggerTimeInterval("Interval_WholeDay")
        );
        TO2.setMySqlDBOutputInfo("GallieraActivityDB","root","nepo");
        TO2.setOutputLinkFromOntoToDB("H_I_Habitant_1","isDoingActivity");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        TaskOntology TO3 = new TaskOntology(
                "TO3",
                "src/main/resources/TaskOntology3.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TaskOntology3",
                true
        );
        TO3.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_BedRoom");
        PO.hasEventListener(TO3);
        TO3.setInputLinkFromOntoToOnto("S_M_Bed",PO);//Take all info of this indiv from PO and update in the TO2
        //TO3.setInputLinkFromOntoToOnto("S_E_AxisZ",PO);//Not integrated yet
        TemporalLogic temporalObjTO3 = new TemporalLogic(
                "timeOntoTO3",
                "src/main/resources/TaskOntology3.owl",
                "http://www.w3.org/2006/time",
                true
        );
        TO3.setTemporalLogic(
                temporalObjTO3.checkInTheDuration(temporalObjTO3.inferenceOf("H_I_Habitant_1","isOccupying",null),"=",0, TimeUnit.MINUTES),
                temporalObjTO3.isInTimeInterval("Interval_IsIn_BedRoom","TI_IsIn_BedRoom_BeginTime","TI_IsIn_BedRoom_EndTime"),
                temporalObjTO3.isInABiggerTimeInterval("Interval_WholeDay")
        );
        TO3.setMySqlDBOutputInfo("GallieraActivityDB","root","nepo");
        TO3.setOutputLinkFromOntoToDB("H_I_Habitant_1","isDoingActivity");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        TaskOntology TO4 = new TaskOntology(
                "TO4",
                "src/main/resources/TaskOntology4.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TaskOntology4",
                true
        );
        TO4.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_BedRoom");
        PO.hasEventListener(TO4);
        TO4.setInputLinkFromOntoToOnto("S_M_Bed",PO);//Take all info of this indiv from PO and update in the TO4
        //TO4.setInputLinkFromOntoToOnto("S_E_AxisZ",PO);//Not integrated yet
        TemporalLogic temporalObjTO4 = new TemporalLogic(
                "timeOntoTO4",
                "src/main/resources/TaskOntology4.owl",
                "http://www.w3.org/2006/time",
                true
        );
        TO4.setTemporalLogic(
                temporalObjTO4.checkInTheDuration(temporalObjTO4.inferenceOf("H_I_Habitant_1","isOccupying",null),"=",0, TimeUnit.MINUTES),
                temporalObjTO4.isInTimeInterval("Interval_IsIn_BedRoom","TI_IsIn_BedRoom_BeginTime","TI_IsIn_BedRoom_EndTime"),
                temporalObjTO4.isInABiggerTimeInterval("Interval_WholeDay")
        );
        TO4.setMySqlDBOutputInfo("GallieraActivityDB","root","nepo");
        TO4.setOutputLinkFromOntoToDB("H_I_Habitant_1","isDoingActivity");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        TaskOntology TO5 = new TaskOntology(
                "TO5",
                "src/main/resources/TaskOntology5.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TaskOntology5",
                true
        );
        TO5.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_BathRoom");
        PO.hasEventListener(TO5);
        TO5.setInputLinkFromOntoToOnto("S_M_BathRoom",PO);//Take all info of this indiv from PO and update in the TO5
        //TO5.setInputLinkFromOntoToOnto("S_E_AxisZ",PO);//Not integrated yet
        TemporalLogic temporalObjTO5 = new TemporalLogic(
                "timeOntoTO5",
                "src/main/resources/TaskOntology5.owl",
                "http://www.w3.org/2006/time",
                true
        );
        TO5.setTemporalLogic(
                temporalObjTO5.checkInTheDuration(temporalObjTO5.inferenceOf("H_I_Habitant_1","isIn",null),">",1, TimeUnit.MINUTES),
                temporalObjTO5.isInTimeInterval("Interval_IsIn_BathRoom","TI_IsIn_BathRoom_BeginTime","TI_IsIn_BathRoom_EndTime"),
                temporalObjTO5.isInABiggerTimeInterval("Interval_WholeDay")
        );
        TO5.setMySqlDBOutputInfo("GallieraActivityDB","root","nepo");
        TO5.setOutputLinkFromOntoToDB("H_I_Habitant_1","isDoingActivity");

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        PO.startScheduledOntology(PO,0,7000, TimeUnit.MILLISECONDS,1);//Each iteration of the run 'does not' make a new object of PlacingOntology
        //PO.testing();
        System.out.println("Central Thread ends");
    }

}
