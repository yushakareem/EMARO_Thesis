public interface RecallFromMemory {

    String recallObjPropToActivateTemporalLogic();
    String recallIndivToActivateTemporalLogic();
}
