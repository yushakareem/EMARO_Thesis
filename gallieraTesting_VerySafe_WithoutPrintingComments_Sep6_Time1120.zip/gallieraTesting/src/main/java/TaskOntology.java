import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;

    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    boolean flagTimeIntervalIsInAnotherInterval;
    boolean flagUpdateTimeIntervalT1;
    List<TemporalLogic> temporalLogicObjectsList = new ArrayList<>();

    List<MORFullIndividual> removalListIndivA = new ArrayList<>();
    List<OWLObjectProperty> removalListObjProp = new ArrayList<>();
    List<OWLNamedIndividual> removalListIndivB = new ArrayList<>();

    //Critical breaking of swrl rule so that when temporal logic inference condition is not satisfied, we continoulsy do not get inference for old knowledge.
    MORFullIndividual toRemoveIndivA1;
    OWLObjectProperty toRemoveObjProp1;
    OWLNamedIndividual toRemoveIndivB1;

    MORFullIndividual toRemoveIndivA2;
    OWLObjectProperty toRemoveObjProp2;
    OWLNamedIndividual toRemoveIndivB2;

    boolean TLInferredIndivDetectedFlag = false;
    boolean durationLogicFlag = false;
    boolean durationLogicEqualToFlag = false;
    Integer TLPositiveTimeDuration;

    //INTERFACE:        CommitToMemory
    Timestamp timeStampForT1;
    //INTERFACE:        RecallFromMemory

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    String eventIndivA;
    String eventObjProp;
    String eventIndivB;

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    Map<String,OntologyPrototype> ontoToOntoInputMap = new HashMap<>();

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    String Activity_DataBase_Name;
    String Activity_Table_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String indivForOutputToDB;
    String objPropForOutputToDB;

    MySQLConnector mySqlObj = new MySQLConnector();

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Task Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public TaskOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # DEFINED AS # TaskOntology()");
    }

    //INTERFACE: OntologyPrototype                         <--/// Has the heart: run() //

    @Override
    public void updateBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {} // NOT USED

    @Override
    public void updateBasedOnCurrentSensoryState(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnCurrentSensoryState()");
        this.startInputFromOntoToOnto(ontoToOntoInputMap);
    }

    @Override
    public void setSensorIndivTimeStamp(String sensorIndividual, String timestamp) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        setIndividualWithTimestamp(localIndiv,timestamp);
    }

    @Override
    public void setIndividualWithTimestamp(MORFullIndividual individual, String timeStamp) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");

        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",timeStamp);
        individual.writeSemantic();

    }

    public void setIndividualWithObjProp(MORFullIndividual individualA, OWLObjectProperty objectProperty, OWLNamedIndividual individualB) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithObjProp()");

        individualA.readSemantic();
        individualA.addObject(objectProperty,individualB);
        individualA.writeSemantic();
    }

    @Override
    public void setSensorIndivBoolValue(String sensorIndividual, String dataPropName, boolean boolDataValue) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivBoolValue()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual, ontoRef);
        setIndividualWithDataPropBool(localIndiv,dataPropName,boolDataValue);

    }

    @Override
    public void setIndividualWithDataPropBool(MORFullIndividual individual, String dataPropName, boolean boolDataValue) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithDataPropBool()");

        individual.readSemantic();
        individual.removeData(dataPropName);
        individual.addData(dataPropName,boolDataValue,true);
        individual.writeSemantic();
    }

    public void setIndividualWithDataPropInt(MORFullIndividual individual, String dataProperty, int value){
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");

        individual.readSemantic();
        individual.removeData(dataProperty);
        individual.addData(dataProperty,value);
        individual.writeSemantic();
    }

    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    public MORFullIndividual getIndividual(OWLNamedIndividual individualName, OWLReferences ontoRef) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    @Override
    public String getIndividualTimestamp(MORFullIndividual individual) {
        return null;
    }

    @Override
    public boolean getSensorIndivBoolValue(String sensorIndividual, String dataPropName) {
        return false;
    }

    @Override
    public String getDataPropInference(MORFullIndividual individual, String dataPropName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty(dataPropName));
        return data.getLiteral();
    }

    public String getDataPropInference(MORFullIndividual individual, OWLDataProperty dataPropName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(dataPropName);
        return data.getLiteral();
    }

    @Override
    public String getSensorIndivTimeStamp(String sensorIndividual) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        return getDataPropInference(localIndiv, "hasTimeStamp");
    }

    @Override
    public String getObjPropInference(MORFullIndividual individual, String objectPropertyName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    public String getObjPropInference(MORFullIndividual individual, OWLObjectProperty objectPropertyName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    @Override
    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, String objectPropertyName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectPropertyName);
    }


    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, OWLObjectProperty objectProperty) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectProperty);
    }

    @Override
    public OWLReferences getOntoRef() {
        return ontoRef;
    }

    @Override
    public void synchronizeAndSaveOnto() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # synchronizeAndSaveOnto()");

        getOntoRef().synchronizeReasoner();
        getOntoRef().saveOntology(getOntoRef().getFilePath());
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+"\n\n # run()");
        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread begins.");

        this.resetKnowledgeCleanerForOnto(removalListIndivA,removalListObjProp,removalListIndivB);
        this.updateBasedOnCurrentSensoryState(ontoToOntoInputMap);
        this.updateBasedOnMemoryAndTemporalLogic(temporalLogicObjectsList);
        this.startOutputFromOntoToDB(recallIndivForInferAndOutputToDB(),recallObjPropForInferAndOutputToDB());
        this.getKnowledgeCleanerForOnto(removalListIndivA,removalListObjProp,removalListIndivB);

        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread ends\n\n");
    }

    // Not Problamatic
    private void resetKnowledgeCleanerForOnto(List<MORFullIndividual> removalListIndivA, List<OWLObjectProperty> removalListObjProp, List<OWLNamedIndividual> removalListIndivB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # resetKnowledgeCleanerForOnto()");

        removalListIndivA.clear();
        removalListObjProp.clear();
        removalListIndivB.clear();
    }

    // Not Problamatic
    private void getKnowledgeCleanerForOnto(List<MORFullIndividual> removalListIndivA, List<OWLObjectProperty> removalListObjProp, List<OWLNamedIndividual> removalListIndivB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getKnowledgeCleanerForOnto()");
        System.out.println("============= Removing Knowledge from "+this.getOntoRef().getReferenceName()+" ============");

        for (MORFullIndividual indivA:removalListIndivA) {
            System.out.println(indivA);
            for (OWLObjectProperty objProp:removalListObjProp) {
                for (OWLNamedIndividual indivB:removalListIndivB) {
                    //indivA.readSemantic(); (checked and is unnecessary to be used here, infact causes trouble, if used)
                    indivA.removeObject(objProp,indivB);
                    indivA.writeSemantic();
                }
            }
            System.out.println(indivA);
        }
        synchronizeAndSaveOnto();
    }

    private String recallObjPropForInferAndOutputToDB() {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallObjPropForInferAndOutputToDB()");

        return objPropForOutputToDB;
    }

    private String recallIndivForInferAndOutputToDB() {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallIndivForInferAndOutputToDB()");

        return indivForOutputToDB;
    }

    //INTERFACE:    OntoHasMemoryAndInputFromOnto
    public void startWithFreshMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithFreshMemory()");

        this.setFlagStartedWithFreshMemory(true);
        Thread thread = new Thread(this);
        thread.start();
    }

    public void startWithOldMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithOldMemory()");

        this.setFlagStartedWithFreshMemory(false);
        Thread thread = new Thread(this);
        thread.start();
    }

    //INTERFACE:        OntologyHasMemory
    @Override
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {
        System.out.println("# " + this.getOntoRef().getReferenceName() + " # startTimeMemoryLogic()");
        /*
            t prefix means time
         */

        //Breaker of old knowledge:
//        try {
//            System.out.println("============= Removing OLD Knowledge ============");
//            toRemoveIndivA1.readSemantic();
//            toRemoveIndivA1.removeObject(toRemoveObjProp1, toRemoveIndivB1);
//            toRemoveIndivA1.writeSemantic();
//            synchronizeAndSaveOnto();
//        } catch (NullPointerException a) {
//            System.out.println("no knowledge to be removed (Null pointer exception)");
//        }

        //Breaker of old knowledge:
//        try {
//            System.out.println("============= Removing OLD Knowledge ============");
//            toRemoveIndivA2.readSemantic();
//            toRemoveIndivA2.removeObject(toRemoveObjProp2, toRemoveIndivB2);
//            toRemoveIndivA2.writeSemantic();
//            synchronizeAndSaveOnto();
//        } catch (NullPointerException a) {
//            System.out.println("no knowledge to be removed (Null pointer exception)");
//        }

        Timestamp beginTimeOfTO;
        Timestamp latestTimeOfTO;

        //Individual and ObjectProperty given by user
        String temporalLogicIndiv = temporalObj.recallIndiv(); //Human
        String temporalLogicObjProp = temporalObj.recallObjProp(); //isUtilizing
        String temporalLogicDataProp = temporalObj.recallDataProp();

        //Definition: TimeStamps of the TimeIntervals (Saved to the Ontology)
        String T1Name = temporalObj.recallTimeIntervalT1Indiv();//TI_IsIn_Kitchen_BeginTime
        String T2Name = temporalObj.recallTimeIntervalT2Indiv();//TI_IsIn_Kitchen_EndTime

        //Setting the timeIntervals 'T1' and 'T2' based on startWithFreshMemory() OR startWithOldMemory()
        if (getFlagStartedWithFreshMemory()) {

            commitT1TS(new Timestamp(System.currentTimeMillis()));//Only gets updated for the first time of activation
            //System.out.println("--------> T1: " + T1Name + " FLAG update T1: " + getFlagStartedWithFreshMemory());
        }

        //setSensorIndivTimeStamp(T1Name, String.valueOf(recallT1TS()));  //BEGIN TIME: Gets updated only once; first time Human enters the particular room.
        beginTimeOfTO = recallT1TS();

        latestTimeOfTO = new Timestamp(System.currentTimeMillis());
        //setSensorIndivTimeStamp(T2Name, String.valueOf(latestTimeOfTO));//LATEST TIME: Gets updated as long as this Human is in the room continuously. Note, human is in the room continuously as long as he/she moves to another room.

        //Update TimeNow so that it is in the true now. (I dont use it anywhere, as of now having it for general purpose use later)
        //setIndividualWithTimestamp(getIndividual("Memory_OntoLastActive", ontoRef), String.valueOf(new Timestamp(System.currentTimeMillis())));
        //synchronizeAndSaveOnto();

        String temporalLogicInferredIndiv = null;

        if (Objects.equals(temporalLogicObjProp,null)) {
            temporalLogicInferredIndiv = getDataPropInference(getIndividual(temporalLogicIndiv,ontoRef),temporalLogicDataProp);//'NULL' OR THE PARTICULAR 'FURNITURE' example: A_F_KitchenCabinet
        } else if (Objects.equals(temporalLogicDataProp,null)){
            temporalLogicInferredIndiv = getObjPropInference(getIndividual(temporalLogicIndiv, ontoRef), temporalLogicObjProp);//'NULL' OR THE PARTICULAR 'FURNITURE' example: A_F_KitchenCabinet
        } else {
            System.out.println("Please only provide either object property or data property, not both at the same time");
        }
        ///////////////////////// checkIsInDuration(inference,comparativeOperator,positiveTimeDuration,minutes/hours) OVERALL STRUCTURE ///////////////////////////////////////////////////

        String temporalLogicComparativeOperator = temporalObj.recallComparativeOperator();
        TLPositiveTimeDuration = temporalObj.recallPositiveTimeDuration();
        TimeUnit TLunitOfTime = temporalObj.recallUnitOfTimeDuration();
        long timeDiff = 0;

        //Check for the kind of TimeUnit being used and accordingly get latestTimeDifference
        if (Objects.equals(TLunitOfTime, TimeUnit.MINUTES)) {

            long T2 = latestTimeOfTO.getTime();
            long T1 = beginTimeOfTO.getTime();
            long diff = (T2 - T1);
            timeDiff = diff / (60 * 1000) % 60;
            System.out.println("timeDifference: "+timeDiff+"  &  its Unit: "+TLunitOfTime);

        } else if (Objects.equals(TLunitOfTime, TimeUnit.HOURS)) {

            long T2 = latestTimeOfTO.getTime();
            long T1 = beginTimeOfTO.getTime();
            long diff = (T2 - T1);
            timeDiff = diff / (60 * 60 * 1000) % 24;
            System.out.println("timeDifference: "+timeDiff+"  &  its Unit: "+TLunitOfTime);

        } else {
            System.out.println("Time unit provided is not considered by the system");
        }

        //Check for the kind of operator being used
        if (Objects.equals(temporalLogicComparativeOperator, "<")) {
            //System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, 'within'/before '" + temporalLogicPositiveTimeDuration + "' '" + temporalLogicUnitOfTimeDuration + "' (always checking), it will cause activity recognition and save to DB");
            if (timeDiff<TLPositiveTimeDuration) {
                durationLogicFlag = true;
            }
        } else if (Objects.equals(temporalLogicComparativeOperator, "=") & !TLPositiveTimeDuration.equals(0)) {
            //System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, every '" + temporalLogicPositiveTimeDuration + "' '" + temporalLogicUnitOfTimeDuration + "' (there is a check), it will cause activity recognition and save to DB");
            if (timeDiff==TLPositiveTimeDuration) {
                durationLogicEqualToFlag = true;
                TLPositiveTimeDuration = TLPositiveTimeDuration+temporalObj.recallPositiveTimeDuration();
            }
        } else if (Objects.equals(temporalLogicComparativeOperator, "=") & TLPositiveTimeDuration.equals(0)) {
            //System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, always checking (ie, checking every 'instant' as duration is 'zero'), it will cause activity recognition and save to DB");
            durationLogicFlag = true;
        } else if (Objects.equals(temporalLogicComparativeOperator, ">")) {
            //System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, 'without'/after '" + temporalLogicPositiveTimeDuration + "' '" + temporalLogicUnitOfTimeDuration + "' (always checking), it will cause activity recognition and save to DB");
            if (timeDiff>TLPositiveTimeDuration) {
                durationLogicFlag = true;
            }
        } else {
            System.out.println("--> TemporalLogic: Comparative operator provided, is not part of the system defined set of operators! Please check!");
        }

        //System.out.println("==========1==========");
        //As long as the temporalLogicInferredIndiv is not null
        if (!Objects.equals(temporalLogicInferredIndiv, null)) {
            TLInferredIndivDetectedFlag = true;
            //System.out.println("==========2==========");
            if (durationLogicFlag) {
                //System.out.println("==========3==========");
                //System.out.println("--> Inference of '" + temporalLogicIndiv + "' '" + temporalLogicObjProp + "' is '" + temporalLogicInferredIndiv + "', proceeding towards setting temporal logic!");
                timeMemoryLogic(temporalObj, temporalLogicInferredIndiv, T1Name, T2Name, beginTimeOfTO, latestTimeOfTO);
                durationLogicFlag = false;
            }
        }
        if (Objects.equals(temporalLogicInferredIndiv, null) & TLInferredIndivDetectedFlag & durationLogicEqualToFlag) {
            //System.out.println("==========4==========");
            //System.out.println("--> Inference of '" + temporalLogicIndiv + "' '" + temporalLogicObjProp + "' is NULL, hence cannot place it in the defined interval T1,T2");
            timeMemoryLogic(temporalObj, temporalLogicInferredIndiv, T1Name, T2Name, beginTimeOfTO, latestTimeOfTO);
            TLInferredIndivDetectedFlag = false;
            durationLogicEqualToFlag = false;
        }

    }

    public void timeMemoryLogic(TemporalLogic temporalObj, String temporalLogicInferredIndiv, String T1Name, String T2Name, Timestamp T1TS, Timestamp T2TS) {
        //System.out.println("==========5==========");
        //Time Ontology object properties
        //OWLObjectProperty objPropBefore = temporalObj.getTimeOntoRef().getOWLObjectProperty("before");//timeInstant before timeInstant (Check swrl to understand why its not critical, to define it here)(For now, not defining in the java side because it is defined in the task ontology)
        //OWLObjectProperty objPropAfter = temporalObj.getTimeOntoRef().getOWLObjectProperty("after");//timeInstant after timeInstant (Check swrl to understand why its not critical, to define it here)
        OWLObjectProperty objPropIntervalContains = temporalObj.getTimeOntoRef().getOWLObjectProperty("intervalContains");//interval contains interval
        OWLObjectProperty objPropInside = temporalObj.getTimeOntoRef().getOWLObjectProperty("inside");//interval contains instant (Check swrl to understand why its not critical, to define it here)
        OWLObjectProperty objPropHasBeginning = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasBeginning");//timeInterval hasBeginning timeInstant
        OWLObjectProperty objPropHasEnd = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasEnd");//timeInterval hasEnd timeInstant
        OWLDataProperty dataPropHour = temporalObj.getTimeOntoRef().getOWLDataProperty("hour");//hour hold a non-negative integer
        OWLDataProperty dataPropMinute = temporalObj.getTimeOntoRef().getOWLDataProperty("minute");//hour hold a non-negative integer

        //Construct the FullOntoIndividual From String
        MORFullIndividual tInferredIndivFull = getIndividual(temporalLogicInferredIndiv, ontoRef);

        //TimeStamp for Inferred Individual obtained by checking its Sensor TimeStamp
        Timestamp tInferredIndivTS;
        String sensorInferredIndiv = null;

        if (temporalLogicInferredIndiv.startsWith("A_F")){
            //System.out.println("==========A_F==========");
            sensorInferredIndiv = getObjPropInference(tInferredIndivFull, "hasFurnitureTheSensor");
        } else if (temporalLogicInferredIndiv.startsWith("A_R")) {
            //System.out.println("==========A_R==========");
            sensorInferredIndiv = getObjPropInference(tInferredIndivFull, "hasRoomTheSensor");
        }
        //NOTE: Very specific implementation related to Galliera case, change in future, for general purpose.
        try {
            //System.out.println("==========TRY==========");

            tInferredIndivTS = Timestamp.valueOf(getSensorIndivTimeStamp(sensorInferredIndiv));//getIndividualTimestamp(getIndividual(sensorInferredIndiv, ontoRef)));//ONLY IF THE FURNITURE GOT INFERRED, WILL WE HAVE TS
        } catch (NullPointerException e) {
            //System.out.println("==========CATCH==========");

            //If furniture did not get inferred, but was inferred in the past. Give the latest TimeStamp
            tInferredIndivTS = new Timestamp(System.currentTimeMillis());
        }



        if (!Objects.equals(T1Name, T2Name) & !Objects.equals(temporalObj.recallTimeIntervalIndiv(),null)) {
            //System.out.println("==========6==========");
            //System.out.println("--> Setting temporalLogic where, T1:Something T2:Something & (T1 isNotEqualTo T2)");

            //Firstly, add the inferredIndiv as instant inside the timeInterval PROBLAMATIC (because of object property not having influence on the swrl result)
//            MORFullIndividual intervalIndiv = getIndividual(temporalObj.recallTimeIntervalIndiv(),ontoRef);
//            setIndividualWithObjProp(intervalIndiv,objPropInside,ontoRef.getOWLIndividual(temporalLogicInferredIndiv));
//            toRemoveIndivA1=intervalIndiv;
//            toRemoveObjProp1=objPropInside;
//            toRemoveIndivB1=ontoRef.getOWLIndividual(temporalLogicInferredIndiv);
            //setKnowledgeCleanerForOnto(intervalIndiv,objPropInside,ontoRef.getOWLIndividual(temporalLogicInferredIndiv));

//            System.out.println("============TS of InferredIndiv: "+tInferredIndivTS);
//            System.out.println("============TS of T1 BeginTime: "+T1TS);
//            System.out.println("============TS of T2 EndTime: "+T2TS);
            if (T1TS.before(T2TS)) {
                if (tInferredIndivTS.after(T1TS)&tInferredIndivTS.before(T2TS)) {
                    Set<OWLNamedIndividual> bigIntervalSet = getObjPropInferences(getIndividual(temporalObj.recallIndivHoldingBigTimeIntervals(),ontoRef),objPropIntervalContains);
                    for (OWLNamedIndividual bigInterval:bigIntervalSet) {
//                        System.out.println("==========7==========");
                        MORFullIndividual bigIntervalIndiv = getIndividual(bigInterval, ontoRef);

                        System.out.println(bigIntervalIndiv);

                        String bigIntervalBeginTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropHour);
                        String bigIntervalBeginTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropMinute);

                        String bigIntervalEndTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropHour);
                        String bigIntervalEndTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropMinute);

                        Date date = new Date();
                        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
                        Timestamp bigIntervalBeginTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalBeginTimeHour + ":" + bigIntervalBeginTimeMinute + ":00");
                        Timestamp bigIntervalEndTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalEndTimeHour + ":" + bigIntervalEndTimeMinute + ":00");

//                        System.out.println("----------------------------> Big Interval Begin Time: "+bigIntervalBeginTime);
//                        System.out.println("----------------------------> Big Interval Begin Time: "+bigIntervalEndTime);

                        //Secondly, add the small interval in the correct big interval
                        if (tInferredIndivTS.after(bigIntervalBeginTime) & tInferredIndivTS.before(bigIntervalEndTime)) {
                            System.out.println("============= Adding Knowledge in "+this.getOntoRef().getReferenceName()+" ============");
                            setIndividualWithObjProp(bigIntervalIndiv,objPropIntervalContains,ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));
//                            toRemoveIndivA2=bigIntervalIndiv;
//                            toRemoveObjProp2=objPropIntervalContains;
//                            toRemoveIndivB2=ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv());
                            setKnowledgeCleanerForOnto(bigIntervalIndiv,objPropIntervalContains,ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));

                        } else { System.out.println("The bigInterval '" + bigInterval + "' does not contain interval '" + temporalObj.recallTimeIntervalIndiv() + "'"); }
                    }
                } else { System.out.println("The TS of INFERENCE("+temporalLogicInferredIndiv+") is not between the TS of T1("+T1Name+") and TS of T2("+T2Name+")"); }
            } else { System.out.println("Logic error: TS of T1("+T1Name+") 'not before' TS of T2("+T2Name+")"); }
        } else { System.out.println("Check the parameters of inTimeInterval() in setTemporalLogic() in the centralThread"); }
    }

    @Override
    public void checkInferenceToActivateTemporalLogic(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith) {

    }

    @Override
    public void updateBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnMemoryAndTemporalLogic()");

        for (TemporalLogic timeMemObj:temporalLogicForMemoryList) {
            startTimeMemoryLogic(timeMemObj);
            synchronizeAndSaveOnto();
        }
    }

    private void setKnowledgeCleanerForOnto(MORFullIndividual indivA, OWLObjectProperty objProp, OWLNamedIndividual indivB) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setKnowledgeCleanerForOnto()");

        removalListIndivA.add(indivA);
        removalListObjProp.add(objProp);
        removalListIndivB.add(indivB);
    }


    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        if (checkHasDuration) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    public void setFlagStartedWithFreshMemory(boolean bool) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setFlagStartedWithFreshMemory()");

        flagUpdateTimeIntervalT1 = bool;
    }

    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj, Boolean checkWhetherInTheIntervals) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        flagTimeIntervalIsInAnotherInterval = checkWhetherInTheIntervals;
        if (checkHasDuration&checkWhetherInTheIntervals) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    @Override
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {

    }

    @Override
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {

    }

    @Override
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return false;
    }

    @Override
    public boolean getFlagActivateTemporalLogic() {
        return false;
    }

    public boolean getFlagTimeIntervalIsInAnotherInterval() {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagTimeIntervalIsInAnotherInterval()");

        return flagTimeIntervalIsInAnotherInterval;
    }

    public boolean getFlagStartedWithFreshMemory() {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagStartedWithFreshMemory()");

        System.out.println("FlagUpdateTimeIntervalT1 is : "+flagUpdateTimeIntervalT1);
        return flagUpdateTimeIntervalT1;
    }

    //INTERFACE:            CommitToMemory
    @Override
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {

    }

    private void commitT1TS(Timestamp timeStampForT1) {

        this.timeStampForT1 = timeStampForT1;
    }

    //INTERFACE:            RecallFromMemory
    @Override
    public String recallObjPropToActivateTemporalLogic() {
        return null;
    }

    @Override
    public String recallIndivToActivateTemporalLogic() {
        return null;
    }

    private Timestamp recallT1TS() {

        return timeStampForT1;
    }

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    public void setActivationCondition(String individualA, String objectProperty, String individualB) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setActivationCondition()");

        eventIndivA = individualA;
        eventObjProp = objectProperty;
        eventIndivB = individualB;
    }
    public String getEventActivationConditionIndivA(){
        return eventIndivA;
    }
    public String getEventActivationConditionObjProp(){
        return eventObjProp;
    }
    public String getEventActivationConditionIndivB(){
        return eventIndivB;
    }

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    @Override
    public void setInputLinkFromOntoToOnto(String sensorIndividual,OntologyPrototype ontologyObject) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setInputLinkFromOntoToOnto()");
        ontoToOntoInputMap.put(sensorIndividual,ontologyObject);
    }

    @Override
    public void startInputFromOntoToOnto(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startInputFromOntoToOnto()");

        Set<String> sensorIndividualSet = ontoToOntoInputMap.keySet();

        for (String sensorIndividual:sensorIndividualSet) {

            OntologyPrototype ontoObj = ontoToOntoInputMap.get(sensorIndividual);
            System.out.println("--> Transferring all data of Individual '"+sensorIndividual+"' from '"+ontoObj.getOntoRef().getReferenceName()+"' to '"+this.getOntoRef().getReferenceName()+"'");

            if (sensorIndividual.startsWith("S_B_")){
                int intValue = Integer.parseInt(getDataPropInference(getIndividual(sensorIndividual,ontoObj.getOntoRef()),"hasBrightnessIntValue"));
                this.setIndividualWithDataPropInt(getIndividual(sensorIndividual,ontoRef),"hasBrightnessIntValue",intValue);
            } else {
                boolean boolValue = ontoObj.getSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue");
                this.setSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue", boolValue);
            }

            String timestamp = ontoObj.getSensorIndivTimeStamp(sensorIndividual);
            this.setSensorIndivTimeStamp(sensorIndividual,timestamp);
            synchronizeAndSaveOnto();
        }
    }

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    @Override
    public void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setMySqlDBOutputInfo()");

        Activity_DataBase_Name = Activity_database_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    @Override
    public void setOutputLinkFromOntoToDB(String individualName, String objPropName) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # setOutputLinkFromOntoToDB()");

        indivForOutputToDB = individualName;
        objPropForOutputToDB = objPropName;
    }


    @Override
    public void startOutputFromOntoToDB(String indivForInfer, String objPropForInfer) {
        //System.out.println("# "+this.getOntoRef().getReferenceName()+" # startOutputFromOntoToDB()");

        String activityName = getObjPropInference(getIndividual(indivForInfer, ontoRef), objPropForInfer);
        if (!Objects.equals(activityName,null)) {
            mySqlObj.startDBConnectionOrCreateNew("GallieraActivityDB", "root", "nepo");
            mySqlObj.setIntoTable(this.getOntoRef().getReferenceName()+"_Activities", activityName, new Timestamp(System.currentTimeMillis()));
            mySqlObj.stopDBConnection();
        } else {
            System.out.println("# "+this.getOntoRef().getReferenceName()+" # has no activity recognition ");
        }
    }

}
