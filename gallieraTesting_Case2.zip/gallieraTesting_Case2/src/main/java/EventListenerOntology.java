import java.util.List;

public interface EventListenerOntology {

    void setActivationCondition(String individualA, String objectProperty, String individualB);

    List<String> getEventActivationConditionIndivA();
    List<String> getEventActivationConditionObjProp();
    List<String> getEventActivationConditionIndivB();
}
