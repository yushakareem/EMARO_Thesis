import java.sql.Timestamp;
import java.util.concurrent.TimeUnit;

public class MySqlDBPersistor {

    public static void main(String[] args) {

        MySqlDBPersistor objSelf = new MySqlDBPersistor();


        //objSelf.startTest();
        objSelf.clearAll();
    }

    public void startTest() {

        MySQLConnector mysqlObj = new MySQLConnector();
        mysqlObj.startDBConnectionOrCreateNew("OpenHAB","root","nepo");

        //=======================================================================================================
        //Kitchen then Cabinet (TO1)
        mysqlObj.setIntoTableBool("Item2",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item2 (S_M_Kitchen) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MINUTES.sleep(1);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item6",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item6 (S_M_KitchenCabinet) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item6",new Timestamp(System.currentTimeMillis()),false);
        System.out.println("Item6 (S_M_KitchenCabinet) as 'FALSE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item2",new Timestamp(System.currentTimeMillis()),false);
        System.out.println("Item2 (S_M_Kitchen) as 'FALSE' at time '"+new Timestamp(System.currentTimeMillis())+"'");


        //=======================================================================================================
        //LivingRoom then TVBrightness (TO2)
        mysqlObj.setIntoTableBool("Item5",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item5 (S_M_LivingRoom) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MINUTES.sleep(1);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableDouble("Item20",new Timestamp(System.currentTimeMillis()),9);
        System.out.println("Item20 (S_B_TV) as '9' at time '"+new Timestamp(System.currentTimeMillis())+"'");

        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableDouble("Item20",new Timestamp(System.currentTimeMillis()),3);
        System.out.println("Item20 (S_B_TV) as '3' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item5",new Timestamp(System.currentTimeMillis()),false);
        System.out.println("Item5 (S_M_LivingRoom) as 'FALSE' at time '"+new Timestamp(System.currentTimeMillis())+"'");


        //=======================================================================================================
        //Sleep (TO3 & TO4)
        mysqlObj.setIntoTableBool("Item7",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item5 (S_M_Bed) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item7",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item5 (S_M_Bed) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(90000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item7",new Timestamp(System.currentTimeMillis()),false);
        System.out.println("Item5 (S_M_Bed) as 'FALSE' at time '"+new Timestamp(System.currentTimeMillis())+"'");

        //=======================================================================================================
        //BathroomVisit (TO5)
        mysqlObj.setIntoTableBool("Item1",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item5 (S_M_BathRoom) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(30000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item1",new Timestamp(System.currentTimeMillis()),true);
        System.out.println("Item5 (S_M_BathRoom) as 'TRUE' at time '"+new Timestamp(System.currentTimeMillis())+"'");
        try {
            TimeUnit.MILLISECONDS.sleep(90000);
        } catch (InterruptedException e) {
            System.out.println("1 min");
        }
        mysqlObj.setIntoTableBool("Item1",new Timestamp(System.currentTimeMillis()),false);
        System.out.println("Item5 (S_M_BathRoom) as 'FALSE' at time '"+new Timestamp(System.currentTimeMillis())+"'");

        //=======================================================================================================

        mysqlObj.stopDBConnection();
    }

    public void clearAll() {

        MySQLConnector mysqlObj = new MySQLConnector();
        mysqlObj.startDBConnectionOrCreateNew("OpenHAB","root","nepo");

        //=======================================================================================================
        //Kitchen then Cabinet (TO1)
        mysqlObj.setIntoTableBool("Item6",new Timestamp(System.currentTimeMillis()),false);
        mysqlObj.setIntoTableBool("Item2",new Timestamp(System.currentTimeMillis()),false);

        //=======================================================================================================
        //LivingRoom then TVBrightness (TO2)
        mysqlObj.setIntoTableDouble("Item20",new Timestamp(System.currentTimeMillis()),3);
        mysqlObj.setIntoTableBool("Item5",new Timestamp(System.currentTimeMillis()),false);

        //=======================================================================================================
        //Sleep (TO3 & TO4)
        mysqlObj.setIntoTableBool("Item7",new Timestamp(System.currentTimeMillis()),false);

        //=======================================================================================================
        //BathroomVisit (TO5)
        mysqlObj.setIntoTableBool("Item1",new Timestamp(System.currentTimeMillis()),false);
        //=======================================================================================================

        mysqlObj.stopDBConnection();
    }
}
