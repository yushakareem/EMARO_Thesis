import java.util.ArrayList;
import java.util.List;

public class isStillIn_TaskOntology implements TaskOntologyPrototype {

    List<OntologyEventListener> TOeventlisteners = new ArrayList<>();

    boolean eventIsStillInFlag = false;
    String nameOfTheFurnitureOccupied;

    @Override
    public void setEventListener(OntologyEventListener TOhasEventListener) {

        TOeventlisteners.add(TOhasEventListener);
        System.out.println("Listener Added!");
    }

    @Override
    public void InitiateListener_eventLivingRoom() {
        //Do nothing
    }

    @Override
    public void InitiateListener_eventTableArea() {
        //Do nothing
    }

    @Override
    public void InitiateListener_eventKitchen() {
        //Do nothing
    }

    @Override
    public void InitiateListener_eventBedRoom() {
        //Do nothing
    }

    @Override
    public void InitiateListener_eventBathRoom() {
        //Do nothing
    }

    @Override
    public void InitiateListener_eventIsStillIn(String nameOfFurnitureOccupied) {
        if (this.eventIsStillInFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
        nameOfTheFurnitureOccupied = nameOfFurnitureOccupied;
    }

    @Override
    public void ListensFor_eventLivingRoom() {
        //Do nothing
    }

    @Override
    public void ListensFor_eventTableArea() {
        //Do nothing
    }

    @Override
    public void ListensFor_eventKitchen() {
        //Do nothing
    }

    @Override
    public void ListensFor_eventBedRoom() {
        //Do nothing
    }

    @Override
    public void ListensFor_eventBathRoom() {
        //Do nothing
    }

    @Override
    public void ListensFor_eventIsStillIn() {
        this.eventIsStillInFlag = true;
    }

    @Override
    public void run() {

    }
}
