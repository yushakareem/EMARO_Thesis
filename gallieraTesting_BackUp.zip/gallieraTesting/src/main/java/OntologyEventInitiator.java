/**
 * Created by yushakareem on 25/07/17.
 */
public interface OntologyEventInitiator {
    void addListener();
}
