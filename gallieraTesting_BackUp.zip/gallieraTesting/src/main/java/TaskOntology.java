import java.util.ArrayList;
import java.util.List;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    List<OntologyEventListener> TOeventlisteners = new ArrayList<>();

    boolean eventLivingRoomFlag = false;
    boolean eventTableAreaFlag = false;
    boolean eventKitchenFlag = false;
    boolean eventBedRoomFlag = false;
    boolean eventBathRoomFlag = false;

    public TaskOntology(){

    }

    @Override
    public void run() {
        //Procedure
        System.out.println("TO1 thread begins, ID:" + Thread.currentThread().getId());
        System.out.println("Task Ontology 1 Running");
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        System.out.println("TO1 thread ends, ID:" + Thread.currentThread().getId());
    }

    @Override
    public void addEventListener(OntologyEventListener TOeventListener) {

        TOeventlisteners.add(TOeventListener);
        System.out.println("Listener Added!");
    }

    @Override
    public void InitiateListener_eventLivingRoom() {
        if (this.eventLivingRoomFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
    }

    @Override
    public void InitiateListener_eventTableArea() {
        if (this.eventLivingRoomFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
    }

    @Override
    public void InitiateListener_eventKitchen() {
        if (this.eventLivingRoomFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
    }

    @Override
    public void InitiateListener_eventBedRoom() {
        if (this.eventLivingRoomFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
    }

    @Override
    public void InitiateListener_eventBathRoom() {
        if (this.eventLivingRoomFlag) {
            Thread thread = new Thread(this);
            thread.start();
        }
    }

    @Override
    public void ListensFor_eventLivingRoom() {
        this.eventLivingRoomFlag = true;
    }

    @Override
    public void ListensFor_eventTableArea() {
        this.eventTableAreaFlag = true;
    }

    @Override
    public void ListensFor_eventKitchen() {
        this.eventKitchenFlag = true;
    }

    @Override
    public void ListensFor_eventBedRoom() {
        this.eventBedRoomFlag = true;
    }

    @Override
    public void ListensFor_eventBathRoom() {
        this.eventBathRoomFlag = true;
    }
}
