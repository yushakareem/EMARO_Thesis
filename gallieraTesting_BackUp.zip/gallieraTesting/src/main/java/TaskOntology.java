import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    OWLReferences ontoRef;

    String Activity_DataBase_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String evIndvidualA;
    String evObjectProperty;
    String evIndividualB;

    public void startWithFreshMemory() {

        Thread thread = new Thread(this);
        thread.start();
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Task Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public TaskOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
    }

    //INTERFACE: OntologyPrototype                         <--/// Has the heart: run() //
    @Override
    public void setIndividualWithTimestamp(MORFullIndividual individual, Timestamp timeStamp) {

    }

    @Override
    public MORFullIndividual getIndividual(String Sensor_IndividualName_InOntology, OWLReferences ontoRef) {
        return null;
    }

    @Override
    public Timestamp getIndividualTimestamp(MORFullIndividual individual) {
        return null;
    }

    @Override
    public String getInference(MORFullIndividual individual, String objectPropertyName) {
        return null;
    }

    @Override
    public Set<OWLNamedIndividual> getInferencesOWLNamedIndividual(MORFullIndividual individual, String objectPropertyName) {
        return null;
    }

    @Override
    public OWLReferences getOntoRef() {
        return ontoRef;
    }

    @Override
    public void synchronizeAndSaveOnto() {

    }
    
    //INTERFACE:    Runnable
    @Override
    public void run() {
        //Procedure
        System.out.println(this.getOntoRef()+"thread begins, ID:" + Thread.currentThread().getId());
        System.out.println("Task Ontology Running");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(this.getOntoRef()+"thread ends, ID:" + Thread.currentThread().getId());
    }
    //INTERFACE:    OntologyHasMemory
    @Override
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {

    }

    @Override
    public void modifyBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {

    }

    @Override
    public void modifyBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {

    }

    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {

    }

    @Override
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {

    }

    @Override
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {

    }

    @Override
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return false;
    }

    @Override
    public boolean getFlagActivateTemporalLogic() {
        return false;
    }

    //INTERFACE:        CommitToMemory
    @Override
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {

    }

    @Override
    public void commitInferenceOf(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith) {

    }
    //INTERFACE:        RecallFromMemory
    @Override
    public String recallDesiredKnowledgeObjProp() {
        return null;
    }

    @Override
    public String recallDesiredKnowledgeIndiv() {
        return null;
    }

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListener
    public void setActivationCondition(String individualA, String objectProperty, String individualB) {

        evIndvidualA = individualA;
        evObjectProperty = objectProperty;
        evIndividualB = individualB;
    }
    public String getEventActivationConditionIndivA(){
        return evIndvidualA;
    }
    public String getEventActivationConditionObjProp(){
        return evObjectProperty;
    }
    public String getEventActivationConditionIndivB(){
        return evIndividualB;
    }

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    @Override
    public void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {

        Activity_DataBase_Name = Activity_database_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

}
