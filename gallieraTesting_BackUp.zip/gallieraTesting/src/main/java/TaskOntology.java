import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    Thread thisThread;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    boolean flagTimeIntervalIsInAnotherInterval;
    boolean flagUpdateTimeIntervalT1;
    List<TemporalLogic> temporalLogicObjectsList = new ArrayList<>();

    List<MORFullIndividual> removalListIndivA = new ArrayList<>();
    List<OWLObjectProperty> removalListObjProp = new ArrayList<>();
    List<OWLNamedIndividual> removalListIndivB = new ArrayList<>();

    //Critical breaking of swrl rule so that when temporal logic inference condition is not satisfied, we continoulsy do not get inference for old knowledge.
    MORFullIndividual toRemoveIndivA;
    OWLObjectProperty toRemoveObjProp;
    OWLNamedIndividual toRemoveIndivB;

    //INTERFACE:        CommitToMemory
    String timeStampForT1;
    //INTERFACE:        RecallFromMemory

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    String eventIndivA;
    String eventObjProp;
    String eventIndivB;

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    Map<String,OntologyPrototype> ontoToOntoInputMap = new HashMap<>();

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    String Activity_DataBase_Name;
    String Activity_Table_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String indivForOutputToDB;
    String objPropForOutputToDB;

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Task Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public TaskOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # DEFINED AS # TaskOntology()");
    }

    //INTERFACE: OntologyPrototype                         <--/// Has the heart: run() //

    @Override
    public void updateBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {} // NOT USED

    @Override
    public void updateBasedOnCurrentSensoryState(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnCurrentSensoryState()");
        this.startInputFromOntoToOnto(ontoToOntoInputMap);
    }

    @Override
    public void setSensorIndivTimeStamp(String sensorIndividual, String timestamp) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        setIndividualWithTimestamp(localIndiv,timestamp);
    }

    @Override
    public void setIndividualWithTimestamp(MORFullIndividual individual, String timeStamp) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");

        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",timeStamp);
        individual.writeSemanticInconsistencySafe();
        individual.buildDataIndividual();

    }

    @Override
    public void setSensorIndivBoolValue(String sensorIndividual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivBoolValue()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual, ontoRef);
        setIndividualWithBoolValue(localIndiv,dataPropName,boolDataValue);

    }

    @Override
    public void setIndividualWithBoolValue(MORFullIndividual individual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithBoolValue()");

        individual.readSemantic();
        individual.removeData(dataPropName);
        individual.addData(dataPropName,boolDataValue,true);
        individual.writeSemanticInconsistencySafe();
        individual.buildDataIndividual();
    }

    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    public MORFullIndividual getIndividual(OWLNamedIndividual individualName, OWLReferences ontoRef) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    @Override
    public String getIndividualTimestamp(MORFullIndividual individual) {
        return null;
    }

    @Override
    public boolean getSensorIndivBoolValue(String sensorIndividual, String dataPropName) {
        return false;
    }

    @Override
    public String getDataPropInference(MORFullIndividual individual, String dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty(dataPropName));
        return data.getLiteral();
    }

    public String getDataPropInference(MORFullIndividual individual, OWLDataProperty dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(dataPropName);
        return data.getLiteral();
    }

    @Override
    public String getSensorIndivTimeStamp(String sensorIndividual) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        return getDataPropInference(localIndiv, "hasTimeStamp");
    }

    @Override
    public String getObjPropInference(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    public String getObjPropInference(MORFullIndividual individual, OWLObjectProperty objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    @Override
    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectPropertyName);
    }


    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, OWLObjectProperty objectProperty) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectProperty);
    }

    @Override
    public OWLReferences getOntoRef() {
        return ontoRef;
    }

    @Override
    public void synchronizeAndSaveOnto() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # synchronizeAndSaveOnto()");

        getOntoRef().synchronizeReasoner();
        getOntoRef().saveOntology(getOntoRef().getFilePath());
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+"\n\n # run()");
        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread begins");


        /*1*/
        this.updateBasedOnCurrentSensoryState(ontoToOntoInputMap);
        this.updateBasedOnMemoryAndTemporalLogic(temporalLogicObjectsList);
        System.out.println("## CHECK 1"+getObjPropInference(getIndividual(indivForOutputToDB,ontoRef),objPropForOutputToDB));
        //this.getKnowledgeCleanerForOnto(removalListIndivA,removalListObjProp,removalListIndivB);
        System.out.println("## CHECK 2"+getObjPropInference(getIndividual(indivForOutputToDB,ontoRef),objPropForOutputToDB));

        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread ends\n\n");
    }

    //INTERFACE:    OntoHasMemoryAndInputFromOnto
    public void startWithFreshMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithFreshMemory()");

        this.setFlagStartedWithFreshMemory(true);
        Thread thread = new Thread(this);
        thread.start();
    }

    public void startWithOldMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithOldMemory()");

        this.setFlagStartedWithFreshMemory(false);
        Thread thread = new Thread(this);
        thread.start();
    }

    //INTERFACE:        OntologyHasMemory
    @Override
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startTimeMemoryLogic()");
        /*
            t prefix means time
         */

        //Update TimeNow so that it is in the true now.
        setIndividualWithTimestamp(getIndividual("Time_Now", ontoRef), String.valueOf(new Timestamp(System.currentTimeMillis())));

        //Time Interval T1
        OWLNamedIndividual tIntervalT1NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT1Indiv());
        Timestamp T1TS;

        //Time Interval T2
        OWLNamedIndividual tIntervalT2NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT2Indiv());
        Timestamp T2TS;

        //Time Ontology object properties
        OWLObjectProperty objPropBefore = temporalObj.getTimeOntoRef().getOWLObjectProperty("before");//timeInstant before timeInstant
        OWLObjectProperty objPropAfter = temporalObj.getTimeOntoRef().getOWLObjectProperty("after");//timeInstant after timeInstant
        OWLObjectProperty objPropIntervalContains = temporalObj.getTimeOntoRef().getOWLObjectProperty("intervalContains");//interval contains interval
        OWLObjectProperty objPropInside = temporalObj.getTimeOntoRef().getOWLObjectProperty("inside");//interval contains instant
        OWLObjectProperty objPropHasBeginning = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasBeginning");//timeInterval hasBeginning timeInstant
        OWLObjectProperty objPropHasEnd = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasEnd");//timeInterval hasEnd timeInstant
        OWLDataProperty dataPropHour = temporalObj.getTimeOntoRef().getOWLDataProperty("hour");//hour hold a non-negative integer
        OWLDataProperty dataPropMinute = temporalObj.getTimeOntoRef().getOWLDataProperty("minute");//hour hold a non-negative integer


        //Individual and ObjectProperty given by user
        String tIndiv = temporalObj.recallIndiv(); //Human
        String tObjProp = temporalObj.recallObjProp(); //isUtilizing

        //Breaker of old knowledge:
        try {
            System.out.println("============= Removing OLD Knowledge ============");
            toRemoveIndivA.readSemantic();
            toRemoveIndivA.removeObject(toRemoveObjProp, toRemoveIndivB);
            toRemoveIndivA.writeSemantic();
            synchronizeAndSaveOnto();
        } catch(NullPointerException a) {
            System.out.println("Skipping removal of old knowledge as there is no knowledge to be removed (Null pointer exception)");
        }

        //Setting the timeIntervals 'T1' and 'T2' based on startWithFreshMemory() OR startWithOldMemory()
        String T1Name = temporalObj.recallTimeIntervalT1Indiv();//TI_IsIn_Kitchen_BeginTime
        String T2Name = temporalObj.recallTimeIntervalT2Indiv();//TI_IsIn_Kitchen_EndTime
        if (getFlagStartedWithFreshMemory()) {
            //Only gets updated for the first time of activation
            commitT1TS(String.valueOf(new Timestamp(System.currentTimeMillis())));
            System.out.println("--------> T1: "+T1Name+" FLAG update T1: "+ getFlagStartedWithFreshMemory());
        }
        System.out.println("------------------------------->THIS IS recallT1TS: "+recallT1TS());

        setSensorIndivTimeStamp(T1Name, recallT1TS());
        setSensorIndivTimeStamp(T2Name, String.valueOf(new Timestamp(System.currentTimeMillis())));//Gets updated every time this ontology is activated
        synchronizeAndSaveOnto();


        String tInferredIndivName = getObjPropInference(getIndividual(tIndiv, ontoRef), tObjProp);//'NULL' OR THE PARTICULAR 'FURNITURE' example: A_F_KitchenCabinet
        //If the main ingredient is 'null' then skip the whole thing
        if (!Objects.equals(tInferredIndivName,null)) {

            System.out.println("--> Inference of '"+tIndiv+"' '"+tObjProp+"' is '"+tInferredIndivName+"', proceeding towards setting temporal logic!");
            MORFullIndividual tInferredIndivFull = getIndividual(tInferredIndivName, ontoRef);

            //TimeStamp for Inferred Individual obtained by checking its Sensor TimeStamp
            Timestamp tInferredIndivTS;
            String sensorInferredIndiv = getObjPropInference(tInferredIndivFull, "hasFurnitureTheSensor");
            tInferredIndivTS = Timestamp.valueOf(getSensorIndivTimeStamp(sensorInferredIndiv));//getIndividualTimestamp(getIndividual(sensorInferredIndiv, ontoRef)));//ONLY IF THE FURNITURE GOT INFERRED, WILL WE HAVE TS

            //WE HAVE 20 SECONDS TO Grab the motion detection of Furniture

            if (Objects.equals(T1Name, null) & !Objects.equals(T2Name, null)) {

                System.out.println("--> Setting temporalLogic where, T1:Something T2:NULL");
                T2TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T2Name, ontoRef)));

                if (tInferredIndivTS.before(T2TS)) {
                    tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                    tInferredIndivFull.writeSemanticInconsistencySafe();
                    tInferredIndivFull.buildObjectIndividual();
                    //setKnowledgeCleanerForOnto(tInferredIndivFull,objPropBefore,ontoRef.getOWLIndividual(T2Name));

                } else {
                    System.out.println("The TS of inferredIndiv is before timeInterval T2");
                }
            } else if (!Objects.equals(T1Name, null) & Objects.equals(T2Name, null)) {
                System.out.println("--> Setting temporalLogic where, T1:NULL T2:Something");
                T1TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T1Name, ontoRef)));

                if (tInferredIndivTS.after(T1TS)) {
                    tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                    tInferredIndivFull.writeSemanticInconsistencySafe();
                    tInferredIndivFull.buildObjectIndividual();
                    //setKnowledgeCleanerForOnto(tInferredIndivFull,objPropAfter,ontoRef.getOWLIndividual(T1Name));

                } else {

                    System.out.println("The TS of inferredIndiv is after timeInterval T1");
                }
            } else if (Objects.equals(T1Name, null) & Objects.equals(T2Name, null) & !Objects.equals(temporalObj.recallTimeIntervalIndiv(),null)) {

                System.out.println("--> Setting temporalLogic where, T1:NULL T2:NULL");
                System.out.println("--> The inferredIndiv is not limited to the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
            }  else if (!Objects.equals(T1Name, T2Name) & !Objects.equals(temporalObj.recallTimeIntervalIndiv(),null)) {

                System.out.println("--> Setting temporalLogic where, T1:Something T2:Something & (T1 isNotEqualTo T2)");

                T1TS = Timestamp.valueOf(recallT1TS());
                T2TS = new Timestamp(System.currentTimeMillis());

                //MORFullIndividual tIntervalIndivFull = getIndividual(temporalObj.recallTimeIntervalIndiv(),ontoRef);
                //tIntervalIndivFull.addObject(objPropInside,tInferredIndivFull.getInstance());
                //setKnowledgeCleanerForOnto(tIntervalIndivFull,objPropInside,tInferredIndivFull.getInstance());
                //tIntervalIndivFull.writeSemantic();

                //tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                //setKnowledgeCleanerForOnto(tInferredIndivFull,objPropAfter,ontoRef.getOWLIndividual(T1Name));
                //tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                //setKnowledgeCleanerForOnto(tInferredIndivFull,objPropBefore,ontoRef.getOWLIndividual(T2Name));
                //tInferredIndivFull.writeSemantic();

                if (T1TS.before(T2TS)) {
                    if (tInferredIndivTS.after(T1TS)&tInferredIndivTS.before(T2TS)) {

                        Set<OWLNamedIndividual> bigIntervalSet = getObjPropInferences(getIndividual(temporalObj.recallIndivHoldingBigTimeIntervals(),ontoRef),objPropIntervalContains);
                        for (OWLNamedIndividual bigInterval:bigIntervalSet) {

                            MORFullIndividual bigIntervalIndiv = getIndividual(bigInterval, ontoRef);


                            System.out.println(bigIntervalIndiv);

                            String bigIntervalBeginTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropHour);
                            String bigIntervalBeginTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropMinute);

                            String bigIntervalEndTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropHour);
                            String bigIntervalEndTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropMinute);

                            Date date = new Date();
                            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
                            Timestamp bigIntervalBeginTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalBeginTimeHour + ":" + bigIntervalBeginTimeMinute + ":00");
                            Timestamp bigIntervalEndTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalEndTimeHour + ":" + bigIntervalEndTimeMinute + ":00");

                            System.out.println("----------------------------> Big Interval Begin Time: "+bigIntervalBeginTime);
                            System.out.println("----------------------------> Big Interval Begin Time: "+bigIntervalEndTime);

                            if (tInferredIndivTS.after(bigIntervalBeginTime) & tInferredIndivTS.before(bigIntervalEndTime)) {
                                System.out.println("============= Adding OLD Knowledge ============");
                                bigIntervalIndiv.readSemantic(); //Because below addObject is primitive way of adding object (it does not have read semantic inside) compared to setObjProperty()
                                bigIntervalIndiv.addObject(objPropIntervalContains, ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));
                                bigIntervalIndiv.writeSemantic();
                                System.out.println(bigIntervalIndiv);
//                                System.out.println(bigIntervalIndiv);
//                                bigIntervalIndiv.buildObjectIndividual();
//                                System.out.println(bigIntervalIndiv);
                                //setKnowledgeCleanerForOnto(bigIntervalIndiv,objPropIntervalContains,ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));
                                toRemoveIndivA = bigIntervalIndiv;
                                toRemoveObjProp = objPropIntervalContains;
                                toRemoveIndivB = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv());
                            } else {
                                System.out.println("The bigInterval '" + bigInterval + "' does not contain interval '" + temporalObj.recallTimeIntervalIndiv() + "'");
                            }
                        }
                    } else {
                        System.out.println("The TS of INFERENCE("+tInferredIndivName+") is not between the TS of T1("+T1Name+") and TS of T2("+T2Name+")");
                    }
                } else {
                    System.out.println("Logic error: TS of T1("+T1Name+") 'not before' TS of T2("+T2Name+")");
                }
            }
        } else {
            System.out.println("--> Inference of '"+tIndiv+"' '"+tObjProp+"' is NULL, hence cannot place it in the defined interval T1,T2");
        }
    }

    @Override
    public void checkInferenceToActivateTemporalLogic(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith) {

    }

    @Override
    public void updateBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnMemoryAndTemporalLogic()");

        for (TemporalLogic timeMemObj:temporalLogicForMemoryList) {
            startTimeMemoryLogic(timeMemObj);
            synchronizeAndSaveOnto();
        }
    }

    private void setKnowledgeCleanerForOnto(MORFullIndividual indivA, OWLObjectProperty objProp, OWLNamedIndividual indivB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setKnowledgeCleanerForOnto()");

        removalListIndivA.add(indivA);
        removalListObjProp.add(objProp);
        removalListIndivB.add(indivB);
    }


    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        if (checkHasDuration) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    public void setFlagStartedWithFreshMemory(boolean bool) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setFlagStartedWithFreshMemory()");

        flagUpdateTimeIntervalT1 = bool;
    }

    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj, Boolean checkWhetherInTheIntervals) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        flagTimeIntervalIsInAnotherInterval = checkWhetherInTheIntervals;
        if (checkHasDuration&checkWhetherInTheIntervals) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    @Override
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {

    }

    @Override
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {

    }

    private void getKnowledgeCleanerForOnto(List<MORFullIndividual> removalListIndivA, List<OWLObjectProperty> removalListObjProp, List<OWLNamedIndividual> removalListIndivB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getKnowledgeCleanerForOnto()");

        for (MORFullIndividual indivA:removalListIndivA) {
            for (OWLObjectProperty objProp:removalListObjProp) {
                for (OWLNamedIndividual indivB:removalListIndivB) {
                    indivA.readSemantic();
                    indivA.removeObject(objProp,indivB);
                    indivA.writeSemanticInconsistencySafe();
                }
            }
        }
        synchronizeAndSaveOnto();
    }


    @Override
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return false;
    }

    @Override
    public boolean getFlagActivateTemporalLogic() {
        return false;
    }

    public boolean getFlagTimeIntervalIsInAnotherInterval() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagTimeIntervalIsInAnotherInterval()");

        return flagTimeIntervalIsInAnotherInterval;
    }

    public boolean getFlagStartedWithFreshMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagStartedWithFreshMemory()");

        System.out.println("FlagUpdateTimeIntervalT1 is : "+flagUpdateTimeIntervalT1);
        return flagUpdateTimeIntervalT1;
    }

    //INTERFACE:            CommitToMemory
    @Override
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {

    }

    private void commitT1TS(String timeStampForT1) {

        this.timeStampForT1 = timeStampForT1;
    }

    //INTERFACE:            RecallFromMemory
    @Override
    public String recallObjPropToActivateTemporalLogic() {
        return null;
    }

    @Override
    public String recallIndivToActivateTemporalLogic() {
        return null;
    }

    private String recallT1TS() {

        return timeStampForT1;
    }

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    public void setActivationCondition(String individualA, String objectProperty, String individualB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setActivationCondition()");

        eventIndivA = individualA;
        eventObjProp = objectProperty;
        eventIndivB = individualB;
    }
    public String getEventActivationConditionIndivA(){
        return eventIndivA;
    }
    public String getEventActivationConditionObjProp(){
        return eventObjProp;
    }
    public String getEventActivationConditionIndivB(){
        return eventIndivB;
    }

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    @Override
    public void setInputLinkFromOntoToOnto(String sensorIndividual,OntologyPrototype ontologyObject) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setInputLinkFromOntoToOnto()");
        ontoToOntoInputMap.put(sensorIndividual,ontologyObject);
    }

    @Override
    public void startInputFromOntoToOnto(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startInputFromOntoToOnto()");

        Set<String> sensorIndividualSet = ontoToOntoInputMap.keySet();
        for (String sensorIndividual:sensorIndividualSet) {
            OntologyPrototype ontoObj = ontoToOntoInputMap.get(sensorIndividual);
            System.out.println("--> Transferring all data of Individual '"+sensorIndividual+"' from '"+ontoObj.getOntoRef().getReferenceName()+"' to '"+this.getOntoRef().getReferenceName()+"'");
            boolean boolValue = ontoObj.getSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue");
            this.setSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue", boolValue);
            String timestamp = ontoObj.getSensorIndivTimeStamp(sensorIndividual);
            this.setSensorIndivTimeStamp(sensorIndividual,timestamp);
            synchronizeAndSaveOnto();
        }
    }

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    @Override
    public void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_table_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setMySqlDBOutputInfo()");

        Activity_DataBase_Name = Activity_database_Name;
        Activity_Table_Name = Activity_table_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    @Override
    public void setOutputLinkFromOntoToDB(String individualName, String objPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setOutputLinkFromOntoToDB()");

        indivForOutputToDB = individualName;
        objPropForOutputToDB = objPropName;
    }

    @Override
    public void startOutputFromOntoToDB() {

    }
}
