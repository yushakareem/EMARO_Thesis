import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    OWLReferences ontoRef;

    List<OntologyEventListener> eventListenersList = new ArrayList<>();

    String Activity_DataBase_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String evIndvidualA;
    String evObjectProperty;
    String evIndividualB;

    String nameOfTO;

    public TaskOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
            OntoReferenceName,
            filePath,
            ontologyPath,
            bufferingReasoner
        );
    }

//    boolean eventLivingRoomFlag = false;
//    boolean eventTableAreaFlag = false;
//    boolean eventKitchenFlag = false;
//    boolean eventBedRoomFlag = false;
//    boolean eventBathRoomFlag = false;

    @Override
    public void run() {
        //Procedure
        System.out.println(this.getOntoReferenceName()+"thread begins, ID:" + Thread.currentThread().getId());
        System.out.println("Task Ontology Running");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(this.getOntoReferenceName()+"thread ends, ID:" + Thread.currentThread().getId());
    }

    //public void setInputLinkFromOntoToOnto(String fromOntology_IndividualName, String toOntology_IndividualName){} //OR
    //public void setInputLinkFromOntoToOnto(String fromOntology_IndividualName, Ontology ontology_Object){} //OR
    //public void setInputLinkFromOntoToOnto(String fromOntology_IndividualName, ontoRef){}

    //public void startInputFromOntoToOnto(List<> or Map<> semanticTransferListorMap) {}

    //public void setOutputLinkFromOntoToDB(String DB_TableName, String toInfer_IndividualName, String toInfer_ObjectPropName){}

    //public void startOutputFromOntoToDB(List<> or Map<> inferredThingToOutputToDBMap) {}

    //public void commitInferenceOf(String individualName, String objectPropertyName) {
    //
    //  save stuff someWhere MapOfThingsToInferBeforeSaving
    // }

    @Override
    public void hasEventListener(OntologyEventListener EventListener) {

        eventListenersList.add(EventListener);
        System.out.println("Listener Added!");
    }

    @Override
    public void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {

        Activity_DataBase_Name = Activity_database_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    @Override
    public void setActivationCondition(String individualA, String objectProperty, String individualB) {

        evIndvidualA = individualA;
        evObjectProperty = objectProperty;
        evIndividualB = individualB;
    }

    @Override
    public String getOntoReferenceName() {
        return String.valueOf(ontoRef);
    }

    public String getEventActivationConditionIndivA(){
        return evIndvidualA;
    }

    public String getEventActivationConditionObjProp(){
        return evObjectProperty;
    }

    public String getEventActivationConditionIndivB(){
        return evIndividualB;
    }

    public void startWithFreshMemory() {

        Thread thread = new Thread(this);
        thread.start();
    }

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/*
    /////////////-->      (Data Importer) methods        <--///////////////////////////

    NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Task Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    INTERFACE: OntologyPrototype                         <--/// Has the heart: run() //
    INTERFACE:    Runnable
    INTERFACE:    OntologyHasMemory
    INTERFACE:        SaveInMemory
    INTERFACE:        RecollectFromMemory
    INTERFACE:    OntologyHasTemporalLogic

    ////////--> Updating ontology with a given frequency

    NONE

    ///////////--> Methods related to: Defining the link between ontologies

    INTERFACE: EventListener

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    INTERFACE: OntoReceivesIndividualsFromOnto

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    INTERFACE: MySqlDBOutputLink
*/
}
