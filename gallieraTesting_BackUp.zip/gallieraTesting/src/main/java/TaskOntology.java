import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    boolean flagTimeIntervalIsInAnotherInterval;
    boolean flagUpdateTimeIntervalT1;
    List<TemporalLogic> temporalLogicObjectsList = new ArrayList<>();
    //INTERFACE:        CommitToMemory
    //INTERFACE:        RecallFromMemory

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    String eventIndivA;
    String eventObjProp;
    String eventIndivB;

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    Map<String,OntologyPrototype> ontoToOntoInputMap = new HashMap<>();

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    String Activity_DataBase_Name;
    String Activity_Table_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String indivForOutputToDB;
    String objPropForOutputToDB;


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    /////////////-->      (Data Importer) methods        <--///////////////////////////

    //NONE

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Task Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public TaskOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # DEFINED AS # TaskOntology()");
    }

    //INTERFACE: OntologyPrototype                         <--/// Has the heart: run() //

    @Override
    public void updateBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {} // NOT USED

    @Override
    public void updateBasedOnCurrentSensoryState(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnCurrentSensoryState()");
        this.startInputFromOntoToOnto(ontoToOntoInputMap);
    }

    @Override
    public void setSensorIndivTimeStamp(String sensorIndividual, String timestamp) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        setIndividualWithTimestamp(localIndiv,timestamp);
    }

    @Override
    public void setIndividualWithTimestamp(MORFullIndividual individual, String timeStamp) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");

        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",timeStamp);
        individual.writeSemanticInconsistencySafe();
        individual.buildDataIndividual();

    }

    @Override
    public void setSensorIndivBoolValue(String sensorIndividual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivBoolValue()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual, ontoRef);
        setIndividualWithBoolValue(localIndiv,dataPropName,boolDataValue);

    }

    @Override
    public void setIndividualWithBoolValue(MORFullIndividual individual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithBoolValue()");

        individual.readSemantic();
        individual.removeData(dataPropName);
        individual.addData(dataPropName,boolDataValue,true);
        individual.writeSemanticInconsistencySafe();
        individual.buildDataIndividual();
    }

    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    public MORFullIndividual getIndividual(OWLNamedIndividual individualName, OWLReferences ontoRef) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }

    @Override
    public String getIndividualTimestamp(MORFullIndividual individual) {
        return null;
    }

    @Override
    public boolean getSensorIndivBoolValue(String sensorIndividual, String dataPropName) {
        return false;
    }

    @Override
    public String getDataPropInference(MORFullIndividual individual, String dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty(dataPropName));
        return data.getLiteral();
    }

    public String getDataPropInference(MORFullIndividual individual, OWLDataProperty dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(dataPropName);
        return data.getLiteral();
    }

    @Override
    public String getSensorIndivTimeStamp(String sensorIndividual) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        return getDataPropInference(localIndiv, "hasTimeStamp");
    }

    @Override
    public String getObjPropInference(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    public String getObjPropInference(MORFullIndividual individual, OWLObjectProperty objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }

    @Override
    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectPropertyName);
    }


    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, OWLObjectProperty objectProperty) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        return individual.getObjects(objectProperty);
    }

    @Override
    public OWLReferences getOntoRef() {
        return ontoRef;
    }

    @Override
    public void synchronizeAndSaveOnto() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # synchronizeAndSaveOnto()");

        getOntoRef().synchronizeReasoner();
        getOntoRef().saveOntology(getOntoRef().getFilePath());
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+"\n\n # run()");
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # thread begins");


        /*1*/
//        this.updateBasedOnCurrentSensoryState(ontoToOntoInputMap);
//        this.updateBasedOnMemoryAndTemporalLogic(temporalLogicObjectsList);


        System.out.println("# "+this.getOntoRef().getReferenceName()+" # thread ends\n\n");
    }

    //INTERFACE:    OntoHasMemoryAndInputFromOnto
    public void startWithFreshMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithFreshMemory()");

        this.setFlagUpdateTimeIntervalT1(true);
        Thread thread = new Thread(this);
        thread.start();
    }

    public void startWithOldMemory() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startWithOldMemory()");

        this.setFlagUpdateTimeIntervalT1(false);
        Thread thread = new Thread(this);
        thread.start();
    }

    //INTERFACE:        OntologyHasMemory
    @Override
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startTimeMemoryLogic()");
        /*
        1.
         */
        /*
            t prefix means time
         */

        //Update TimeNow so that it is in the true now.
        //setIndividualWithTimestamp(getIndividual("Time_Now", ontoRef), String.valueOf(new Timestamp(System.currentTimeMillis())));

        //Time Interval T1
        OWLNamedIndividual tIntervalT1NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT1Indiv()); //PERHAPS USE THIS LOGIC TO GET AN INDIVIDUAL ALWAYS
        Timestamp T1TS;

        //Time Interval T2
        OWLNamedIndividual tIntervalT2NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT2Indiv());
        Timestamp T2TS;

        //Time Ontology object properties
        OWLObjectProperty objPropBefore = temporalObj.getTimeOntoRef().getOWLObjectProperty("before");//timeInstant before timeInstant
        OWLObjectProperty objPropAfter = temporalObj.getTimeOntoRef().getOWLObjectProperty("after");//timeInstant after timeInstant
        OWLObjectProperty objPropIntervalContains = temporalObj.getTimeOntoRef().getOWLObjectProperty("intervalContains");//interval contains interval
        OWLObjectProperty objPropHasBeginning = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasBeginning");//timeInterval hasBeginning timeInstant
        OWLObjectProperty objPropHasEnd = temporalObj.getTimeOntoRef().getOWLObjectProperty("hasEnd");//timeInterval hasEnd timeInstant
        OWLDataProperty dataPropHour = temporalObj.getTimeOntoRef().getOWLDataProperty("hour");//hour hold a non-negative integer
        OWLDataProperty dataPropMinute = temporalObj.getTimeOntoRef().getOWLDataProperty("minute");//hour hold a non-negative integer


        //Individual and ObjectProperty given by user
        String tIndiv = temporalObj.recallIndiv(); //Human
        String tObjProp = temporalObj.recallObjProp(); //isUtilizing

//        //Removing All the old before's and after's, so that they do not have influence in the NOW
//        System.out.println(getObjPropInference(tIndivFull, tObjProp)); //THERE CAN BE ONE INFERENCE OF A PARTICULAR FURNITURE
//
//        Set<OWLNamedIndividual> tInferredIndivSet = getObjPropInferences(tIndivFull,tObjProp);
//
//        for (OWLNamedIndividual tInferredIndiv : tInferredIndivSet) {
//
//            MORFullIndividual localIndivFull = new MORFullIndividual(tInferredIndiv, ontoRef);
//            localIndivFull.readSemantic();
//            localIndivFull.removeObject(objPropBefore, tIntervalT1NamedIndiv);
//            localIndivFull.removeObject(objPropAfter, tIntervalT1NamedIndiv);
//            localIndivFull.removeObject(objPropBefore, tIntervalT2NamedIndiv);
//            localIndivFull.removeObject(objPropAfter, tIntervalT2NamedIndiv);
//            localIndivFull.writeSemanticInconsistencySafe();
//        }
//        synchronizeAndSaveOnto(); ------------------------------------> USE THE ABOVE TO MAKE MORE GENERAL CASE LATER

        String tInferredIndivName = getObjPropInference(getIndividual(tIndiv, ontoRef), tObjProp);//'NULL' OR THE PARTICULAR 'FURNITURE' example: A_F_KitchenCabinet
        //If the main ingredient is 'null' then skip the whole thing
        if (!Objects.equals(tInferredIndivName,null)) {

            System.out.println("Inference of '"+tIndiv+"' '"+tObjProp+"' is '"+tInferredIndivName+"', proceeding towards setting temporal logic!");
            MORFullIndividual tInferredIndivFull = getIndividual(tInferredIndivName, ontoRef);

            //Remove if any 'before' and 'after' related to the inferredIndiv
            tInferredIndivFull.readSemantic();
            tInferredIndivFull.removeObject(objPropBefore, tIntervalT1NamedIndiv);
            tInferredIndivFull.removeObject(objPropAfter, tIntervalT1NamedIndiv);
            tInferredIndivFull.removeObject(objPropBefore, tIntervalT2NamedIndiv);
            tInferredIndivFull.removeObject(objPropAfter, tIntervalT2NamedIndiv);
            tInferredIndivFull.writeSemanticInconsistencySafe();

            synchronizeAndSaveOnto();

            //TimeStamp for Inferred Individual obtained by checking its Sensor TimeStamp
            Timestamp tInferredIndivTS;
            String sensorInferredIndiv = getObjPropInference(tInferredIndivFull, "hasFurnitureTheSensor");
            tInferredIndivTS = Timestamp.valueOf(getSensorIndivTimeStamp(sensorInferredIndiv));//getIndividualTimestamp(getIndividual(sensorInferredIndiv, ontoRef)));//ONLY IF THE FURNITURE GOT INFERRED, WILL WE HAVE TS

            //Setting the timeIntervals 'T1' and 'T2' based on startWithFreshMemory() OR startWithOldMemory()
            String T1Name = temporalObj.recallTimeIntervalT1Indiv();//TI_IsIn_Kitchen_BeginTime
            String T2Name = temporalObj.recallTimeIntervalT2Indiv();//TI_IsIn_Kitchen_EndTime
            if (getFlagUpdateTimeIntervalT1()) {
                setSensorIndivTimeStamp(T1Name, String.valueOf(new Timestamp(System.currentTimeMillis())));//Only gets updated for the first time of activation
            }
            setSensorIndivTimeStamp(T2Name, String.valueOf(new Timestamp(System.currentTimeMillis())));//Gets updated every time this ontology is activated
            //WE HAVE 20 SECONDS TO Grab the motion detection of Furniture

            if (Objects.equals(T1Name, null)) {

                T2TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T2Name, ontoRef)));

                if (tInferredIndivTS.before(T2TS)) {
                    tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                    tInferredIndivFull.writeSemantic();
                } else {
                    System.out.println("The TS of inferredIndiv is after timeInterval T2");
                }
            } else if (Objects.equals(T2Name, null)) {

                T1TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T1Name, ontoRef)));
                if (tInferredIndivTS.after(T1TS)) {

                    tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                    tInferredIndivFull.writeSemantic();
                } else {

                    System.out.println("The TS of inferredIndiv is before timeInterval T1");
                }
            } else if (Objects.equals(T1Name, null) & Objects.equals(T2Name, null)) {

                System.out.println("The inferredIndiv is not limited to the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
            } else if (Objects.equals(T1Name, T2Name)) {

                T1TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T1Name, ontoRef)));
                if (tInferredIndivTS.after(T1TS)) {

                    tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                    tInferredIndivFull.writeSemantic();

                    Set<OWLNamedIndividual> bigIntervalSet = getObjPropInferences(getIndividual(temporalObj.recallIndivHoldingBigTimeIntervals(),ontoRef),objPropIntervalContains);
                    for (OWLNamedIndividual bigInterval:bigIntervalSet) {

                        MORFullIndividual bigIntervalIndiv = getIndividual(bigInterval, ontoRef);

                        String bigIntervalBeginTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropHour);
                        String bigIntervalBeginTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropMinute);

                        String bigIntervalEndTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropHour);
                        String bigIntervalEndTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropMinute);

                        //BE CAREFUL HERE: WHILE TESTING ALONG THE OpenHAB23/24 DATA-SET, the following if-conditions will not be satisfied.
                        Date date = new Date();
                        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
                        Timestamp bigIntervalBeginTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalBeginTimeHour + ":" + bigIntervalBeginTimeMinute + ":00");
                        Timestamp bigIntervalEndTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalEndTimeHour + ":" + bigIntervalEndTimeMinute + ":00");

                        if (tInferredIndivTS.after(bigIntervalBeginTime) & tInferredIndivTS.before(bigIntervalEndTime)) {
                            bigIntervalIndiv.addObject(objPropIntervalContains, ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));
                        } else {
                            System.out.println("The bigInterval '" + bigInterval + "' does not contain interval '" + temporalObj.recallTimeIntervalIndiv() + "'");
                        }
                    }
                }
            } else if (!Objects.equals(T1Name, T2Name)) {

                T1TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T1Name, ontoRef)));
                T2TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T2Name, ontoRef)));

                if (T1TS.before(T2TS)) {
                    if (tInferredIndivTS.after(T1TS)&tInferredIndivTS.before(T2TS)) {

                        tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                        tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                        tInferredIndivFull.writeSemantic();

                        Set<OWLNamedIndividual> bigIntervalSet = getObjPropInferences(getIndividual(temporalObj.recallIndivHoldingBigTimeIntervals(),ontoRef),objPropIntervalContains);
                        for (OWLNamedIndividual bigInterval:bigIntervalSet) {

                            MORFullIndividual bigIntervalIndiv = getIndividual(bigInterval, ontoRef);

                            String bigIntervalBeginTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropHour);
                            String bigIntervalBeginTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasBeginning), ontoRef), dataPropMinute);

                            String bigIntervalEndTimeHour = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropHour);
                            String bigIntervalEndTimeMinute = getDataPropInference(getIndividual(getObjPropInference(bigIntervalIndiv, objPropHasEnd), ontoRef), dataPropMinute);

                            //BE CAREFUL HERE: WHILE TESTING ALONG THE OpenHAB23/24 DATA-SET, the following if-conditions will not be satisfied.
                            Date date = new Date();
                            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
                            Timestamp bigIntervalBeginTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalBeginTimeHour + ":" + bigIntervalBeginTimeMinute + ":00");
                            Timestamp bigIntervalEndTime = Timestamp.valueOf(sdfDate.format(date) + " " + bigIntervalEndTimeHour + ":" + bigIntervalEndTimeMinute + ":00");

                            if (tInferredIndivTS.after(bigIntervalBeginTime) & tInferredIndivTS.before(bigIntervalEndTime)) {
                                bigIntervalIndiv.addObject(objPropIntervalContains, ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalIndiv()));
                                bigIntervalIndiv.writeSemantic();
                            } else {
                                System.out.println("The bigInterval '" + bigInterval + "' does not contain interval '" + temporalObj.recallTimeIntervalIndiv() + "'");
                            }
                        }
                    }
                }
            }
        } else {
            System.out.println("Inference of '"+tIndiv+"' '"+tObjProp+"' is NULL, hence cannot place it in defined interval");
        }
    }

    @Override
    public void updateBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnMemoryAndTemporalLogic()");

        for (TemporalLogic timeMemObj:temporalLogicForMemoryList) {
            startTimeMemoryLogic(timeMemObj);
            synchronizeAndSaveOnto();
        }
    }

    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        if (checkHasDuration) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    public void setFlagUpdateTimeIntervalT1(boolean bool) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setFlagUpdateTimeIntervalT1()");

        flagUpdateTimeIntervalT1 = bool;
    }

    @Override
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj, Boolean checkWhetherInTheIntervals) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        flagTimeIntervalIsInAnotherInterval = checkWhetherInTheIntervals;
        if (checkHasDuration&checkWhetherInTheIntervals) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }

    @Override
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {

    }

    @Override
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {

    }

    @Override
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return false;
    }

    @Override
    public boolean getFlagActivateTemporalLogic() {
        return false;
    }

    public boolean getFlagTimeIntervalIsInAnotherInterval() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagTimeIntervalIsInAnotherInterval()");

        return flagTimeIntervalIsInAnotherInterval;
    }

    public boolean getFlagUpdateTimeIntervalT1() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getFlagUpdateTimeIntervalT1()");

        return flagUpdateTimeIntervalT1;
    }

    //INTERFACE:            CommitToMemory
    @Override
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {

    }

    @Override
    public void checkInferenceToActivateTemporalLogic(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith) {

    }
    //INTERFACE:            RecallFromMemory
    @Override
    public String recallObjPropToActivateTemporalLogic() {
        return null;
    }

    @Override
    public String recallIndivToActivateTemporalLogic() {
        return null;
    }

    ////////--> Updating ontology with a given frequency

    //NONE

    ///////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventListenerOntology
    public void setActivationCondition(String individualA, String objectProperty, String individualB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setActivationCondition()");

        eventIndivA = individualA;
        eventObjProp = objectProperty;
        eventIndivB = individualB;
    }
    public String getEventActivationConditionIndivA(){
        return eventIndivA;
    }
    public String getEventActivationConditionObjProp(){
        return eventObjProp;
    }
    public String getEventActivationConditionIndivB(){
        return eventIndivB;
    }

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    //INTERFACE: OntoReceivesIndividualsFromOnto
    @Override
    public void setInputLinkFromOntoToOnto(String sensorIndividual,OntologyPrototype ontologyObject) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setInputLinkFromOntoToOnto()");
        ontoToOntoInputMap.put(sensorIndividual,ontologyObject);
    }

    @Override
    public void startInputFromOntoToOnto(Map<String, OntologyPrototype> ontoToOntoInputMap) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startInputFromOntoToOnto()");

        Set<String> sensorIndividualSet = ontoToOntoInputMap.keySet();
        for (String sensorIndividual:sensorIndividualSet) {
            OntologyPrototype ontoObj = ontoToOntoInputMap.get(sensorIndividual);
            System.out.println("# Transferring all data of Individual '"+sensorIndividual+"' from '"+ontoObj.getOntoRef().getReferenceName()+"' to '"+this.getOntoRef().getReferenceName()+"'");
            boolean boolValue = ontoObj.getSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue");
            this.setSensorIndivBoolValue(sensorIndividual,"hasMotionBoolValue", boolValue);
            String timestamp = ontoObj.getSensorIndivTimeStamp(sensorIndividual);
            this.setSensorIndivTimeStamp(sensorIndividual,timestamp);
            synchronizeAndSaveOnto();
        }
    }

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //INTERFACE: MySqlDBOutputLink
    @Override
    public void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_table_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setMySqlDBOutputInfo()");

        Activity_DataBase_Name = Activity_database_Name;
        Activity_Table_Name = Activity_table_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    @Override
    public void setOutputLinkFromOntoToDB(String individualName, String objPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setOutputLinkFromOntoToDB()");

        indivForOutputToDB = individualName;
        objPropForOutputToDB = objPropName;
    }

    @Override
    public void startOutputFromOntoToDB() {

    }
}
