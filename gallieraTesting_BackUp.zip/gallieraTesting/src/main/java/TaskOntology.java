import java.util.ArrayList;
import java.util.List;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology1
 *       Fundamentally it is the spatial-temporal context of a person in a Room, designed considering the behaviour of the Hardware.
 * Why: For the inference of "isStillIn" [Domian:Person, Range:Room]
 * How: This TaskOntology is listening for "isBeingIn" [Domian:Person, Range:Room] from the PlacingOntology.
 *      It is also a PlacingOntology EventListener.
 */
public class TaskOntology implements TaskOntologyPrototype {

    List<OntologyEventListener> eventListenersList = new ArrayList<>();

    String Activity_DataBase_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;

    String evIndvidualA;
    String evObjectProperty;
    String evIndividualB;

//    boolean eventLivingRoomFlag = false;
//    boolean eventTableAreaFlag = false;
//    boolean eventKitchenFlag = false;
//    boolean eventBedRoomFlag = false;
//    boolean eventBathRoomFlag = false;

    public void startListener(){
        Thread thread = new Thread();
        thread.start();
    }

    @Override
    public void run() {
        //Procedure
        System.out.println("TO1 thread begins, ID:" + Thread.currentThread().getId());
        System.out.println("Task Ontology Running");
        System.out.println("TO1 thread ends, ID:" + Thread.currentThread().getId());
    }

    @Override
    public void setEventListener(OntologyEventListener EventListener) {

        eventListenersList.add(EventListener);
        System.out.println("Listener Added!");
    }

    @Override
    public void outputMySqlDBDescription(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {

        Activity_DataBase_Name = Activity_database_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    @Override
    public void setEventActivationCondition(String individualA, String objectProperty, String individualB) {

        evIndvidualA = individualA;
        evObjectProperty = objectProperty;
        evIndividualB = individualB;
    }

    public String getEventActivationConditionIndivA(){
        return evIndvidualA;
    }

    public String getEventActivationConditionObjProp(){
        return evObjectProperty;
    }

    public String getEventActivationConditionIndivB(){
        return evIndividualB;
    }

//    @Override
//    public void InitiateListener_eventLivingRoom() {
//        if (this.eventLivingRoomFlag) {
//            Thread thread = new Thread(this);
//            thread.start();
//        }
//    }
//
//    @Override
//    public void InitiateListener_eventTableArea() {
//        if (this.eventLivingRoomFlag) {
//            Thread thread = new Thread(this);
//            thread.start();
//        }
//    }
//
//    @Override
//    public void InitiateListener_eventKitchen() {
//        if (this.eventLivingRoomFlag) {
//            Thread thread = new Thread(this);
//            thread.start();
//        }
//    }
//
//    @Override
//    public void InitiateListener_eventBedRoom() {
//        if (this.eventLivingRoomFlag) {
//            Thread thread = new Thread(this);
//            thread.start();
//        }
//    }
//
//    @Override
//    public void InitiateListener_eventBathRoom() {
//        if (this.eventLivingRoomFlag) {
//            Thread thread = new Thread(this);
//            thread.start();
//        }
//    }
//
//    @Override
//    public void InitiateListener_eventIsStillIn(String nameOfTheFurnitureOccupied) {
//        //Do nothing
//    }
//
//    @Override
//    public void ListensFor_eventLivingRoom() {
//        this.eventLivingRoomFlag = true;
//    }
//
//    @Override
//    public void ListensFor_eventTableArea() {
//        this.eventTableAreaFlag = true;
//    }
//
//    @Override
//    public void ListensFor_eventKitchen() {
//        this.eventKitchenFlag = true;
//    }
//
//    @Override
//    public void ListensFor_eventBedRoom() {
//        this.eventBedRoomFlag = true;
//    }
//
//    @Override
//    public void ListensFor_eventBathRoom() {
//        this.eventBathRoomFlag = true;
//    }
//
//    @Override
//    public void ListensFor_eventIsStillIn() {
//        //Do nothing
//    }

}
