import java.sql.*;

/**
 * Created by yushakareem on 24/07/17.
 */

public class MySQLConnector implements MySQLConnectorPrototype {
//    public void writeResultSet(ResultSet resultSet) throws SQLException {
//        while(resultSet.next()){
//
//            ts = resultSet.getTimestamp("time");
//            //Date ts = resultSet.getDate("time");
//            //Time ts = resultSet.getTime("time");
//            value = resultSet.getInt("value");
//            //System.out.println(ts);
//            //System.out.println(value);
//            System.out.println(ts + " | " + value + "Hmmm");
//        }
//    }

    static Connection conn;
    static Statement stmt;
    static ResultSet rs;

    Timestamp ts;
    boolean value;

    @Override
    public void initiateDBConnection(String DataBase_Name,String MySQL_UserName,String MySQL_Password) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Cannot find jdbc driver");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase_Name+"?autoReconnect=true&verifyServerCertificate=false&useSSL=true",MySQL_UserName,MySQL_Password);
        } catch (SQLException e) {
            System.out.println("problem with DB/user/password");
        }
    }

    //Selects recent data from the table for the Item in parameter
    @Override
    public void readItemLatest(String Item_Name_In_DB){

        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println("MySQL Making statement problem");
        }
        try {
            rs = stmt.executeQuery("select * from "+Item_Name_In_DB+" order by time desc limit 1");
        } catch (SQLException e) {
            System.out.println("MySQL Making query problem");
        }
        try {
            while(rs.next()) {
                ts = rs.getTimestamp("time");
                value = rs.getBoolean("value");
            }
        } catch (SQLException e) {
            System.out.println("MySQL getting Item TimeStamp/Value problem");
        }
    }

    @Override
    public void readItemWithCustomQuery(String MySQLQuery) throws SQLException {

        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println("MySQL Making statement problem");
        }
        try {
            rs = stmt.executeQuery(MySQLQuery);
        } catch (SQLException e) {
            System.out.println("MySQL Making query problem");
        }
        try {
            while(rs.next()) {
                ts = rs.getTimestamp("time");
                value = rs.getBoolean("value");
            }
        } catch (SQLException e) {
            System.out.println("MySQL getting Item TimeStamp/Value problem");
        }
    }

    public Timestamp getItemTimeStamp(){
        return ts;
    }

    public Boolean getItemValue(){
        return value;
    }

    @Override
    public void endDBConnection() {

        //Closing -  need to close
        if(rs != null){
            try {
                rs.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing RESULT STATEMENT");
            }
        }
        if(stmt != null){
            try {
                stmt.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing STATEMENT");
            }
        }
        if(conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing CONNECTION");
            }
        }
    }
}