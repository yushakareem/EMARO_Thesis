import java.sql.*;

/**
 * Created by yushakareem on 24/07/17.
 */

public class MySQLConnector implements MySQLConnectorPrototype {
//    public void writeResultSet(ResultSet resultSet) throws SQLException {
//        while(resultSet.next()){
//
//            ts = resultSet.getTimestamp("time");
//            //Date ts = resultSet.getDate("time");
//            //Time ts = resultSet.getTime("time");
//            value = resultSet.getInt("value");
//            //System.out.println(ts);
//            //System.out.println(value);
//            System.out.println(ts + " | " + value + "Hmmm");
//        }
//    }

    static Connection conn;
    static Statement stmt;
    static ResultSet rs;

    Timestamp ts;
    boolean value;

    @Override
    public void startDBConnection(String DataBase_Name, String MySQL_UserName, String MySQL_Password) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Cannot find jdbc driver");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase_Name+"?autoReconnect=true&verifyServerCertificate=false&useSSL=true",MySQL_UserName,MySQL_Password);
        } catch (SQLException e) {
            System.out.println("Unable to connect with MySQL DB: Please check DB_Name OR User_Name OR Password");
        }
    }

    @Override
    public void startDBConnectionOrCreateNew(String New_DataBase_Name, String MySQL_UserName, String MySQL_Password) {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Cannot find jdbc driver");
        }
        try {
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+New_DataBase_Name+"?autoReconnect=true&verifyServerCertificate=false&useSSL=true",MySQL_UserName,MySQL_Password);
            System.out.println("DataBase with the name:"+New_DataBase_Name+" already exists. Making connection.");
        } catch (SQLException e) {
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/?autoReconnect=true&verifyServerCertificate=false&useSSL=true",MySQL_UserName,MySQL_Password);
            } catch (SQLException e1) {
                System.out.println("Unable to connect with MySQL: Please check User_Name OR Password");
            }
            try {
                stmt = conn.createStatement();
            } catch (SQLException e1) {
                System.out.println("Problem in creating statement for 'startDBConnectionOrCreateNew'");
            }
            try {
                stmt.executeUpdate("CREATE DATABASE "+New_DataBase_Name);
                stmt.executeUpdate("USE DATABASE "+New_DataBase_Name);
            } catch (SQLException e1) {
                System.out.println("Problem in creating new DataBase!");
            }
        }
    }

    @Override
    public void getFromTableLatest(String Table_Name_In_DB){

        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println("MySQL Making statement problem");
        }
        try {
            rs = stmt.executeQuery("select * from "+Table_Name_In_DB+" order by time desc limit 1");
        } catch (SQLException e) {
            System.out.println("MySQL Making query problem");
        }
        try {
            while(rs.next()) {
                ts = rs.getTimestamp("time");
                value = rs.getBoolean("value");
            }
        } catch (SQLException e) {
            System.out.println("MySQL getting Item TimeStamp/Value problem");
        }
    }

    @Override
    public void getFromTableWithCustomQuery(String MySQLQuery) {

        try {
            stmt = conn.createStatement();
        } catch (SQLException e) {
            System.out.println("MySQL Making statement problem");
        }
        try {
            rs = stmt.executeQuery(MySQLQuery);
        } catch (SQLException e) {
            System.out.println("MySQL Making query problem");
        }
        try {
            while(rs.next()) {
                ts = rs.getTimestamp("time");
                value = rs.getBoolean("value");
            }
        } catch (SQLException e) {
            System.out.println("MySQL getting Item TimeStamp/Value problem");
        }
    }

    public Timestamp getItemTimeStamp(){
        return ts;
    }

    public Boolean getItemValue(){
        return value;
    }

    @Override
    public void putIntoTable(String Table_Name_InDB, String timeStamp, String stringValue) {}

    @Override
    public void stopDBConnection() {

        //Closing -  need to close
        if(rs != null){
            try {
                rs.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing RESULT STATEMENT");
            }
        }
        if(stmt != null){
            try {
                stmt.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing STATEMENT");
            }
        }
        if(conn != null){
            try {
                conn.close();
            } catch (SQLException e) {
                System.out.println("Problem in closing CONNECTION");
            }
        }
    }
}