import java.sql.*;

/**
 * Created by yushakareem on 24/07/17.
 */

public class MySQLConnector implements MySQLConnectorPrototype {
//    public void writeResultSet(ResultSet resultSet) throws SQLException {
//        while(resultSet.next()){
//
//            ts = resultSet.getTimestamp("time");
//            //Date ts = resultSet.getDate("time");
//            //Time ts = resultSet.getTime("time");
//            value = resultSet.getInt("value");
//            //System.out.println(ts);
//            //System.out.println(value);
//            System.out.println(ts + " | " + value + "Hmmm");
//        }
//    }

    Connection conn;
    Statement stmt;
    ResultSet rs;

    Timestamp ts;
    Integer value;

    @Override
    public void initiateDBConnection(String DataBase_Name,String MySQL_UserName,String MySQL_Password) throws ClassNotFoundException, SQLException {

        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/"+DataBase_Name+"?autoReconnect=true&verifyServerCertificate=false&useSSL=true",MySQL_UserName,MySQL_Password);
    }

    //Selects recent data from the table for the Item in parameter
    @Override
    public void readItemLatest(String Item_Name_In_DB) throws SQLException {

        stmt = conn.createStatement();
        rs = stmt.executeQuery("select * from "+Item_Name_In_DB+" order by time desc limit 1");
        ts = rs.getTimestamp("time");
        value = rs.getInt("value");
    }

    @Override
    public void readItemWithCustomQuery(String MySQLQuery) throws SQLException {

        stmt = conn.createStatement();
        rs = stmt.executeQuery(MySQLQuery);
        ts = rs.getTimestamp("time");
        value = rs.getInt("value");
    }

    public Timestamp getItemTimeStamp(){
        return ts;
    }

    public Integer getItemValue(){
        return value;
    }

    @Override
    public void endDBConnection() throws SQLException {

        //Closing -  need to close
        if(rs != null){
            rs.close();
        }
        if(stmt != null){
            stmt.close();
        }
        if(conn != null){
            conn.close();
        }
    }
}