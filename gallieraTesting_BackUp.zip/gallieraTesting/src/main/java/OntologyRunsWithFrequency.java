import java.util.concurrent.TimeUnit;

public interface OntologyRunsWithFrequency {

    void scheduleOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize);
}
