import java.util.List;

public interface EventInitiator {

    void hasEventListener(TaskOntology eventListener);
    void inferAndTriggerEvents(List<TaskOntology> listOfeventListeners);
    boolean checkEventActivationCondition(TaskOntology objectOfTO);
}
