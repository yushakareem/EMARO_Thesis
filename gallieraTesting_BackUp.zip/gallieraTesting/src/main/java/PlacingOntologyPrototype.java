import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;

/**
 *  Sensor -> Individual in Ontology
 *  Sensor -> Item in MySqlDB
 */

public interface PlacingOntologyPrototype extends OntologyPrototype,MySqlDBInputLink,OntologyRunsWithFrequency,EventInitiator {

}
