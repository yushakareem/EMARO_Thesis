import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;

import java.util.concurrent.TimeUnit;

/**
 *  Sensor -> Individual in Ontology
 *  Sensor -> Item in MySqlDB
 */

public interface PlacingOntologyPrototype extends MySQLDBLink, OntologyRunsWithFrequency, Runnable {

    void attachIndividualWithItem(String Sensor_IndividualName_InOntology,String Sensor_ItemName_InDataBase);
}
