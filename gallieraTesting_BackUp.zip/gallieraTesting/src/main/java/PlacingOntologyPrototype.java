/**
 *  Sensor -> Individual in Ontology
 *  Sensor -> Item in MySqlDB
 */

public interface PlacingOntologyPrototype extends OntologyPrototype,MySqlDBInputLink,OntologyRunsWithFrequency, EventInitiatorOntology {

}
