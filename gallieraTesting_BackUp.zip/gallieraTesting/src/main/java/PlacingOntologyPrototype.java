import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;

/**
 *  Sensor -> Individual in Ontology
 *  Sensor -> Item in MySqlDB
 */

public interface PlacingOntologyPrototype extends MySqlDBInputLink, OntologyRunsWithFrequency, Runnable {

    void hasEventListener(TaskOntology eventListener);
    void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase);
    MORFullIndividual getIndividual(String Sensor_IndividualName_InOntology, OWLReferences ontoRef);
    String getOntoReferenceName();
}
