import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;

/**
 *  Sensor -> Individual in Ontology
 *  Sensor -> Item in MySqlDB
 */

public interface PlacingOntologyPrototype extends MySqlDBInputLink, OntologyRunsWithFrequency, Runnable, MySqlDBOutputLink {

    void setEventListener(OntologyEventListener POeventListener);
    void connectIndividualWithSensorItemInDB(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase);
    MORFullIndividual makeIndividualFromString(String Sensor_IndividualName_InOntology, OWLReferences ontoRef);
}
