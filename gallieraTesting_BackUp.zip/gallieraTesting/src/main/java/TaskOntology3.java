/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology3
 *       The spatial-temporal context of a person being in Kitchen and making Breakfast/Lunch/Dinner
 * Why: For the inference of ("isDoingActivity" - "Making_Breakfast/Lunch/Dinner") [Domian:Person, Range:Activity]
 * How: This TaskOntology is listening for "isStillIn" [P_Habitant_1, Kitchen] from TO1 and
 *      will be taking interesting/specific individuals from PO.
 *      It is also a PlacingOntology EventListener.
 */


/**
 * Modify How .. later.
 * Because the idea is to listen to PO and wait for a 'shared resource' from TO1 (ie. that person isStillIn Kitchen)
 */

public class TaskOntology3 extends Thread implements OntologyEventListener {

    @Override
    public void beginTaskOntology_LivingRoom() {}
    public void beginTaskOntology_TableArea() {}
    public void beginTaskOntology_Kitchen() {
        Thread thread = new Thread(this);
        thread.start();
    }
    public void beginTaskOntology_BedRoom() {}
    public void beginTaskOntology_BathRoom() {}

    @Override
    public void run() {
        //Procedure
        System.out.println("Task Ontology 3 Running");
    }
}
