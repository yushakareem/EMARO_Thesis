import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

public interface OntologyPrototype extends OntologyHasMemory,Runnable {

    void setIndividualWithTimestamp(MORFullIndividual individual, Timestamp timeStamp);

    void synchronizeAndSaveOnto();

    void modifyBasedOnCurrentSensoryState(List<String> sensorItemsInDBList);

    MORFullIndividual getIndividual(String Sensor_IndividualName_InOntology, OWLReferences ontoRef);
    Timestamp getIndividualTimestamp(MORFullIndividual individual);
    String getInference(MORFullIndividual individual, String objectPropertyName);
    Set<OWLNamedIndividual> getInferencesOWLNamedIndividual(MORFullIndividual individual, String objectPropertyName);
    OWLReferences getOntoRef();
}
