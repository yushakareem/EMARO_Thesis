public interface CommitToMemory {

    void commitToActivateTemporalLogic(String individualName, String objPropName);
    void checkInferenceToActivateTemporalLogic(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith);
}
