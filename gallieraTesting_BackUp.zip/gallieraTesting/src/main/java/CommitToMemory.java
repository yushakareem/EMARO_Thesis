public interface CommitToMemory {

    void commitToActivateTemporalLogic(String individualName, String objPropName);
    void commitInferenceOf(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith);
}
