import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;

import java.util.Objects;

public class TemporalLogic implements OntologyHasTemporalLogic {

    String indiv;
    String objProp;

    String timeLogicBiggerTimeIntervalIndiv;
    String objPropForIntervalCheck;

    String timeLogicInterval;
    String timeLogicT1Indiv;
    String timeLogicT2Indiv;

    PlacingOntology objOfIncomingOnto;

    OWLReferences timeOntoRef;

    // REMOVE THE FIRST PARAMETER OF PLACING ONTOLOGY .. NOT USED
    public TemporalLogic(PlacingOntology ontoObjToMergeWithTimeOnto,String timeOntoRefName,String timeOntoFilePath,String timeOntoPath,boolean timeOntoBufferingReasoner) {
        System.out.println("# TL # TemporalLogic()");
        objOfIncomingOnto = ontoObjToMergeWithTimeOnto;

        timeOntoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                timeOntoRefName,
                timeOntoFilePath,
                timeOntoPath,
                timeOntoBufferingReasoner
        );
    }

    public Boolean hasDuration(boolean inference, String comparativeOperator, int positiveIntTimeDuration) {
        System.out.println("# TL # hasDuration()");
//        if (comparativeOperator.equals("=") & positiveIntTimeDuration == 0) {
//
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInstant");
//        } else if (comparativeOperator.equals("<")) {
//
//            System.out.println("'<' operator not assigned any work YET!");
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInterval");
//        } else if (comparativeOperator.equals(">")) {
//
//            System.out.println("'>' operator not assigned any work YET!");
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInterval");
//        }
        if (inference) {
            System.out.println("TemporalLogic: This timeMemObj has a definition for hasDuration (comparative operator and poisitiveTimeDuration)");
        }
        return true;
    }


    public TemporalLogic inTimeInterval(String indivNameTimeInstantT1, String indivNameTimeInstantT2) {
        System.out.println("# TL # inTimeInterval()");
        if (!Objects.equals(indivNameTimeInstantT1,null)){
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'After' the 'time-instant' -> "+indivNameTimeInstantT1);
        } else if (!Objects.equals(indivNameTimeInstantT2,null)){
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'Before' the 'time-instant' -> "+indivNameTimeInstantT2);
        } else {
            System.out.println("TemporalLogic: Time Interval not defined");
        }
        this.timeLogicT1Indiv = indivNameTimeInstantT1;
        this.timeLogicT2Indiv = indivNameTimeInstantT2;
        return this;
    }

    public TemporalLogic inTimeInterval(String indivNameTimeInterval, String indivNameTimeInstantT1, String indivNameTimeInstantT2) {
        System.out.println("# TL # inTimeInterval()");
        if (!Objects.equals(indivNameTimeInstantT1,null)){
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'After' the 'time-instant' -> "+indivNameTimeInstantT1);
        } else if (!Objects.equals(indivNameTimeInstantT2,null)){
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'Before' the 'time-instant' -> "+indivNameTimeInstantT2);
        } else {
            System.out.println("TemporalLogic: Time Interval not defined");
        }
        this.timeLogicT1Indiv = indivNameTimeInstantT1;
        this.timeLogicT2Indiv = indivNameTimeInstantT2;
        this.timeLogicInterval = indivNameTimeInterval;
        return this;
    }

    public Boolean timeIntervalInBiggerTimeInterval(String indivHoldingBigTimeIntervals) {
        System.out.println("# TL # timeIntervalInBiggerTimeInterval()");
        boolean flag = false;
        if (!Objects.equals(indivHoldingBigTimeIntervals,null)) {
            this.timeLogicBiggerTimeIntervalIndiv = indivHoldingBigTimeIntervals;
            flag = true;
        }
        return flag;
    }

    public boolean inferenceOf(String desiredIndivName, String desiredObjPropName) {
        System.out.println("# TL # inferenceOf()");
        boolean flag = false;
        if (!Objects.equals(desiredIndivName,null)&!Objects.equals(desiredObjPropName,null)) {
            this.indiv = desiredIndivName;
            this.objProp = desiredObjPropName;
            flag = true;
        } else {
            System.out.println("TemporalLogic: Proper parameters not entered for hasDuration(inferenceOf(___,___),,)");
        }
        return flag;
    }


    public String recallIndiv() {
        System.out.println("# TL # recallIndiv()");
        return indiv;}

    public String recallObjProp() {
        System.out.println("# TL # recallObjProp()");
        return objProp;}

    public String recallTimeIntervalT1Indiv() {
        System.out.println("# TL # recallTimeIntervalT1Indiv()");
        return timeLogicT1Indiv;
    }

    public String recallTimeIntervalT2Indiv() {
        System.out.println("# TL # recallTimeIntervalT2Indiv()");
        return timeLogicT2Indiv;
    }

    public String recallTimeIntervalIndiv() {
        System.out.println("# TL # recallIndivHoldingBigTimeIntervals()");

        return timeLogicInterval;
    }

    public String recallIndivHoldingBigTimeIntervals() {
        System.out.println("# TL # recallIndivHoldingBigTimeIntervals()");

        return timeLogicBiggerTimeIntervalIndiv;
    }

    public OWLReferences getTimeOntoRef() {
        System.out.println("# TL # getTimeOntoRef()");
        return timeOntoRef;}

//    public Boolean timeIntervalInBiggerTimeInterval(String individualName, String objPropName) {
//        System.out.println("# TL # timeIntervalInBiggerTimeInterval");
//        boolean flag = false;
//        if (!Objects.equals(individualName,null)&!Objects.equals(objPropName,null)) {
//            timeLogicBiggerTimeIntervalIndiv = individualName;
//            objPropForIntervalCheck = objPropName;
//            flag = true;
//        }
//        return flag;
//    }
}
