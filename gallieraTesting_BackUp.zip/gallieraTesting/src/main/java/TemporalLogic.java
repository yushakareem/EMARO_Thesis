import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;

import java.util.Objects;

public class TemporalLogic {

    String desiredIndivForComp;
    String desiredObjPropForComp;

    String timeLogicT1Indiv;
    String timeLogicT2Indiv;

    PlacingOntology objOfIncomingOnto;

    OWLReferences timeOntoRef;

    public TemporalLogic(PlacingOntology ontoObjToMergeWithTimeOnto,String timeOntoRefName,String timeOntoFilePath,String timeOntoPath,boolean timeOntoBufferingReasoner) {

        objOfIncomingOnto = new PlacingOntology(
                ontoObjToMergeWithTimeOnto.getOntoRef().getReferenceName(),
                ontoObjToMergeWithTimeOnto.getOntoRef().getFilePath(),
                ontoObjToMergeWithTimeOnto.getOntoRef().getOntologyPath(),
                ontoObjToMergeWithTimeOnto.getOntoRef().getOWLEnquirerReasoningFlag()
        );

        timeOntoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                timeOntoRefName,
                timeOntoFilePath,
                timeOntoPath,
                timeOntoBufferingReasoner
        );
    }

    public Boolean hasDuration(boolean inference, String comparativeOperator, int positiveIntTimeDuration) {
        System.out.println("############# hasDuration() #############");
//        if (comparativeOperator.equals("=") & positiveIntTimeDuration == 0) {
//
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInstant");
//        } else if (comparativeOperator.equals("<")) {
//
//            System.out.println("'<' operator not assigned any work YET!");
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInterval");
//        } else if (comparativeOperator.equals(">")) {
//
//            System.out.println("'>' operator not assigned any work YET!");
//            System.out.println("The individual (type:'time-entity'): '" + inferenceOf + "' is a timeInterval");
//        }
        if (inference) {
            System.out.println("This timeMemObj has a definition for hasDuration (comparative operator and poisitiveTimeDuration)");
        }
        return true;
    }


    public TemporalLogic inTimeInterval(String individualNameWithT1, String individualNameWithT2) {
        System.out.println("############# inTimeInterval() #############");
        if (!Objects.equals(individualNameWithT1,null)){
            timeLogicT1Indiv = individualNameWithT1;
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'After' the 'time-instant' -> "+individualNameWithT1);
        } else {
            timeLogicT1Indiv = individualNameWithT1;
        }
        if (!Objects.equals(individualNameWithT2,null)){
            timeLogicT2Indiv = individualNameWithT2;
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'Before' the 'time-instant' -> "+individualNameWithT2);
        } else {
            timeLogicT2Indiv = individualNameWithT2;
        }
        return this;
    }

    public boolean inferenceOf(String desiredIndivName, String desiredObjPropName) {

        boolean flag = false;
        if (!Objects.equals(desiredIndivName,null)&!Objects.equals(desiredObjPropName,null)) {
            this.desiredIndivForComp = desiredIndivName;
            this.desiredObjPropForComp = desiredObjPropName;
            flag = true;
        } else {
            System.out.println("Proper parameters not entered for hasDuration(inferenceOf(___,___),,)");
        }
        return flag;
    }


    public String recallIndiv() {return desiredIndivForComp;}

    public String recallObjProp() {return desiredObjPropForComp;}

    public String recallTimeIntervalT1() {
        return timeLogicT1Indiv;
    }

    public String recallTimeIntervalT2() {
        return timeLogicT2Indiv;
    }

    public OWLReferences getTimeOntoRef() {return timeOntoRef;}
}
