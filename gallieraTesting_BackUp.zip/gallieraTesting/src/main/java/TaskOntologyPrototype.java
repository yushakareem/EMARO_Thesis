public interface TaskOntologyPrototype extends MySqlDBOutputLink, Runnable {

    void hasEventListener(OntologyEventListener EventListener);
    void setActivationCondition(String individualA, String objectProperty, String individualB);
    String getOntoReferenceName();
}
