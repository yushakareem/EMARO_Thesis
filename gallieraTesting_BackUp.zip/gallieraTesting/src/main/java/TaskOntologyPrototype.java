public interface TaskOntologyPrototype extends MySqlDBOutputLink, Runnable {

    void setEventListener(OntologyEventListener EventListener);
    void setEventActivationCondition(String individualA, String objectProperty, String individualB);
}
