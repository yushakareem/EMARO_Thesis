public interface TaskOntologyPrototype extends Runnable {

    void setEventListener(OntologyEventListener EventListener);
    void outputMySqlDBDescription(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password);
    void setEventActivationCondition(String individualA, String objectProperty, String individualB);
}
