public interface TaskOntologyPrototype extends OntologyEventListener, Runnable {

    void addEventListener(OntologyEventListener addListener);
}
