import java.util.List;

public interface OntologyHasMemory extends CommitToMemory,RecallFromMemory {

    void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj);
    void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj, Boolean checkWhetherInTheIntervals);
    void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic);
    void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic);

    boolean getFlagExistsKnowledgeToActivateTemporalLogic();
    boolean getFlagActivateTemporalLogic();

    void startTimeMemoryLogic(TemporalLogic temporalObj);

    void updateBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList);
}
