import java.util.List;

public interface OntologyHasMemory extends CommitToMemory,RecallFromMemory {

    void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj);
    void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic);
    void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic);

    boolean getFlagExistsKnowledgeToActivateTemporalLogic();
    boolean getFlagActivateTemporalLogic();

    void startTimeMemoryLogic(TemporalLogic temporalObj);

    void modifyBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList);
}
