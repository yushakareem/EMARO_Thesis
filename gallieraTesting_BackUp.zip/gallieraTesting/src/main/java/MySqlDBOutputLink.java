public interface MySqlDBOutputLink {

    void outputMySqlDBDescription(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password);
    void stringOutputToDB_ResultOfReason(String individual_A_NameInOntology, String objectPropertyRelating_individuals);
    void booleanOutputToDB_ResultOfReason(String individual_A_NameInOntology, String objectPropertyRelating_AandB, String individual_B_NameInOntology);
}
