/**
 * Created by yushakareem on 24/07/17.
 *
 * What: TaskOntology2
 *       Fundamentally it is the spatial-temporal context of a person in LivingRoom and is watchingTV
 * Why: For the inference of ("isDoingActivity" - "WatchingTV") [Domian:Person, Range:Activity]
 * How: This TaskOntology is listening for "isStillIn" [P_Habitant_1, LivingRoom] from TO1 and
 *      will be taking interesting/specific individuals from PO.
 *      It is also a PlacingOntology EventListener.
 */

/**
 * Modify How .. later.
 * Because the idea is to listen to PO and wait for a 'shared resource' from TO1 (ie. that person isStillIn LivingRoom)
 */

public class TaskOntology2 implements TaskOntologyPrototype {

    @Override
    public void Event_LivingRoom() {
        Thread thread = new Thread(this);
        thread.start();
    }
    public void Event_TableArea() {}
    public void Event_Kitchen() {}
    public void Event_BedRoom() {}
    public void Event_BathRoom() {}

    @Override
    public void run() {
        //Procedure
        System.out.println("TO2 thread begins, ID:" + Thread.currentThread().getId());
        System.out.println("Task Ontology 2 Running");
//        try {
//            Thread.sleep(2000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
        System.out.println("TO2 thread ends, ID:" + Thread.currentThread().getId());
    }

    @Override
    public void addListener(OntologyEventListener addListener) {

    }
}
