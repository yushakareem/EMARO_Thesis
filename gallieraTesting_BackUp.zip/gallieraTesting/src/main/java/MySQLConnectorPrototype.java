import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public interface MySQLConnectorPrototype {

    void startDBConnection(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void startDBConnectionOrCreateNew(String New_DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void getFromTableLatest(String Table_Name_In_DB);
    void getFromTableWithCustomQuery(String MySQLCustomQuery);
    Timestamp getItemTimeStamp();
    Boolean getItemValue();
    void putIntoTable(String Table_Name_InDB, String timeStamp, String stringValue);
    void stopDBConnection();
}
