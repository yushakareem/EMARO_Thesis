import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public interface MySQLConnectorPrototype {

    void beginDBConnection(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void beginDBConnectionOrCreateNew(String New_DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void getFromTableLatest(String Table_Name_In_DB);
    void getFromTableWithCustomQuery(String MySQLCustomQuery);
    Timestamp getItemTimeStamp();
    Boolean getItemValue();
    void putIntoTable();
    void endDBConnection();
}
