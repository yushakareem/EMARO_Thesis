import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public interface MySQLConnectorPrototype {

    void initiateDBConnection(String DataBase_Name,String MySQL_UserName,String MySQL_Password) throws ClassNotFoundException, SQLException;
    void readItemLatest(String Item_Name_In_DB) throws SQLException;
    void readItemWithCustomQuery(String MySQLQuery) throws SQLException;
    Timestamp getItemTimeStamp();
    Boolean getItemValue();
    void endDBConnection() throws SQLException;
}
