import java.sql.SQLException;

public interface MySQLDBLink {

    void connectWithMySQLDataBase(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
}
