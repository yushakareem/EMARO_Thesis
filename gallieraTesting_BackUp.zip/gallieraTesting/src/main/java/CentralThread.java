import it.emarolab.amor.owlDebugger.Logger;

import java.util.concurrent.TimeUnit;
/**
 * Created by yushakareem on 28/06/17.
 *
 * Thanks to: Prof. Fulvio Mastrogiovanni, Dr. Luca Buoncompagni
 *
 * What: Central thread for the system
 * Why: It has the main method, where the designer is able to create a connection between a MySQL-DB and network of ontologies, such that by communicating with
 *      eachother the system as a whole is context-aware and is able to detect 'tasks/activities' which the designer of the system is interested in.
 *
 * Legend:
 *          PO - Placing Ontology
 *          TO - Task Ontology
 *          Indiv - Individual in Ontology
 *          Onto - Ontology
 *          TS - TimeStamp
 *
 */
public class CentralThread {

    public static void main(String[] args) {
        System.out.println("Central thread begins");

        Logger.LoggerFlag.resetAllLoggingFlags();
//        System.out.println("Main thread begins, ID:" + Thread.currentThread().getId());
//
//        //***** Initialize PlacingOntology (PO)
//        PlacingOntology PO = new PlacingOntology();
//
//        //***** Initialize TaskOntologies (TOs)
//        TaskOntology1 TO1 = new TaskOntology1();    //Ontology infers: 'Person' "isStillIn" 'Room'
//        TaskOntology2 TO2 = new TaskOntology2();    //Ontology infers: 'Person' "isDoingActivity" 'WatchingTV'
//        //TaskOntology2 TO3 = new TaskOntology3();    //Ontology infers: 'Person' "isDoingActivity" 'Making_Breakfast/Lunch/Dinner'(LocationDependent)
//        //TaskOntology2 TO3 = new TaskOntology3();    //Ontology infers: 'Person' "isDoingActivity" 'Eating_Breakfast/Lunch/Dinner'(LocationInDependent)
//        //TaskOntology2 TO4 = new TaskOntology4();    //Ontology infers: 'Person' "isDoingActivity" 'Nap'//During Day
//        //TaskOntology2 TO5 = new TaskOntology5();    //Ontology infers: 'Person' "isDoingActivity" 'Sleeping'//During Night
//        //TaskOntology2 TO6 = new TaskOntology6();    //Ontology infers: 'Person' "isDoingActivity" 'DisturbedSleepInPrevious15Mins'
//        //TaskOntology2 TO7 = new TaskOntology7();    //Ontology infers: 'Person' "isDoingActivity" 'MorningBathRoomRoutine'//PerhapsBrushing&UsingToiletSeat
//        //TaskOntology2 TO8 = new TaskOntology8();    //Ontology infers: 'Person' "isDoingActivity" 'DidNotUseBathroomInPrev3Hours'
//        //TaskOntology2 TO9 = new TaskOntology9();    //Ontology infers: 'Person' "isDoingActivity" 'FrequencyOfVisitToBathRoomAtNight'
//        //TaskOntology2 TO10 = new TaskOntology10();    //Ontology infers: 'Person' "isDoingActivity" 'InRoomButNoMovementPrev3Hours'
//        //Sensors data Unavailable for these inferences
//        //TaskOntology2 TO11 = new TaskOntology11();    //Ontology infers: 'Person' "isDoingActivity" 'TookShowerDuringPrev30Mins'or'Showering'
//        //TaskOntology2 TO12 = new TaskOntology12();    //Ontology infers: 'Person' "isDoingActivity" 'Cooking'
//        //TaskOntology2 TO13 = new TaskOntology13();    //Ontology infers: 'Person' "isDoingActivity" 'WalkingTestDone'//CalculateAndSaveSpeedOfWalking
//
//        //***** Add the TOs as 'event-listeners' of 'event' happening in PO
//        PO.hasEventListener(TO1);
//        PO.hasEventListener(TO2);
//
//        //***** Periodically updating the PO with latest values from MySql DataBase
//        //***** Inside PO's run method:
//        //***** 1.UpdateOntology from MySQL DB
//        //***** 2.Reason with PO and activate TOs based on the context
//        Timer time = new Timer();
//        time.schedule(PO,0,10000);       //Period is in Millis (Only Method:startInputFromDBtoOnto in run())
//
//        //***** For TESTING: Periodically updating the PO by reading through the data base from the beginning to the end
//        //
//        //
//        //
//
//
//        //*****
//        //PO.inferThenInitiateTOs();
//
//        System.out.println("Main thread ends, ID:" + Thread.currentThread().getId());

//        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
//        scheduler.scheduleAtFixedRate(PO, 0, 10000, TimeUnit.MILLISECONDS);
        PlacingOntology PO = new PlacingOntology(
                "PO",
                "src/main/resources/PlacingOntology.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology",
                true
        );

        PO.setMySqlDBInputInfo("OpenHAB","openhab","nepo");

        PO.setInputLinkFromDBtoOnto("S_M_BathRoom","Item1");
        PO.setInputLinkFromDBtoOnto("S_M_Kitchen","Item2");
        PO.setInputLinkFromDBtoOnto("S_M_TableX","Item3");
        PO.setInputLinkFromDBtoOnto("S_M_Table","Item4");
        PO.setInputLinkFromDBtoOnto("S_M_LivingRoom","Item5");
        PO.setInputLinkFromDBtoOnto("S_M_Bed","Item7");
//            TaskOntology TO1 = new TaskOntology();
//
//            TO1.ListensFor_eventLivingRoom();
//            TO1.ListensFor_eventTableArea();
//            TO1.ListensFor_eventKitchen();
//            TO1.ListensFor_eventBedRoom();
//            TO1.ListensFor_eventBathRoom();
//
//            TaskOntology TO2 = new TaskOntology();
//
//            TO2.ListensFor_eventLivingRoom();
//
//        PO.hasEventListener(TO1);
//        PO.hasEventListener(TO2);
//
//        PO.startScheduledOntology(PO,0,10000,TimeUnit.MILLISECONDS,1);

        //PO.setMySqlDBOutputInfo("ActivityRecognitionDB","root","nepo");
//        PO.stringOutputToDB_ResultOfReason(bla,bla);
//        PO.booleanOutputToDB_ResultOfReason(bla,bla,bla);
//
//        TaskOntology TO1 = new isStillInTaskOntology(bla, bla, bla, bla); //Making a special TaskOntology
//        TO1.provideMySqlDBInfo_Input(bla,bla,bla); //Not used by TOs normally
//        TO1.InputFromA_DB(bla, bla, bla); //Need to give above if this method is to be used
//        TO1.InputFromAn_Ontology(bla, bla, bla);
//
//        //Inside the task ontology it takes this info and makes a definition of "ModTaskOntology(Object)"LinkedWith"OutputToDB(Object)"
//        if(TO1.Duration(activity,comparator,timePositiveInt)&TO1.Interval(t1,t2)) {
//            TO1.stringOutputToDB_ResultOf(bla, bla, bla);
//        }
//
//        TaskOntology TO2 = new TaskOntology(bla, bla, bla, bla);
//        TO2.InputFromAn_Ontology(bla,bla,bla);
//        TO2.booleanOutputToDB_ResultOf(bla,bla,bla);
//
//        TO1.hasEventListener(TO2);
//        TO2.ListensFor_eventIsStillIn();
//
//        PO.hasEventListener(TO1);
//        TO1.ListensFor_eventLivingRoom();
//        TO1.ListensFor_eventBathRoom();
//        TO1.ListensFor_eventBedRoom();
//        TO1.ListensFor_eventKitchen();
//        TO1.ListensFor_eventTableArea();
//        PO.hasEventListener(TO2);
//        TO2.ListensFor_eventLivingRoom();
//
//        PO.startInputFromDBtoOnto();

        //Otherwise
        //Make a special placing ontology where it is merged with OWL-Time and rest of the TaskOntologies become simple
        //NOTE: Memory brings temporal-logic into the picture. IOW(In Other Words) Temporal-logic requires memory. IOW Memory is Temporality
        //On each update of PlacingOntology
        PO.commitInferenceOf("H_I_Habitant_1","isStillIn");

        /*
            NOTE:
            Development stage:
            As far as saving things or 'committing' is concerned multiple things can be saved. But as far as reading
            from memory is concerned, now simply for quick testing reading from single variables rather than lists.

         */

        //On each update system will modify ontology based on Memory
//        PO.makeTemporalLogicBasedOnMemory(
//                PO.hasDuration(PO.recallInferenceOf("isStillIn"),"=",0),
//                PO.inTimeInterval(null,"Time_Now"));

        PO.hasDuration(PO.recallInferenceOf("isStillIn"),"=",0);
        PO.inTimeInterval(null,"Time_Now");

        TaskOntology TO1 = new TaskOntology(
                "TO1",
                "src/main/resources/PlacingOntology.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TO1",
                true
        );
        TO1.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_LivingRoom");
        PO.hasEventListener(TO1);

        TaskOntology TO2 = new TaskOntology(
                "TO2",
                "src/main/resources/PlacingOntology.owl",
                "http://www.semanticweb.org/emaroLab/YushaKareem/TO1",
                true
        );
        TO2.setActivationCondition("H_I_Habitant_1","isStillIn","A_R_LivingRoom");
        PO.hasEventListener(TO2);

        System.out.println("Central thread ends1");

        //Each iteration of the run 'does not' make a new object of PlacingOntology
        PO.startScheduledOntology(PO,0,15000, TimeUnit.MILLISECONDS,1);
        System.out.println("Central thread ends2");
    }

}
