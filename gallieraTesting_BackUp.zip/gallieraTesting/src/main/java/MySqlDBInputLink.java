import java.sql.SQLException;

public interface MySqlDBInputLink {

    void setMySqlDBInputInfo(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
}
