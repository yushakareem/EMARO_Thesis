import java.sql.SQLException;

public interface MySqlDBInputLink {

    void inputMySqlDBDescription(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
}
