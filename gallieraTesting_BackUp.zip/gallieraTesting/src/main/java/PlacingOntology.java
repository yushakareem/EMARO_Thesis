import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import it.emarolab.owloop.aMORDescriptor.utility.objectProperty.MORFullObjectProperty;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its sensorIndividualMap from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 */

public class PlacingOntology implements PlacingOntologyPrototype {

    OWLReferences ontoRef;
    String DataBase_Name;
    String MySQL_UserName;
    String MySQL_Password;
    String Activity_DataBase_Name;
    String Activity_MySQL_UserName;
    String Activity_MySQL_Password;
    String ontoFilePath;

    List<TaskOntology> eventListenersList = new ArrayList<>();

    Map<String, MORFullIndividual> sensorIndividualMap = new HashMap<>();
    Map<String, String> sensorItemIndividualMap = new HashMap<>();
    List<String> sensorItemsInDBList = new ArrayList<>();

    MySQLConnector mySqlObj = new MySQLConnector();

    MORFullIndividual s_individual_A_NameInOntology;
    MORFullObjectProperty s_objectPropertyRelating_individuals;
    MORFullIndividual b_individual_A_NameInOntology;
    MORFullObjectProperty b_objectPropertyRelating_individuals;
    MORFullIndividual b_individual_B_NameInOntology;


    public PlacingOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoFilePath = filePath;
        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("0.1");
    }

    @Override
    public void run() {
        System.out.println("PO thread begins, ID:" + Thread.currentThread().getId());
        this.importDataFromDBToOntology(sensorItemsInDBList); //Import data from DB and Update the PO
        this.activateEventBasedOnActivationCondition(eventListenersList);
        System.out.println("PO thread ends, ID:" + Thread.currentThread().getId());
        try {
            this.finalize();
        } catch (Throwable throwable) {
            System.out.println("PO finalized");
        }
    }

    //delete this eventually
    private void UpdateOLD() {

    //Constructing the sensorIndividualMap from Ontology domain to Java domain. By reading from PO

//        iP = new MORFullIndividual(
//                "P_Habitant_1", // the ground instance name
//                "PO", // ontology reference name
//                "src/main/resources/PlacingOntologyTest.owl", // the ontology file path
//                "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology" // the ontology IRI path
//        );
//
//        iSML = new MORFullIndividual(
//        "S_MotionLivingRoom", // the ground instance name
//        "PO", // ontology reference name
//        "src/main/resources/PlacingOntologyTest.owl", // the ontology file path
//        "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology" // the ontology IRI path
//        );

        /*
           METHOD 1 ... If A sematicRelation b. For A getting single/set object/data property B
         */

//        iP.readSemantic();
//        System.out.println("iP:"+iP);
//        OWLNamedIndividual i = iP.getObjectSemantics().getLink(iP.getOWLObjectProperty("isWithSensor")); //Gives me first one from the set
//        System.out.println("i:"+ i);
//        //Try getOWLObjectName(i) somehow -> gives the perfect thing
//        //iP.getOWLName(i) also works
//
//        iSML.readSemantic();
//        iSML.addData("hasMotionValue",true,true);
//        iSML.writeSemantic();
//        OWLLiteral j = iSML.getDataSemantics().getLiteral(iSML.getOWLDataProperty("hasMotionValue"));
//        System.out.println("j:"+ j);
//
        /*
           METHOD 1.5 ... If i want to browse through a set. In object property
         */
//       for( OWLNamedIndividual hh : iP.getDisjointIndividual()) {
//            if (hh.equals(iP.getOWLIndividual("dddd"))) {
//                .....
//                break;
//            }
//        }

        /*
           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
         */

//        //This is how we construct a new IRI
//        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
//        "EO",
//        "src/main/resources/empty.owl",
//        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
//        true);
//
//        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
//        System.out.println("j2:"+ j2);
//        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
//        iP.writeSemantic();
    }

    @Override
    public void setEventListener(TaskOntology eventListener) {
        eventListenersList.add(eventListener);
        System.out.println("Listener Added!");
    }

    //add method to placingOntologyPrototype //Remember to add parameter "List<String> itemsInDB"
    public void importDataFromDBToOntology(List<String> listOfSensorItemsInDB) {

        mySqlObj.startDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);
        System.out.println("1");

        for (String sensorItemInDB:listOfSensorItemsInDB) {

            mySqlObj.getFromTableLatest(sensorItemInDB); //ImportData from DB
            System.out.println("2");
            MORFullIndividual sensorIndivInOnto = sensorIndividualMap.get(sensorItemIndividualMap.get(sensorItemInDB));
            System.out.println("3");
            sensorIndivInOnto.readSemantic(); //perhaps do only once, as ontoName for all the sensorIndividualMap is same
            System.out.println("4");
            if (mySqlObj.getItemValue()) {
                sensorIndivInOnto.removeData("hasTypeTimeStamp");
                sensorIndivInOnto.addData("hasTypeTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionValue");
                sensorIndivInOnto.addData("hasMotionValue", true, true);
            }
            else{
                sensorIndivInOnto.removeData("hasTypeTimeStamp");
                sensorIndivInOnto.addData("hasTypeTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionValue");
                sensorIndivInOnto.addData("hasMotionValue", false, true);
            }
            System.out.println("5");
            sensorIndivInOnto.writeSemanticInconsistencySafe();
            System.out.println("6");
            sensorIndivInOnto.buildDataIndividual();
            System.out.println("7");
            sensorIndivInOnto.saveOntology(ontoFilePath);
            System.out.println("8");
        }
        mySqlObj.stopDBConnection();
        System.out.println("9");

//        MORFullIndividual i = new MORFullIndividual("P_Habitant_1",ontoRef);
//        i.readSemantic();
//        //i.reason();
//        System.out.println("Person Details after update:"+i);
    }

    @Override
    public void connectIndividualWithSensorItemInDB(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase) {

        sensorItemIndividualMap.put(Sensor_ItemName_InDataBase,Sensor_IndividualName_InOntology);
        System.out.println("0.2");
        sensorItemsInDBList.add(Sensor_ItemName_InDataBase);
        System.out.println("0.3");
        sensorIndividualMap.put(Sensor_IndividualName_InOntology,this.makeIndividualFromString(Sensor_IndividualName_InOntology, ontoRef));
        System.out.println("0.4");
    }

    @Override
    public MORFullIndividual makeIndividualFromString(String Sensor_IndividualName_InOntology, OWLReferences ontoRef) {

        return new MORFullIndividual(
                Sensor_IndividualName_InOntology,
                ontoRef
        );
    }

    @Override
    public String getName() {
        return String.valueOf(ontoRef);
    }

    @Override
    public void inputMySqlDBDescription(String database_Name, String mysql_UserName, String mysql_Password) {

            DataBase_Name = database_Name;
            MySQL_UserName = mysql_UserName;
            MySQL_Password = mysql_Password;
    }

    @Override
    public void outputMySqlDBDescription(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password) {
        Activity_DataBase_Name = Activity_database_Name;
        Activity_MySQL_UserName = Activity_mysql_UserName;
        Activity_MySQL_Password = Activity_mysql_Password;
    }

    //Here lies output to DB
//    private void reasonAndSaveDesiredOutputToDB_String() {
//
//
//    }
//
//    private void reasonAndSaveDesiredOutputToDB_Boolean() {
//
//        mySqlObj.startDBConnectionOrCreateNew(Activity_DataBase_Name,Activity_MySQL_UserName,Activity_MySQL_Password);
//        //Read the inference of the indiv.P_Habitant_1: ObjProp.isOccupying & DataProp.
//    }
//
//    @Override
//    public void stringOutputToDB_ResultOfReason(String individual_A_NameInOntology, String objectPropertyRelating_individuals) {
//        //Later save in a List
//
//        s_individual_A_NameInOntology = makeIndividualFromString(individual_A_NameInOntology,ontoRef);
//        //s_objectPropertyRelating_individuals = objectPropertyRelating_individuals;
//    }
//
//    @Override
//    public void booleanOutputToDB_ResultOfReason(String individual_A_NameInOntology, String objectPropertyRelating_AandB, String individual_B_NameInOntology) {
//        //Later save in a List
//
//        b_individual_A_NameInOntology = makeIndividualFromString(individual_A_NameInOntology,ontoRef);
//        //b_objectPropertyRelating_individuals = objectPropertyRelating_AandB;
//        b_individual_B_NameInOntology = makeIndividualFromString(individual_B_NameInOntology,ontoRef);
//
//    }

    public void activateEventBasedOnActivationCondition(List<TaskOntology> listOfeventListeners){

        System.out.println("10");
        if(!listOfeventListeners.isEmpty()) {
            System.out.println("11");
            for (TaskOntology objTO : listOfeventListeners) {
                System.out.println("12");
                if (checkEventActivation(objTO)) {
                    System.out.println("13");
                    Thread thread = new Thread(objTO);
                    System.out.println("13.1: Activating thread->"+objTO.getName());
                    thread.start();
                    System.out.println("13.2");
                } else {
                    System.out.println("13.1: Did not activate thread->"+objTO.getName());
                }
            }
        } else {
            System.out.println("No eventListeners exist of this Ontology!");
        }
    }

    public boolean checkEventActivation(TaskOntology objectOfTO){

        System.out.println("12.5");
        MORFullIndividual localIndiv = makeIndividualFromString(objectOfTO.getEventActivationConditionIndivA(),ontoRef);
        System.out.println("12.6");
        localIndiv.readSemantic();
        localIndiv.reason();    //Reasoning the PO for every taskOntology 'event' condition
        System.out.println("12.7");
        OWLNamedIndividual namedIndiv = localIndiv.getObjectSemantics().getLink(localIndiv.getOWLObjectProperty(objectOfTO.getEventActivationConditionObjProp()));
        System.out.println("12.8");
        String check = localIndiv.getOWLName(namedIndiv);
        System.out.println("12.9,Check:"+localIndiv.getOWLName(namedIndiv)+"indivB:"+objectOfTO.getEventActivationConditionIndivB());
        System.out.println("12.10"+Objects.equals(check,objectOfTO.getEventActivationConditionIndivB()));
        return Objects.equals(check,objectOfTO.getEventActivationConditionIndivB());
    }

    @Override
    public void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {

        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }

}
