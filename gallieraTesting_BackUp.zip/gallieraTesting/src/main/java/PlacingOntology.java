import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.*;

import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its sensorIndividualMap from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 * Note:To have the local memory here, the attributes do not need to be static because the PlacingOntology object never dies.
 *      Its like same object and infinite loop of run() with a particular frequency.
 *
 */

//        /*
//           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
//         */
//
////        //This is how we construct a new IRI
////        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
////        "EO",
////        "src/main/resources/empty.owl",
////        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
////        true);
////
////        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
////        System.out.println("j2:"+ j2);
////        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
////        iP.writeSemantic();

public class PlacingOntology implements PlacingOntologyPrototype {

    ///////////////-->      (Data Importer) attributes        <--///////////////////////////
    //INTERFACE: MySqlDBInputLink
    String DataBase_Name;
    String MySQL_UserName;
    String MySQL_Password;
    MySQLConnector mySqlObj = new MySQLConnector();
    List<String> sensorItemsInDBList = new ArrayList<>();
    Map<String, String> sensorItemIndividualMap = new HashMap<>();
    Map<String, MORFullIndividual> sensorIndividualMap = new HashMap<>();
    ///////////////-->      (Ontology Defining) attributes    <--///////////////////////////
    /////////////--> attributes related to: Defining the kind of ontology
    //////////--> attributes that allow: Basic functions to access the ontology
    //////////--> attributes that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> attributes that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')
    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    boolean flagExistsKnowledgeToActivateTemporalLogic;
    boolean flagActivateTemporalLogic;
    List<TemporalLogic> temporalLogicForMemoryList = new ArrayList<>();
    //INTERFACE:        SaveInMemory
    String memIndividualName;
    String memObjPropName;
    String memDesiredInferredIndivName;
    //Timestamp memDesiredInferredIndivTS;
    //Map<String, String> memDesiredObjPropInferredIndivMap = new HashMap<>();
    //Map<String, Timestamp> memDesiredInferredIndivAndItsTSMap = new HashMap<>();

    //INTERFACE:        RecollectFromMemory
    //////////--> Updating ontology with a given frequency
    //INTERFACE: OntologyRunsWithFrequency
    /////////////--> attributes related to: Defining the link between ontologies
    //INTERFACE: EventInitiator
    List<TaskOntology> eventListenersList = new ArrayList<>();
    ///////////////-->      (Task Importer) attributes       <--////////////////////////////
    //NONE
    ///////////////-->      (Task Dispatcher) attributes     <--////////////////////////////
    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////-->      (Data Importer) methods        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    @Override
    public void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase) {
        System.out.println("############# setInputLinkFromDBToOnto() #############");
        sensorItemIndividualMap.put(Sensor_ItemName_InDataBase,Sensor_IndividualName_InOntology);
        sensorItemsInDBList.add(Sensor_ItemName_InDataBase);
        sensorIndividualMap.put(Sensor_IndividualName_InOntology,this.getIndividual(Sensor_IndividualName_InOntology, ontoRef));
    }
    @Override
    public void setMySqlDBInputInfo(String database_Name, String mysql_UserName, String mysql_Password) {
        System.out.println("############# setMySqlDBInputInfo() #############");
        DataBase_Name = database_Name;
        MySQL_UserName = mysql_UserName;
        MySQL_Password = mysql_Password;
    }
    public void startInputFromDBtoOnto(List<String> listOfSensorItemsInDB) {
        System.out.println("\n############# startInputFromDBToOnto() #############\n");
        mySqlObj.startDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);

        for (String sensorItemInDB:listOfSensorItemsInDB) {

            mySqlObj.getFromTableLatest(sensorItemInDB); //ImportData from DB
            MORFullIndividual sensorIndivInOnto = sensorIndividualMap.get(sensorItemIndividualMap.get(sensorItemInDB));
            sensorIndivInOnto.readSemantic(); //perhaps do only once, as ontoName for all the sensorIndividualMap is same
            if (mySqlObj.getItemValue()) {
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", true, true);
            }
            else{
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", false, true);
            }
            sensorIndivInOnto.writeSemanticInconsistencySafe();
            sensorIndivInOnto.buildDataIndividual();
        }

        this.setIndividualWithTimestamp(this.getIndividual("Time_Now",ontoRef), new Timestamp(System.currentTimeMillis()));
        synchronizeAndSaveOnto();
        mySqlObj.stopDBConnection();
    }

    ///////////////-->      (Ontology Defining) methods    <--///////////////////////////

    /////////////--> Methods related to: Defining the kind of ontology
    //////////--> Methods that allow: Basic functions to access the ontology
    //////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public PlacingOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {
        System.out.println("############# PlacingOntology() #############");
        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
    }

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    public void setIndividualWithTimestamp(MORFullIndividual individual, Timestamp timeStamp){
        System.out.println("############# setIndividualWithTimestamp() #############");
        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",String.valueOf(timeStamp));
        individual.writeSemanticInconsistencySafe();
    }
    public void synchronizeAndSaveOnto() {
        this.getOntoRef().synchronizeReasoner();
        this.getOntoRef().saveOntology(this.getOntoRef().getFilePath());
    }
    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        System.out.println("############# getIndividual() #############");
        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }
    public Timestamp getIndividualTimestamp(MORFullIndividual individual) {
        System.out.println("############# getIndividualTimestamp() #############");
        individual.readSemantic();
        OWLLiteral localNamedIndiv = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty("hasTimeStamp"));
        return Timestamp.valueOf(individual.getOWLName(localNamedIndiv));//Timestamp.valueOf(localNamedIndiv.getLiteral());
    }
    public String getInference(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("############# getInference() #############");
        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));//individual.getObject(objectPropertyName)
        return individual.getOWLName(namedIndiv);
    }
    public Set<OWLNamedIndividual> getInferencesOWLNamedIndividual(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("############# getInference() #############");
        individual.readSemantic();
        return individual.getObjects(objectPropertyName);
    }
    @Override
    public OWLReferences getOntoRef() {
        System.out.println("############# getOntoRefName() #############");
        return ontoRef;
    }
    public void modifyBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {
        System.out.println("\n############# modifyBasedOnCurrentSensoryState() #############\n");

        this.startInputFromDBtoOnto(sensorItemsInDBList);
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("\n############# run() #############\n");
        System.out.println("PO thread begins, ID:" + Thread.currentThread().getId());

        /*1*/this.modifyBasedOnCurrentSensoryState(sensorItemsInDBList);//Makes the current state of Ontology based on live sensor values from DB
        /*2*/this.commitInferenceOf(recallDesiredKnowledgeIndiv(), recallDesiredKnowledgeObjProp());
        /*3*/if (getFlagActivateTemporalLogic()){
            this.modifyBasedOnMemoryAndTemporalLogic(temporalLogicForMemoryList);
            setFlagActivateTemporalLogic(false);
        }
        //--> Now system ready with context based on current sensory input and past memory
        //--> Activate the Task Ontologies based on the current state of the Placing Ontology
        /*4*/this.inferAndTriggerEvents(eventListenersList);
        //--> Based on the current state of Ontology, commitInferenceOf to memory knowledge specified by the designer of the system

        System.out.println("PO thread ends, ID:" + Thread.currentThread().getId());
    }

    //INTERFACE:    OntologyHasMemory

    public void modifyBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {
        System.out.println("\n############# modifyBasedOnMemoryAndTemporalLogic() #############\n");

        for (TemporalLogic timeMemObj:temporalLogicForMemoryList) {
            startTimeMemoryLogic(timeMemObj);
            synchronizeAndSaveOnto();
        }
    }
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {
        System.out.println("\n\n############# startTimeMemoryLogic() #############\n\n");

        /*
            t prefix means time
         */

        //Update TimeNow so that it is in the true now.
        setIndividualWithTimestamp(getIndividual("Time_Now", ontoRef), new Timestamp(System.currentTimeMillis()));

        //Time Interval T1
        OWLNamedIndividual tIntervalT1NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT1());
        Timestamp T1TS;

        //Time Interval T2
        OWLNamedIndividual tIntervalT2NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT2());
        Timestamp T2TS;

        //Time Ontology object properties
        OWLObjectProperty objPropBefore = temporalObj.getTimeOntoRef().getOWLObjectProperty("before");
        OWLObjectProperty objPropAfter = temporalObj.getTimeOntoRef().getOWLObjectProperty("after");

        //Individual and ObjectProperty given by user
        String tIndiv = temporalObj.recallIndiv(); //Human
        MORFullIndividual tIndivFull = getIndividual(tIndiv, ontoRef); //Human
        String tObjProp = temporalObj.recallObjProp(); //isStillIn

        //Removing All the old before's and after's, so that they do not have influence in the NOW
        System.out.println("BEFORE REMOVING before and after");
        System.out.println(getInference(tIndivFull, tObjProp)); //THERE CAN BE TWO INFERENCE (Because the way swrl rules are written)

        Set<OWLNamedIndividual> tInferredIndivSet = getInferencesOWLNamedIndividual(tIndivFull,tObjProp);

        System.out.println("-- 1 --");
        for (OWLNamedIndividual tInferredIndiv : tInferredIndivSet) {
            System.out.println("-- 2 --");
            MORFullIndividual localIndivFull = new MORFullIndividual(tInferredIndiv, ontoRef);
            localIndivFull.readSemantic();
            localIndivFull.removeObject(objPropBefore, tIntervalT1NamedIndiv);
            localIndivFull.removeObject(objPropAfter, tIntervalT1NamedIndiv);
            localIndivFull.removeObject(objPropBefore, tIntervalT2NamedIndiv);
            localIndivFull.removeObject(objPropAfter, tIntervalT2NamedIndiv);
            localIndivFull.writeSemanticInconsistencySafe();
        }
        synchronizeAndSaveOnto();

        System.out.println("### 2");
        MORFullIndividual tInferredIndivFull = getIndividual(getInference(getIndividual(tIndiv, ontoRef), tObjProp), ontoRef);//AT THIS STAGE THERE SHOULD BE A SINGLE INFERENCE (Because influence of rules removed)

        //NOTE SPECIFIC IMPLIMENTATION HAPPENING HERE
        //TimeStamp for Inferred Individual obtained by checking its Sensor TimeStamp
        Timestamp tInferredIndivTS;
        System.out.println("-------> 0.1");
        String sensorOfInferredIndiv = getInference(getIndividual("A_House",ontoRef),"detectedMotionBy");
        System.out.println("-------> 0.2");
        tInferredIndivTS = getIndividualTimestamp(getIndividual(sensorOfInferredIndiv, ontoRef));
        System.out.println("-------> 0.3");

        String T1Name = temporalObj.recallTimeIntervalT1();
        System.out.println("-------> 0.4");
        String T2Name = temporalObj.recallTimeIntervalT2();
        System.out.println("-------> 0.5");
        if (Objects.equals(T1Name, null)) {
            System.out.println("-------> 0.6");
            T2TS = getIndividualTimestamp(getIndividual(T2Name, ontoRef));
            System.out.println("-------> 0.7");
            if (tInferredIndivTS.before(T2TS)) {
                System.out.println("-------> 0.8");
                tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                tInferredIndivFull.writeSemantic();
                System.out.println("-------> 0.9");
            } else {
                System.out.println("The TS of inferredIndiv is after timeInterval T2");
            }
            System.out.println("-- 6 --");


        } else if (Objects.equals(T2Name, null)) {

            T1TS = getIndividualTimestamp(getIndividual(T1Name, ontoRef));

            if (tInferredIndivTS.after(T1TS)) {

                tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                tInferredIndivFull.writeSemantic();
            } else {

                System.out.println("The TS of inferredIndiv is before timeInterval T1");
            }
            System.out.println("-- 7 --");

        } else if (Objects.equals(T1Name, null) & Objects.equals(T2Name, null)) {

            System.out.println("The inferredIndiv is not limited to the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
        } else {

            System.out.println("The inferredIndiv is strictly in the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
        }
    }

    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {
        System.out.println("############# setTemporalLogic() #############");
        if (checkHasDuration) {
            temporalLogicForMemoryList.add(temporalLogicObj);
        }
    }
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {
        this.flagExistsKnowledgeToActivateTemporalLogic = flagExistsKnowledgeToActivateTemporalLogic;
    }
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return flagExistsKnowledgeToActivateTemporalLogic;
    }
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {
        this.flagActivateTemporalLogic = flagActivateTemporalLogic;
    }
    public boolean getFlagActivateTemporalLogic() {
        return flagActivateTemporalLogic;
    }

    //INTERFACE:        CommitToMemory
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {
        System.out.println("############# commitToActivateTemporalLogic() #############");
        memIndividualName = individualName;
        memObjPropName = objPropName;
        if (!Objects.equals(memIndividualName,null)&!Objects.equals(memObjPropName,null)) {
            System.out.println("User desired individual and objectProperty saved to memory.");
            setFlagExistsKnowledgeToActivateTemporalLogic(true);
        } else {
            System.out.println("Please enter the parameters properly!");
        }
    }
    public void commitInferenceOf(String desiredIndividualNameToInferWith, String desiredObjPropNameToInferWith){
        System.out.println("\n############# commitInferenceOf() #############\n");

        if (/**/getFlagExistsKnowledgeToActivateTemporalLogic()) {

            MORFullIndividual localIndiv = this.getIndividual(desiredIndividualNameToInferWith, ontoRef);
            memDesiredInferredIndivName = this.getInference(localIndiv, desiredObjPropNameToInferWith);
            if (!Objects.equals(memDesiredInferredIndivName,null)) {
                System.out.println("INFERENCE EXISTS!! TemporalLogic will be activated!");
                setFlagActivateTemporalLogic(true);
            } else {
                System.out.println("For OntoMemory: "+desiredIndividualNameToInferWith+" "+desiredObjPropNameToInferWith+" --> "+memDesiredInferredIndivName+", This inference and its TS not committed to memory '"+this.getOntoRef().getReferenceName()+"' ontology.");
            }
        } else {
            System.out.println("For OntoMemory: No desired knowledge to infer the ontology with, hence no modification will be done to '"+this.getOntoRef().getReferenceName()+"' ontology.");
        }
    }

    //INTERFACE:        RecallFromMemory
    public String recallDesiredKnowledgeObjProp() {
        System.out.println("############# recallDesiredKnowledgeObjProp() #############");
        System.out.println(memObjPropName);
        return memObjPropName;
    }
    public String recallDesiredKnowledgeIndiv() {
        System.out.println("############# recallDesiredKnowledgeIndiv() #############");
        System.out.println(memIndividualName);
        return memIndividualName;
    }

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency
    @Override
    public void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {
        System.out.println("############# startScheduledOntology() #############");
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }

    /////////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventInitiator
    public void inferAndTriggerEvents(List<TaskOntology> listOfeventListeners){
        System.out.println("\n############# inferAndTriggerEvents() #############\n");
        if(!listOfeventListeners.isEmpty()) {
            for (TaskOntology objTO : listOfeventListeners) {
                if (this.checkEventActivationCondition(objTO)) {
                    objTO.startWithFreshMemory();//If memory 'list' here is having memory objTO.getEventActivationConditionIndivB()
                    //ElseIf memory 'list' does not have that then objTO.startWithOldMemory
                } else {
                    System.out.println("Did not activate thread -> '"+objTO.getOntoReferenceName()+"'");
                }
            }
        } else {
            System.out.println("No eventListeners exist of this Ontology!");
        }
    }
    public boolean checkEventActivationCondition(TaskOntology objectOfTO){
        System.out.println("\n############# checkEventActivationCondition() #############\n");
        MORFullIndividual localIndiv = getIndividual(objectOfTO.getEventActivationConditionIndivA(),ontoRef);
        String inferredIndiv = this.getInference(localIndiv,objectOfTO.getEventActivationConditionObjProp());
        return Objects.equals(inferredIndiv,objectOfTO.getEventActivationConditionIndivB());
    }
    @Override
    public void hasEventListener(TaskOntology eventListener) {
        System.out.println("############# hasEventListener #############");
        eventListenersList.add(eventListener);
        System.out.println("Listener Added!");
    }

    ///////////////-->      (Task Importer) methods       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
    /////////////-->      (Data Importer) methods        <--///////////////////////////

    INTERFACE: MySqlDBInputLink

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    INTERFACE:    Runnable
    INTERFACE:    OntologyHasMemory
    INTERFACE:        CommitToMemory
    INTERFACE:        RecallFromMemory

    ////////--> Updating ontology with a given frequency

    INTERFACE: OntologyRunsWithFrequency

    ///////////--> Methods related to: Defining the link between ontologies

    INTERFACE: EventInitiator

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    NONE

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    NONE
*/
}
