import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import it.emarolab.owloop.aMORDescriptor.utility.objectProperty.MORFullObjectProperty;
import org.apache.commons.collections.BidiMap;
import org.apache.commons.collections.bidimap.DualHashBidiMap;
import org.apache.jena.base.Sys;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TimerTask;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its individuals from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 */

public class PlacingOntology implements PlacingOntologyPrototype {

    private static MORFullIndividual iP;
    private static MORFullIndividual iSML;
    private static MORFullObjectProperty iObj;
    public List<OntologyEventListener> POeventlisteners = new ArrayList<>();
    MySQLConnector mySqlObj = new MySQLConnector();
    BidiMap bidiMap = new DualHashBidiMap();

    @Override
    public void run() {
        System.out.println("PO thread begins, ID:" + Thread.currentThread().getId());
        try {
            this.UpdatePlacingOntology();
            this.reasonThenInitiateTOs();
        } catch (SQLException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        System.out.println("PO thread ends, ID:" + Thread.currentThread().getId());
    }

//    private void UpdatePlacingOntology() throws SQLException, ClassNotFoundException {
//
//    //Constructing the individuals from Ontology domain to Java domain. By reading from PO
//
////        iP = new MORFullIndividual(
////                "P_Habitant_1", // the ground instance name
////                "PO", // ontology reference name
////                "src/main/resources/PlacingOntologyTest.owl", // the ontology file path
////                "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology" // the ontology IRI path
////        );
////
////        iSML = new MORFullIndividual(
////        "S_MotionLivingRoom", // the ground instance name
////        "PO", // ontology reference name
////        "src/main/resources/PlacingOntologyTest.owl", // the ontology file path
////        "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology" // the ontology IRI path
////        );
//
//        /*
//           METHOD 1 ... If A sematicRelation b. For A getting single/set object/data property B
//         */
//
////        iP.readSemantic();
////        System.out.println("iP:"+iP);
////        OWLNamedIndividual i = iP.getObjectSemantics().getLink(iP.getOWLObjectProperty("isWithSensor")); //Gives me first one from the set
////        System.out.println("i:"+ i);
////        //Try getOWLObjectName(i) somehow -> gives the perfect thing
////        //iP.getOWLName(i) also works
////
////        iSML.readSemantic();
////        iSML.addData("hasMotionValue",true,true);
////        iSML.writeSemantic();
////        OWLLiteral j = iSML.getDataSemantics().getLiteral(iSML.getOWLDataProperty("hasMotionValue"));
////        System.out.println("j:"+ j);
////
//        /*
//           METHOD 1.5 ... If i want to browse through a set. In object property
//         */
////       for( OWLNamedIndividual hh : iP.getDisjointIndividual()) {
////            if (hh.equals(iP.getOWLIndividual("dddd"))) {
////                .....
////                break;
////            }
////        }
//
//        /*
//           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
//         */
//
////        //This is how we construct a new IRI
////        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
////        "EO",
////        "src/main/resources/empty.owl",
////        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
////        true);
////
////        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
////        System.out.println("j2:"+ j2);
////        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
////        iP.writeSemantic();
//    }

    public void addEventListener(OntologyEventListener POeventListener) {
        POeventlisteners.add(POeventListener);
        System.out.println("Listener Added!");
    }

    public void reasonThenInitiateTOs() {

        //bla.readSemantic()
        iObj = new MORFullObjectProperty(
                "isBeingIn", // the ground instance name
                "PO", // ontology reference name
                "src/main/resources/PlacingOntologyTest.owl", // the ontology file path
                "http://www.semanticweb.org/emaroLab/YushaKareem/PlacingOntology" // the ontology IRI path
        );

        iObj.readSemantic();
        System.out.println("Related to isBeingIn:" + iObj);

        //System.out.println("Placing Ontology inferred!! Based on context, instantiating TO's from here");



        //if (isBeingIn_LivingRoom == true)
//            for (OntologyEventListener iterateObj:listeners)
//                iterateObj.beginTaskOntology_LivingRoom();
        //else if(isBeingIn_Kitchen == true)
    //        for (OntologyEventListener iterateObj:listeners)
    //            iterateObj.beginTaskOntology_Kitchen();
        //else
        //  System.out.println("Unable to detect where the person is, Please check if PO is getting updated and inferred properly");
    }

    private void UpdatePlacingOntology() {


    }

    @Override
    public void attachIndividualWithItem(String Sensor_IndividualName_InOntology,String Sensor_ItemName_InDataBase) {
        bidiMap.put(Sensor_IndividualName_InOntology, Sensor_ItemName_InDataBase);
    }

    @Override
    public void connectWithMySQLDataBase(String DataBase_Name, String MySQL_UserName, String MySQL_Password) {

        try {
            mySqlObj.initiateDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Unable to connect with MySQL DB: Database/User/Password might be wrong");
        }
    }

    @Override
    public void scheduleOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {

        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }
}
