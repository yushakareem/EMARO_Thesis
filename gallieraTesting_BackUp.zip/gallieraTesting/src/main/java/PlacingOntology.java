import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.*;

import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its sensorIndividualMap from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 * Note:To have the local memory here, the attributes do not need to be static because the PlacingOntology object never dies.
 *      Its like same object and infinite loop of run() with a particular frequency.
 *
 */

//Help: For reading through a set of objectProp results. Passing individuals from one onto to another
//        /*
//           METHOD 1.5 ... If i want to browse through a set. In object property
//         */
////       for( OWLNamedIndividual hh : iP.getDisjointIndividual()) {
////            if (hh.equals(iP.getOWLIndividual("dddd"))) {
////                .....
////                break;
////            }
////        }
//
//        /*
//           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
//         */
//
////        //This is how we construct a new IRI
////        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
////        "EO",
////        "src/main/resources/empty.owl",
////        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
////        true);
////
////        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
////        System.out.println("j2:"+ j2);
////        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
////        iP.writeSemantic();

public class PlacingOntology implements PlacingOntologyPrototype {

    ///////////////-->      (Data Importer) attributes        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    String DataBase_Name;
    String MySQL_UserName;
    String MySQL_Password;

    MySQLConnector mySqlObj = new MySQLConnector();

    List<String> sensorItemsInDBList = new ArrayList<>();
    Map<String, String> sensorItemIndividualMap = new HashMap<>();
    Map<String, MORFullIndividual> sensorIndividualMap = new HashMap<>();
    ///////////////-->      (Ontology Defining) attributes    <--///////////////////////////

    /////////////--> attributes related to: Defining the kind of ontology
    //////////--> attributes that allow: Basic functions to access the ontology
    //////////--> attributes that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> attributes that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    String ontoFilePath;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    //INTERFACE:        SaveInMemory
    //INTERFACE:        RecollectFromMemory
    List<String> memObjectPropList = new ArrayList<>();
    Map<String,String> memObjectIndivMap = new HashMap<>();
    Map<String,Map<String,Timestamp>> memObjectInferredIndivMap = new HashMap<>();
    Map<String,Timestamp> memInferredIndivTimeStampMap = new HashMap<>();

    //INTERFACE:    OntologyHasTemporalLogic
    String logicInferredIndiv;
    Timestamp logicInferredIndivTS;
    String logicTimeIntervalT1Indiv;
    Timestamp logicTimeIntervalT1TS;
    String logicTimeIntervalT2Indiv;
    Timestamp logicTimeIntervalT2TS;

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency

    /////////////--> attributes related to: Defining the link between ontologies

    //INTERFACE: EventInitiator
    List<TaskOntology> eventListenersList = new ArrayList<>();

    ///////////////-->      (Task Importer) attributes       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) attributes     <--////////////////////////////

    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////-->      (Data Importer) methods        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    @Override
    public void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase) {

        sensorItemIndividualMap.put(Sensor_ItemName_InDataBase,Sensor_IndividualName_InOntology);
        System.out.println("0.2");
        sensorItemsInDBList.add(Sensor_ItemName_InDataBase);
        System.out.println("0.3");
        sensorIndividualMap.put(Sensor_IndividualName_InOntology,this.getIndividual(Sensor_IndividualName_InOntology, ontoRef));
        System.out.println("0.4");
    }
    @Override
    public void setMySqlDBInputInfo(String database_Name, String mysql_UserName, String mysql_Password) {

        DataBase_Name = database_Name;
        MySQL_UserName = mysql_UserName;
        MySQL_Password = mysql_Password;
    }
    public void startInputFromDBtoOnto(List<String> listOfSensorItemsInDB) {

        mySqlObj.startDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);
        System.out.println("1");

        for (String sensorItemInDB:listOfSensorItemsInDB) {

            mySqlObj.getFromTableLatest(sensorItemInDB); //ImportData from DB
            System.out.println("2");
            MORFullIndividual sensorIndivInOnto = sensorIndividualMap.get(sensorItemIndividualMap.get(sensorItemInDB));
            System.out.println("3");
            sensorIndivInOnto.readSemantic(); //perhaps do only once, as ontoName for all the sensorIndividualMap is same
            System.out.println("4");
            if (mySqlObj.getItemValue()) {
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", true, true);
            }
            else{
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", false, true);
            }
            System.out.println("5");
            sensorIndivInOnto.writeSemanticInconsistencySafe();
            System.out.println("6");
            sensorIndivInOnto.buildDataIndividual();
            System.out.println("7");
        }

        this.setIndividualWithTimestamp(this.getIndividual("Time_Now",ontoRef), new Timestamp(System.currentTimeMillis()));
        ontoRef.saveOntology(ontoFilePath);
        mySqlObj.stopDBConnection();
        System.out.println("9");
    }

    ///////////////-->      (Ontology Defining) methods    <--///////////////////////////

    /////////////--> Methods related to: Defining the kind of ontology
    //////////--> Methods that allow: Basic functions to access the ontology
    //////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    public PlacingOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoFilePath = filePath;
        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("0.1");
    }
    public void setIndividualWithTimestamp(MORFullIndividual individual, Timestamp timeStamp){

        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",String.valueOf(timeStamp));
        individual.writeSemanticInconsistencySafe();
    }
    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }
    public Timestamp getIndividualTimestamp(MORFullIndividual individual) {

        individual.readSemantic();
        OWLLiteral localNamedIndiv = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty("hasTimeStamp"));
        return Timestamp.valueOf(individual.getOWLName(localNamedIndiv));
    }
    public String getInference(MORFullIndividual individual, String objectPropertyName) {

        individual.readSemantic();
        individual.reason();    //Reasoning the PO for every taskOntology 'event' condition
        OWLNamedIndividual namedIndiv = individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }
    @Override
    public String getOntoReferenceName() {
        return String.valueOf(ontoRef);
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("PO thread begins, ID:" + Thread.currentThread().getId());
        this.startInputFromDBtoOnto(sensorItemsInDBList); //Makes the current state of Ontology based on live sensor values from DB
        this.modifyOntologyBasedOnMemory(logicInferredIndiv, logicInferredIndivTS, logicTimeIntervalT1Indiv, logicTimeIntervalT1TS, logicTimeIntervalT2Indiv, logicTimeIntervalT2TS);//Modifies the Ontology based on useful knowledge of the past moment(iteration/Heartbeat)
        //--> Now system ready with context based on current sensory input and past memory
        System.out.println("Current time is:" + new Timestamp(System.currentTimeMillis()));
        this.triggerEventBasedOnActivationCondition(eventListenersList);
        //--> Based on the current state of Ontology, commit to memory knowledge specified by the designer of the system
        // ie, the designer decides what is to be shown in the rear view mirror (we move forward based on the past)
        this.commitDesiredKnowledgeToMemory(memObjectPropList,memObjectIndivMap);
        System.out.println("PO thread ends, ID:" + Thread.currentThread().getId());
    }
    //INTERFACE:    OntologyHasMemory
    public void modifyOntologyBasedOnMemory(String logicInferredIndiv, Timestamp logicInferredIndivTS, String logicTimeIntervalT1Indiv, Timestamp logicTimeIntervalT1TS, String logicTimeIntervalT2Indiv, Timestamp logicTimeIntervalT2TS) {

        if(logicTimeIntervalT1TS.equals(null)){
            if (logicInferredIndivTS.before(logicTimeIntervalT2TS)){
                MORFullIndividual localIndiv1 = this.getIndividual(logicInferredIndiv,ontoRef);
                localIndiv1.readSemantic();
                localIndiv1.removeObject("before");
                localIndiv1.removeObject("after");
                localIndiv1.addObject("before","Time_Now");
                localIndiv1.writeSemanticInconsistencySafe();
                localIndiv1.saveOntology(ontoFilePath);
            }
        } else if (logicTimeIntervalT2TS.equals(null)){
            if (logicInferredIndivTS.after(logicTimeIntervalT1TS)){
                MORFullIndividual localIndiv2 = this.getIndividual(logicInferredIndiv,ontoRef);
                localIndiv2.readSemantic();
                localIndiv2.removeObject("before");
                localIndiv2.removeObject("after");
                localIndiv2.addObject("after","Time_Now");
                localIndiv2.writeSemanticInconsistencySafe();
                localIndiv2.saveOntology(ontoFilePath);
            }
        } else if (logicTimeIntervalT1TS.equals(null)&logicTimeIntervalT2TS.equals(null)){
            System.out.println("The individual:"+logicInferredIndiv+"can happen anytime");
        } else {
            System.out.println("Something can only happen between the times:"+logicTimeIntervalT1Indiv+" and "+logicTimeIntervalT2Indiv);
        }
    }
    public void commitDesiredKnowledgeToMemory(List<String> memObjectPropList, Map<String,String> memObjectIndivMap) {

        if(!memObjectPropList.isEmpty()) {
            for (String objProp : memObjectPropList) {
                String individualName = memObjectIndivMap.get(objProp);
                MORFullIndividual localIndiv = this.getIndividual(individualName, ontoRef);
                String inference = this.getInference(localIndiv, objProp);
                if (!Objects.equals(inference,null)) {
                    memObjectInferredIndivMap.put(objProp, commitWithTimestamp(memInferredIndivTimeStampMap, inference, new Timestamp(System.currentTimeMillis())));
                } else {
                    System.out.println("No inference to be saved for the desired knowledge!");
                }
            }
        } else {
            System.out.println("No 'desired knowledge to commit to memory' provided by user; for "+this.getOntoReferenceName()+" ontology");
        }
    }
//    public void makeTemporalLogicBasedOnMemory(void isStillIn, void time_now) {
//        /*
//            Here i will relate the inference to the temporal logic settings and save them perhaps in a list or map.
//            So that multiple inferences and their temporal logic settings can be used to modify the ontology.
//         */
//    }

    //INTERFACE:        SaveInMemory
    public Map<String,Timestamp> commitWithTimestamp(Map<String,Timestamp> toMemoryMap, String individualName, Timestamp timestamp) {

        toMemoryMap.put(individualName, timestamp);
        return toMemoryMap;
    }
    public void commitInferenceOf(String individualName, String objectPropertyName) {

        memObjectPropList.add(objectPropertyName);//this way because can save objectProperty as key
        memObjectIndivMap.put(objectPropertyName,individualName);//can have different 'objectProperty' key for the same value 'individual'
    }

    //INTERFACE:        RecollectFromMemory
    public String recallInferenceOf(String objectProperty) {

        String returnString = null;
        Map<String,Timestamp> localMap = memObjectInferredIndivMap.get(objectProperty);
        for(String iter:localMap.keySet()){
            logicInferredIndivTS = localMap.get(iter);
            logicInferredIndiv = iter;
            returnString =  iter;
        }
        return returnString;
    }

    //INTERFACE:    OntologyHasTemporalLogic
    public void hasDuration(String individualInOnto, String operator, float positiveTimeDuration) {

        if (operator.equals("=") & positiveTimeDuration==0){

            System.out.println("The individual:"+individualInOnto+"is a timeInstant");
        } else if (operator.equals("<")) {

            System.out.println("'<' operator not assigned any work YET!");
        } else if (operator.equals(">")) {

            System.out.println("'>' operator not assigned any work YET!");
        }

    }
    public void inTimeInterval(String nullOrIndivInOntoWithTime_t1, String nullOrIndivInOntoWithTime_t2) {

        if (!nullOrIndivInOntoWithTime_t1.equals("null")){
            logicTimeIntervalT1TS = this.getIndividualTimestamp(this.getIndividual(nullOrIndivInOntoWithTime_t1,ontoRef));
            logicTimeIntervalT1Indiv = nullOrIndivInOntoWithTime_t1;
        } else {
            logicTimeIntervalT1TS = null;
            logicTimeIntervalT1Indiv = nullOrIndivInOntoWithTime_t1;
        }
        if (!nullOrIndivInOntoWithTime_t2.equals("null")){
            logicTimeIntervalT2TS = this.getIndividualTimestamp(this.getIndividual(nullOrIndivInOntoWithTime_t2,ontoRef));
            logicTimeIntervalT2Indiv = nullOrIndivInOntoWithTime_t2;
        } else {
            logicTimeIntervalT2TS = null;
            logicTimeIntervalT2Indiv = nullOrIndivInOntoWithTime_t2;
        }
    }

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency
    @Override
    public void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {

        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }

    /////////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventInitiator
    public void triggerEventBasedOnActivationCondition(List<TaskOntology> listOfeventListeners){

        System.out.println("10");
        if(!listOfeventListeners.isEmpty()) {
            System.out.println("11");
            for (TaskOntology objTO : listOfeventListeners) {
                System.out.println("12");
                if (checkEventActivationCondition(objTO)) {
                    System.out.println("13");
                    objTO.startWithFreshMemory();//If memory 'list' here is having memory objTO.getEventActivationConditionIndivB()
                    //ElseIf memory 'list' does not have that then objTO.startWithOldMemory
                } else {
                    System.out.println("13.1: Did not activate thread->"+objTO.getOntoReferenceName());
                }
            }
        } else {
            System.out.println("No eventListeners exist of this Ontology!");
        }
    }
    public boolean checkEventActivationCondition(TaskOntology objectOfTO){

        System.out.println("12.5");
        MORFullIndividual localIndiv = getIndividual(objectOfTO.getEventActivationConditionIndivA(),ontoRef);
        String check = this.getInference(localIndiv,objectOfTO.getEventActivationConditionObjProp());
        System.out.println("12.9,Check:"+check+"indivB:"+objectOfTO.getEventActivationConditionIndivB());
        System.out.println("12.10"+Objects.equals(check,objectOfTO.getEventActivationConditionIndivB()));
        return Objects.equals(check,objectOfTO.getEventActivationConditionIndivB());
    }
    @Override
    public void hasEventListener(TaskOntology eventListener) {
        eventListenersList.add(eventListener);
        System.out.println("Listener Added!");
    }

    ///////////////-->      (Task Importer) methods       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //NONE






///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
    /////////////-->      (Data Importer) methods        <--///////////////////////////

    INTERFACE: MySqlDBInputLink

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    INTERFACE:    Runnable
    INTERFACE:    OntologyHasMemory
    INTERFACE:        SaveInMemory
    INTERFACE:        RecollectFromMemory
    INTERFACE:    OntologyHasTemporalLogic

    ////////--> Updating ontology with a given frequency

    INTERFACE: OntologyRunsWithFrequency

    ///////////--> Methods related to: Defining the link between ontologies

    INTERFACE: EventInitiator

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    NONE

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    NONE
*/
}
