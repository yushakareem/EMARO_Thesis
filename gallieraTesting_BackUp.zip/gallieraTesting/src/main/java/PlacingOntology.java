import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.*;

import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its sensorIndividualMap from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 * Note:To have the local memory here, the attributes do not need to be static because the PlacingOntology object never dies.
 *      Its like same object and infinite loop of run() with a particular frequency.
 *
 */

//Help: For reading through a set of objectProp results. Passing individuals from one onto to another
//        /*
//           METHOD 1.5 ... If i want to browse through a set. In object property
//         */
////       for( OWLNamedIndividual hh : iP.getDisjointIndividual()) {
////            if (hh.equals(iP.getOWLIndividual("dddd"))) {
////                .....
////                break;
////            }
////        }
//
//        /*
//           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
//         */
//
////        //This is how we construct a new IRI
////        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
////        "EO",
////        "src/main/resources/empty.owl",
////        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
////        true);
////
////        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
////        System.out.println("j2:"+ j2);
////        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
////        iP.writeSemantic();

public class PlacingOntology implements PlacingOntologyPrototype {

    ///////////////-->      (Data Importer) attributes        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    String DataBase_Name;
    String MySQL_UserName;
    String MySQL_Password;

    MySQLConnector mySqlObj = new MySQLConnector();

    List<String> sensorItemsInDBList = new ArrayList<>();
    Map<String, String> sensorItemIndividualMap = new HashMap<>();
    Map<String, MORFullIndividual> sensorIndividualMap = new HashMap<>();
    ///////////////-->      (Ontology Defining) attributes    <--///////////////////////////

    /////////////--> attributes related to: Defining the kind of ontology
    //////////--> attributes that allow: Basic functions to access the ontology
    //////////--> attributes that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> attributes that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    String ontoFilePath;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    //INTERFACE:        SaveInMemory
    //INTERFACE:        RecollectFromMemory
    List<String> memObjectPropList = new ArrayList<>();
    Map<String,String> memObjectIndivMap = new HashMap<>();
    Map<String,Map<String,Timestamp>> memObjectInferredIndivMap = new HashMap<>();
    Map<String,Timestamp> memInferredIndivTimeStampMap = new HashMap<>();

    //INTERFACE:    OntologyHasTemporalLogic
    String logicInferredIndiv;
    Timestamp logicInferredIndivTS;
    String logicTimeIntervalT1Indiv;
    Timestamp logicTimeIntervalT1TS;
    String logicTimeIntervalT2Indiv;
    Timestamp logicTimeIntervalT2TS;

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency

    /////////////--> attributes related to: Defining the link between ontologies

    //INTERFACE: EventInitiator
    List<TaskOntology> eventListenersList = new ArrayList<>();

    ///////////////-->      (Task Importer) attributes       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) attributes     <--////////////////////////////

    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////-->      (Data Importer) methods        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    @Override
    public void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase) {
        System.out.println("############# setInputLinkFromDBToOnto() #############");
        sensorItemIndividualMap.put(Sensor_ItemName_InDataBase,Sensor_IndividualName_InOntology);
        sensorItemsInDBList.add(Sensor_ItemName_InDataBase);
        sensorIndividualMap.put(Sensor_IndividualName_InOntology,this.getIndividual(Sensor_IndividualName_InOntology, ontoRef));
    }
    @Override
    public void setMySqlDBInputInfo(String database_Name, String mysql_UserName, String mysql_Password) {
        System.out.println("############# setMySqlDBInputInfo() #############");
        DataBase_Name = database_Name;
        MySQL_UserName = mysql_UserName;
        MySQL_Password = mysql_Password;
    }
    public void startInputFromDBtoOnto(List<String> listOfSensorItemsInDB) {
        System.out.println("############# startInputFromDBToOnto() #############");
        mySqlObj.startDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);

        for (String sensorItemInDB:listOfSensorItemsInDB) {

            mySqlObj.getFromTableLatest(sensorItemInDB); //ImportData from DB
            MORFullIndividual sensorIndivInOnto = sensorIndividualMap.get(sensorItemIndividualMap.get(sensorItemInDB));
            sensorIndivInOnto.readSemantic(); //perhaps do only once, as ontoName for all the sensorIndividualMap is same
            if (mySqlObj.getItemValue()) {
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", true, true);
            }
            else{
                sensorIndivInOnto.removeData("hasTimeStamp");
                sensorIndivInOnto.addData("hasTimeStamp", String.valueOf(mySqlObj.getItemTimeStamp()));
                sensorIndivInOnto.removeData("hasMotionBoolValue");
                sensorIndivInOnto.addData("hasMotionBoolValue", false, true);
            }
            sensorIndivInOnto.writeSemanticInconsistencySafe();
            sensorIndivInOnto.buildDataIndividual();
        }

        this.setIndividualWithTimestamp(this.getIndividual("Time_Now",ontoRef), new Timestamp(System.currentTimeMillis()));
        System.out.println("Time_Now got updated");
        ontoRef.synchronizeReasoner();
        ontoRef.saveOntology(ontoFilePath);
        mySqlObj.stopDBConnection();
    }

    ///////////////-->      (Ontology Defining) methods    <--///////////////////////////

    /////////////--> Methods related to: Defining the kind of ontology
    //////////--> Methods that allow: Basic functions to access the ontology
    //////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    public PlacingOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {
        System.out.println("############# PlacingOntology() #############");
        ontoFilePath = filePath;
        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
    }
    public void setIndividualWithTimestamp(MORFullIndividual individual, Timestamp timeStamp){
        System.out.println("############# setIndividualWithTimestamp() #############");
        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",String.valueOf(timeStamp));
        individual.writeSemanticInconsistencySafe();
    }
    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        System.out.println("############# getIndividual() #############");
        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }
    public Timestamp getIndividualTimestamp(MORFullIndividual individual) {

        individual.readSemantic();
        OWLLiteral localNamedIndiv = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty("hasTimeStamp"));
        return Timestamp.valueOf(individual.getOWLName(localNamedIndiv));
    }
    public String getInference(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("############# getInference() #############");
        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }
    @Override
    public String getOntoReferenceName() {
        System.out.println("############# getOntoRefName() #############");
        return String.valueOf(ontoRef);
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("\n############# run() #############\n");
        System.out.println("PO thread begins, ID:" + Thread.currentThread().getId());
        this.startInputFromDBtoOnto(sensorItemsInDBList); //Makes the current state of Ontology based on live sensor values from DB
        this.modifyOntologyBasedOnMemory(logicInferredIndiv, logicInferredIndivTS, logicTimeIntervalT1Indiv, logicTimeIntervalT1TS, logicTimeIntervalT2Indiv, logicTimeIntervalT2TS);//Modifies the Ontology based on useful knowledge of the past moment(iteration/Heartbeat)
        //--> Now system ready with context based on current sensory input and past memory
        this.triggerEventBasedOnActivationCondition(eventListenersList);
        //--> Based on the current state of Ontology, commit to memory knowledge specified by the designer of the system
        // ie, the designer decides what is to be shown in the rear view mirror (we move forward based on the past)
        this.commitDesiredKnowledgeToMemory(memObjectPropList,memObjectIndivMap);
        System.out.println("PO thread ends, ID:" + Thread.currentThread().getId());
    }
    //INTERFACE:    OntologyHasMemory
    public void modifyOntologyBasedOnMemory(String timeLogicIndiv, Timestamp timeLogicIndivTS, String timeLogicT1Indiv, Timestamp timeLogicT1TS, String timeLogicT2Indiv, Timestamp timeLogicT2TS) {

        System.out.println("############# modifyOntologyBasedOnMemory() #############");
        if (!Objects.equals(timeLogicIndiv,null)) {
            if (Objects.equals(timeLogicT1TS, null)) {
                System.out.println("timeLogicIndivTS: " + timeLogicIndivTS);
                System.out.println("timeLogicT2TS: " + timeLogicT2TS);
                System.out.println("timeLogicIndivTS.before(timeLogicT2TS): " + timeLogicIndivTS.before(timeLogicT2TS));
                if (timeLogicIndivTS.before(timeLogicT2TS)) {
                    MORFullIndividual localIndiv1 = this.getIndividual(timeLogicIndiv, ontoRef);
                    localIndiv1.readSemantic();
                    localIndiv1.removeObject("before");
                    localIndiv1.removeObject("after");
                    localIndiv1.addObject("before", "Time_Now");
                    localIndiv1.writeSemanticInconsistencySafe();
                    localIndiv1.saveOntology(ontoFilePath);
                }
            } else if (Objects.equals(timeLogicT2TS, null)) {
                if (timeLogicIndivTS.after(timeLogicT1TS)) {
                    MORFullIndividual localIndiv2 = this.getIndividual(timeLogicIndiv, ontoRef);
                    localIndiv2.readSemantic();
                    localIndiv2.removeObject("before");
                    localIndiv2.removeObject("after");
                    localIndiv2.addObject("after", "Time_Now");
                    localIndiv2.writeSemanticInconsistencySafe();
                    localIndiv2.saveOntology(ontoFilePath);
                }
            } else if (Objects.equals(timeLogicT1TS, null) & Objects.equals(timeLogicT2TS, null)) {
                System.out.println("The individual: " + timeLogicIndiv + " is not limited in the TimeInterval -> From:'" + timeLogicT1Indiv + "' To:'" + timeLogicT2Indiv + "'");
            } else {
                System.out.println("The individual: " + timeLogicIndiv + " is is strictly in the TimeInterval -> From:'" + timeLogicT1Indiv + "' To:'" + timeLogicT2Indiv + "'");
            }
        } else {
            System.out.println("No recollection of individual from memory, to which temporal-logic can be assigned!");
            System.out.println("Hence ontology not modified based on temporal-logic");
        }
    }
    public void commitDesiredKnowledgeToMemory(List<String> memObjectPropList, Map<String,String> memObjectIndivMap) {
        System.out.println("############# commitDesiredKnowledgeToMemory() #############");
        if(!memObjectPropList.isEmpty()) {
            for (String objProp : memObjectPropList) {
                String individualName = memObjectIndivMap.get(objProp);
                MORFullIndividual localIndiv = this.getIndividual(individualName, ontoRef);
                String inference = this.getInference(localIndiv, objProp);
                if (!Objects.equals(inference,null)) {
                    memObjectInferredIndivMap.put(objProp, commitWithTimestamp(memInferredIndivTimeStampMap, inference, new Timestamp(System.currentTimeMillis())));
                } else {
                    System.out.println("Desired 'inference to commit to Memory' is Null");
                }
            }
        } else {
            System.out.println("No 'desired knowledge to commit to memory' provided by user; for "+this.getOntoReferenceName()+" ontology");
        }
    }
//    public void makeTemporalLogicBasedOnMemory(void isStillIn, void time_now) {
//        /*
//            Here i will relate the inference to the temporal logic settings and save them perhaps in a list or map.
//            So that multiple inferences and their temporal logic settings can be used to modify the ontology.
//         */
//    }

    //INTERFACE:        SaveInMemory
    public Map<String,Timestamp> commitWithTimestamp(Map<String,Timestamp> toMemoryMap, String individualName, Timestamp timestamp) {
        System.out.println("############# commitWithTimestamp() #############");
        toMemoryMap.put(individualName, timestamp);
        return toMemoryMap;
    }
    public void commitInferenceOf(String individualName, String objectPropertyName) {
        System.out.println("############# commitInferenceOf() #############");
        memObjectPropList.add(objectPropertyName);//this way because can save objectProperty as key
        memObjectIndivMap.put(objectPropertyName,individualName);//can have different 'objectProperty' key for the same value 'individual'
    }

    //INTERFACE:        RecollectFromMemory
    public String recallInferenceOf(String objectProperty) {
        System.out.println("############# recallInferenceOf() #############");
        String returnString = null;
        Map<String,Timestamp> localMap = memObjectInferredIndivMap.get(objectProperty);
        if (!Objects.equals(localMap,null)) {
            for (String iter : localMap.keySet()) {
                logicInferredIndivTS = localMap.get(iter);
                logicInferredIndiv = iter;
                returnString = iter;
            }
        } else {
            System.out.println("Note: The infered individual must be of type 'time-entity' in the ontology");
            System.out.println("In this moment. Nothing in memory!");
            System.out.println("Inference related to the object property '"+objectProperty+"' is "+returnString);
        }
        return returnString;
    }

    //INTERFACE:    OntologyHasTemporalLogic
    public void hasDuration(String individualName, String operator, float positiveTimeDuration) {
        System.out.println("############# hasDuration() #############");
        if (!Objects.equals(individualName,null)) {
            if (operator.equals("=") & positiveTimeDuration == 0) {

                System.out.println("The individual (type:'time-entity'): '" + individualName + "' is a timeInstant");
            } else if (operator.equals("<")) {

                System.out.println("'<' operator not assigned any work YET!");
                System.out.println("The individual (type:'time-entity'): '" + individualName + "' is a timeInterval");
            } else if (operator.equals(">")) {

                System.out.println("'>' operator not assigned any work YET!");
                System.out.println("The individual (type:'time-entity'): '" + individualName + "' is a timeInterval");
            }
        } else {
            System.out.println("No individual (type:'time-entity') in memory, which can be liked with temporal-logic 'hasDuration'");
        }

    }
    public void inTimeInterval(String NullOrIndivWithTimeT1, String NullOrIndivWithTimeT2) {
        System.out.println("############# inTimeInterval() #############");
        if (!Objects.equals(NullOrIndivWithTimeT1,null)){
            logicTimeIntervalT1TS = this.getIndividualTimestamp(this.getIndividual(NullOrIndivWithTimeT1,ontoRef));
            logicTimeIntervalT1Indiv = NullOrIndivWithTimeT1;
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'After' the 'time-instant' -> "+NullOrIndivWithTimeT1);
        } else {
            logicTimeIntervalT1TS = null;
            logicTimeIntervalT1Indiv = NullOrIndivWithTimeT1;
        }
        if (!Objects.equals(NullOrIndivWithTimeT2,null)){
            logicTimeIntervalT2TS = this.getIndividualTimestamp(this.getIndividual(NullOrIndivWithTimeT2,ontoRef));
            logicTimeIntervalT2Indiv = NullOrIndivWithTimeT2;
            System.out.println(logicTimeIntervalT2Indiv+"-->"+logicTimeIntervalT2TS);
            System.out.println("TemporalLogic: The inferred individual linked with temporal-logic 'hasDuration' will be set 'Before' the 'time-instant' -> "+NullOrIndivWithTimeT2);
        } else {
            logicTimeIntervalT2TS = null;
            logicTimeIntervalT2Indiv = NullOrIndivWithTimeT2;
        }
    }

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency
    @Override
    public void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {
        System.out.println("############# startScheduledOntology() #############");
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }

    /////////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventInitiator
    public void triggerEventBasedOnActivationCondition(List<TaskOntology> listOfeventListeners){
        System.out.println("############# triggerEventBasedOnActivationCondition() #############");
        if(!listOfeventListeners.isEmpty()) {
            for (TaskOntology objTO : listOfeventListeners) {
                if (checkEventActivationCondition(objTO)) {
                    objTO.startWithFreshMemory();//If memory 'list' here is having memory objTO.getEventActivationConditionIndivB()
                    //ElseIf memory 'list' does not have that then objTO.startWithOldMemory
                } else {
                    System.out.println("Did not activate thread -> '"+objTO.getOntoReferenceName()+"'");
                }
            }
        } else {
            System.out.println("No eventListeners exist of this Ontology!");
        }
    }
    public boolean checkEventActivationCondition(TaskOntology objectOfTO){
        System.out.println("############# checkEventActivationCondition() #############");
        MORFullIndividual localIndiv = getIndividual(objectOfTO.getEventActivationConditionIndivA(),ontoRef);
        String inferredIndiv = this.getInference(localIndiv,objectOfTO.getEventActivationConditionObjProp());
        return Objects.equals(inferredIndiv,objectOfTO.getEventActivationConditionIndivB());
    }
    @Override
    public void hasEventListener(TaskOntology eventListener) {
        System.out.println("############# hasEventListener #############");
        eventListenersList.add(eventListener);
        System.out.println("Listener Added!");
    }

    ///////////////-->      (Task Importer) methods       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //NONE






///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
    /////////////-->      (Data Importer) methods        <--///////////////////////////

    INTERFACE: MySqlDBInputLink

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    INTERFACE:    Runnable
    INTERFACE:    OntologyHasMemory
    INTERFACE:        SaveInMemory
    INTERFACE:        RecollectFromMemory
    INTERFACE:    OntologyHasTemporalLogic

    ////////--> Updating ontology with a given frequency

    INTERFACE: OntologyRunsWithFrequency

    ///////////--> Methods related to: Defining the link between ontologies

    INTERFACE: EventInitiator

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    NONE

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    NONE
*/
}
