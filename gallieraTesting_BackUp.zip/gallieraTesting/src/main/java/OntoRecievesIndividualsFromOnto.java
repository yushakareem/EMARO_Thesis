public interface OntoRecievesIndividualsFromOnto {
}
