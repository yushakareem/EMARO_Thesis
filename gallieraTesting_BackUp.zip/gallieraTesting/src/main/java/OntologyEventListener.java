/**
 * Created by yushakareem on 25/07/17.
 */

public interface OntologyEventListener {
    void InitiateListener_eventLivingRoom();
    void InitiateListener_eventTableArea();
    void InitiateListener_eventKitchen();
    void InitiateListener_eventBedRoom();
    void InitiateListener_eventBathRoom();
    void InitiateListener_eventIsStillIn(String nameOfTheFurnitureOccupied);

    void ListensFor_eventLivingRoom();
    void ListensFor_eventTableArea();
    void ListensFor_eventKitchen();
    void ListensFor_eventBedRoom();
    void ListensFor_eventBathRoom();
    void ListensFor_eventIsStillIn();
}
