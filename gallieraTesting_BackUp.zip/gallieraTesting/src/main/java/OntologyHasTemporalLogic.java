import it.emarolab.amor.owlInterface.OWLReferences;

public interface OntologyHasTemporalLogic {

    Boolean hasDuration(boolean inference, String comparativeOperator, int positiveIntTimeDuration);

    TemporalLogic inTimeInterval(String interval_is_in_kitchen, String individualNameWithT1, String individualNameWithT2);

    boolean inferenceOf(String desiredIndivName, String desiredObjPropName);

    String recallIndiv();
    String recallObjProp();
    String recallTimeIntervalT1Indiv();
    String recallTimeIntervalT2Indiv();

    OWLReferences getTimeOntoRef();

}
