import it.emarolab.amor.owlInterface.OWLReferences;

public interface OntologyHasTemporalLogic {

    Boolean hasDuration(boolean inference, String comparativeOperator, int positiveIntTimeDuration);

    TemporalLogic inTimeInterval(String individualNameWithT1, String individualNameWithT2);

    boolean inferenceOf(String desiredIndivName, String desiredObjPropName);

    String recallIndiv();
    String recallObjProp();
    String recallTimeIntervalT1();
    String recallTimeIntervalT2();

    OWLReferences getTimeOntoRef();

}
