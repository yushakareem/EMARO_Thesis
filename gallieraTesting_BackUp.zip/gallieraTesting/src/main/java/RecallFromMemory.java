public interface RecallFromMemory {

    String recallDesiredKnowledgeObjProp();
    String recallDesiredKnowledgeIndiv();
}
