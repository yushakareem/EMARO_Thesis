public interface EventListenerOntology {

    void setActivationCondition(String individualA, String objectProperty, String individualB);

    String getEventActivationConditionIndivA();
    String getEventActivationConditionObjProp();
    String getEventActivationConditionIndivB();
}
