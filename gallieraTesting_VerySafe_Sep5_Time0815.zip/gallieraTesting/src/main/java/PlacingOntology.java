import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.*;

import java.sql.Timestamp;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by yushakareem on 24/07/17.
 *
 * What: This is the PlacingOntology Thread which coincides with the CentralThread.
 *       Fundamentally it is the spatial context of the smartHome environment in this moment.
 * Why: It infers all the spatial relationships between the entities in this ontology in this moment.
 *      Example: Person isBeingIn LivingRoom, Person isOccupying TVCouch, Person isDoingGesture Sitting, LivingRoom isNearTo TableArea, LivingRoom hasFurniture TVCouch .. etc
 * How: The centralThread initiates the PlacingOntology Thread which updates (with decided frequency) its sensorIndividualMap from the current Sensor values (Items) in the DB.
 *      The update of the PO is more frequent than the update of the MySQL-DB (whose frequency depends on the update from OpenHAB persistence).
 *
 * Note:To have the local memory here, the attributes do not need to be static because the PlacingOntology object never dies.
 *      Its like same object and infinite loop of run() with a particular frequency.
 *
 */

//        /*
//           METHOD 2 ... If A sematicRelation b. Passing an individual from one ontology to another [Facing Problem]
//         */
//
////        //This is how we construct a new IRI
////        OWLReferences ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFile(
////        "EO",
////        "src/main/resources/empty.owl",
////        "http://www.semanticweb.org/emaroLab/YushaKareem/empty",
////        true);
////
////        OWLNamedIndividual j2 = ontoRef.getOWLIndividual(iP.getInstance().getIRI().getRemainder()+"");
////        System.out.println("j2:"+ j2);
////        iP.setGround(new MORGrounding.IndividualInstance(ontoRef,j2));
////        iP.writeSemantic();

public class PlacingOntology implements PlacingOntologyPrototype {

    ///////////////-->      (Data Importer) attributes        <--///////////////////////////
    //INTERFACE: MySqlDBInputLink
    String DataBase_Name;
    String MySQL_UserName;
    String MySQL_Password;
    MySQLConnector mySqlObj = new MySQLConnector();
    List<String> sensorItemsInDBList = new ArrayList<>();
    Map<String, String> sensorItemIndividualMap = new HashMap<>();
    //Map<String, MORFullIndividual> sensorIndividualMap = new HashMap<>();
    ///////////////-->      (Ontology Defining) attributes    <--///////////////////////////
    /////////////--> attributes related to: Defining the kind of ontology
    //////////--> attributes that allow: Basic functions to access the ontology
    //////////--> attributes that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> attributes that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')
    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    OWLReferences ontoRef;
    //INTERFACE:    Runnable
    //INTERFACE:    OntologyHasMemory
    boolean flagExistsKnowledgeToActivateTemporalLogic;
    boolean flagActivateTemporalLogic;
    boolean flagCheckWhetherInTheIntervals;
    List<TemporalLogic> temporalLogicObjectsList = new ArrayList<>();

    List<MORFullIndividual> removalListIndivA = new ArrayList<>();
    List<OWLObjectProperty> removalListObjProp = new ArrayList<>();
    List<OWLNamedIndividual> removalListIndivB = new ArrayList<>();

    Map<String,String> memInferenceOfActivationConditionMap = new HashMap<>();

    MORFullIndividual toRemoveIndivA;
    OWLObjectProperty toRemoveObjProp;
    OWLNamedIndividual toRemoveIndivB;
    //INTERFACE:        SaveInMemory
    String memIndividualToActivateTemporalLogic;
    String memObjPropToActivateTemporalLogic;
    String memInferredIndivThatActivatedTemporalLogic;
    String memInferenceOfActivationCondition;
    //Timestamp memDesiredInferredIndivTS;
    //Map<String, String> memDesiredObjPropInferredIndivMap = new HashMap<>();
    //Map<String, Timestamp> memDesiredInferredIndivAndItsTSMap = new HashMap<>();

    //INTERFACE:        RecollectFromMemory
    //////////--> Updating ontology with a given frequency
    //INTERFACE: OntologyRunsWithFrequency
    /////////////--> attributes related to: Defining the link between ontologies
    //INTERFACE: EventInitiatorOntology
    List<TaskOntology> eventListenersList = new ArrayList<>();
    String ontoObjNameForTrigger;
    ///////////////-->      (Task Importer) attributes       <--////////////////////////////
    //NONE
    ///////////////-->      (Task Dispatcher) attributes     <--////////////////////////////
    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    ///////////////-->      (Data Importer) methods        <--///////////////////////////

    //INTERFACE: MySqlDBInputLink
    @Override
    public void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setInputLinkFromDBtoOnto()");
        sensorItemIndividualMap.put(Sensor_ItemName_InDataBase,Sensor_IndividualName_InOntology);
        sensorItemsInDBList.add(Sensor_ItemName_InDataBase);
        //sensorIndividualMap.put(Sensor_IndividualName_InOntology,this.getIndividual(Sensor_IndividualName_InOntology, ontoRef));
    }
    @Override
    public void setMySqlDBInputInfo(String database_Name, String mysql_UserName, String mysql_Password) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setMySqlDBInputInfo()");
        DataBase_Name = database_Name;
        MySQL_UserName = mysql_UserName;
        MySQL_Password = mysql_Password;
    }
    public void startInputFromDBtoOnto(List<String> listOfSensorItemsInDB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startInputFromDBtoOnto()");

        mySqlObj.startDBConnection(DataBase_Name, MySQL_UserName, MySQL_Password);

        for (String sensorItemInDB:listOfSensorItemsInDB) {

            if (sensorItemInDB.equalsIgnoreCase("Item20")) {
                mySqlObj.getFromTableLatestDouble(sensorItemInDB); //ImportData from DB
                String sensorIndivInOnto = sensorItemIndividualMap.get(sensorItemInDB);
                System.out.println("===========Entered======");
                System.out.println("===========TS======"+mySqlObj.getItemTimeStamp());
                System.out.println("===========intVAL======"+(int) mySqlObj.getItemValueDouble());
                setSensorIndivTimeStamp(sensorIndivInOnto, String.valueOf(mySqlObj.getItemTimeStamp()));
                setIndividualWithDataPropInt(getIndividual(sensorIndivInOnto,ontoRef),"hasBrightnessIntValue", (int) mySqlObj.getItemValueDouble());

            } else {
                mySqlObj.getFromTableLatestBool(sensorItemInDB); //ImportData from DB
                String sensorIndivInOnto = sensorItemIndividualMap.get(sensorItemInDB);

                if (mySqlObj.getItemValueBool()) {
                    setSensorIndivTimeStamp(sensorIndivInOnto, String.valueOf(mySqlObj.getItemTimeStamp()));
                    setSensorIndivBoolValue(sensorIndivInOnto, "hasMotionBoolValue", true);
                } else {
                    setSensorIndivTimeStamp(sensorIndivInOnto, String.valueOf(mySqlObj.getItemTimeStamp()));
                    setSensorIndivBoolValue(sensorIndivInOnto, "hasMotionBoolValue", false);
                }
            }

            //buildDataIndividual(); PERHAPS I HAVE TO >>> FIND OUT!!
        }

        //this.setIndividualWithTimestamp(this.getIndividual("Time_Now",ontoRef), new Timestamp(System.currentTimeMillis()));
        synchronizeAndSaveOnto();
        mySqlObj.stopDBConnection();
    }

    ///////////////-->      (Ontology Defining) methods    <--///////////////////////////

    /////////////--> Methods related to: Defining the kind of ontology
    //////////--> Methods that allow: Basic functions to access the ontology
    //////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    //////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    public PlacingOntology(String OntoReferenceName, String filePath, String ontologyPath, Boolean bufferingReasoner) {

        ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                OntoReferenceName,
                filePath,
                ontologyPath,
                bufferingReasoner
        );
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # DEFINED AS # PlacingOntology()");
    }

    //INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    public void updateBasedOnCurrentSensoryState(List<String> sensorItemsInDBList) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnCurrentSensoryState()");

        this.startInputFromDBtoOnto(sensorItemsInDBList);
    }

    @Override
    public void updateBasedOnCurrentSensoryState(Map<String, OntologyPrototype> ontoToOntoInputMap) {}// NOT USED

    @Override
    public void setSensorIndivTimeStamp(String sensorIndividual, String timestamp) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        setIndividualWithTimestamp(localIndiv,timestamp);
    }

    @Override
    public void setIndividualWithTimestamp(MORFullIndividual individual, String timeStamp){
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");


        individual.readSemantic();
        individual.removeData("hasTimeStamp");
        individual.addData("hasTimeStamp",timeStamp);
        System.out.println(individual);
        individual.writeSemantic();
    }

    public void setIndividualWithDataPropInt(MORFullIndividual individual, String dataProperty, int value){
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithTimestamp()");


        individual.readSemantic();
        individual.removeData(dataProperty);
        individual.addData(dataProperty,value);
        System.out.println(individual);
        individual.writeSemantic();
    }

    @Override
    public void setSensorIndivBoolValue(String sensorIndividual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setSensorIndivBoolValue()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual, ontoRef);
        setIndividualWithDataPropBool(localIndiv,dataPropName,boolDataValue);
    }

    @Override
    public void setIndividualWithDataPropBool(MORFullIndividual individual, String dataPropName, boolean boolDataValue) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setIndividualWithDataPropBool()");

        individual.readSemantic();
        individual.removeData(dataPropName);
        individual.addData(dataPropName,boolDataValue,true);
        individual.writeSemantic();
    }

    private void setKnowledgeCleanerForOnto(MORFullIndividual indivA, OWLObjectProperty objProp, OWLNamedIndividual indivB) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setKnowledgeCleanerForOnto()");

        removalListIndivA.add(indivA);
        removalListObjProp.add(objProp);
        removalListIndivB.add(indivB);
    }

    public void synchronizeAndSaveOnto() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # synchronizeAndSaveOnto()");
        getOntoRef().synchronizeReasoner();
        getOntoRef().saveOntology(getOntoRef().getFilePath());
    }
    @Override
    public MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividual()");

        return new MORFullIndividual(
                individualName,
                ontoRef
        );
    }
    public String getIndividualTimestamp(MORFullIndividual individual) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getIndividualTimestamp()");
        return getDataPropInference(individual,"hasTimeStamp");
    }

    @Override
    public boolean getSensorIndivBoolValue(String sensorIndividualName, String dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getSensorIndivBoolValue()");
        MORFullIndividual sensorIndividual = getIndividual(sensorIndividualName,ontoRef);
        return Boolean.parseBoolean(getDataPropInference(sensorIndividual,dataPropName));
    }

    @Override
    public String getDataPropInference(MORFullIndividual individual, String dataPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getDataPropInference()");

        individual.readSemantic();
        OWLLiteral data = individual.getDataSemantics().getLiteral(individual.getOWLDataProperty(dataPropName));
        return data.getLiteral();//individual.getOWLName(data);
    }

    @Override
    public String getSensorIndivTimeStamp(String sensorIndividual) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getSensorIndivTimeStamp()");

        MORFullIndividual localIndiv = getIndividual(sensorIndividual,ontoRef);
        return getDataPropInference(localIndiv, "hasTimeStamp");
    }

    public String getObjPropInference(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInference()");

        individual.readSemantic();
        OWLNamedIndividual namedIndiv = individual.getObject(objectPropertyName);//individual.getObjectSemantics().getLink(individual.getOWLObjectProperty(objectPropertyName));
        return individual.getOWLName(namedIndiv);
    }
    public Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, String objectPropertyName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # getObjPropInferences()");
        individual.readSemantic();
        return individual.getObjects(objectPropertyName);
    }
    @Override
    public OWLReferences getOntoRef() {
        return ontoRef;
    }

    //INTERFACE:    Runnable
    @Override
    public void run() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+"\n\n # run()");
        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread begins");

        /*1*/this.updateBasedOnCurrentSensoryState(sensorItemsInDBList);//Makes the current state of Ontology based on live sensor values from DB
        /*2*/this.checkInferenceToActivateTemporalLogic(recallIndivToActivateTemporalLogic(), recallObjPropToActivateTemporalLogic());
        /*3*/if (getFlagActivateTemporalLogic()){
            this.updateBasedOnMemoryAndTemporalLogic(temporalLogicObjectsList);
            setFlagActivateTemporalLogic(false);
        }//--> Now system ready with context based on current sensory input and past memory
        /*4*/this.inferAndTriggerEvents(eventListenersList);

        System.out.println("--> "+this.getOntoRef().getReferenceName()+" # thread ends\n\n");
    }

    //INTERFACE:    OntologyHasMemory

    public void updateBasedOnMemoryAndTemporalLogic(List<TemporalLogic> temporalLogicForMemoryList) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # updateBasedOnMemoryAndTemporalLogic()");

        for (TemporalLogic timeMemObj:temporalLogicForMemoryList) {
            startTimeMemoryLogic(timeMemObj);
            synchronizeAndSaveOnto();
        }
    }
    public void startTimeMemoryLogic(TemporalLogic temporalObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startTimeMemoryLogic()");
        /*
            t prefix means time
         */

        //Update TimeNow so that it is in the true now.
        setIndividualWithTimestamp(getIndividual("Time_Now", ontoRef), String.valueOf(new Timestamp(System.currentTimeMillis())));

        //Time Interval T1
        OWLNamedIndividual tIntervalT1NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT1Indiv()); //PERHAPS USE THIS LOGIC TO GET AN INDIVIDUAL ALWAYS
        Timestamp T1TS;

        //Time Interval T2
        OWLNamedIndividual tIntervalT2NamedIndiv = ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT2Indiv());
        Timestamp T2TS;

        //Time Ontology object properties
        OWLObjectProperty objPropBefore = temporalObj.getTimeOntoRef().getOWLObjectProperty("before");
        OWLObjectProperty objPropAfter = temporalObj.getTimeOntoRef().getOWLObjectProperty("after");

        //Individual and ObjectProperty given by user
        String tIndiv = temporalObj.recallIndiv(); //Human
        MORFullIndividual tIndivFull = getIndividual(tIndiv, ontoRef); //Human
        String tObjProp = temporalObj.recallObjProp(); //isStillIn

        //Removing All the old before's and after's, so that they do not have influence in the NOW
        //System.out.println(getObjPropInference(tIndivFull, tObjProp)); //THERE CAN BE TWO INFERENCE (Because the way swrl rules are written)

        Set<OWLNamedIndividual> tInferredIndivSet = getObjPropInferences(tIndivFull,tObjProp);//THERE CAN BE TWO INFERENCE (Because the way swrl rules are written)

        for (OWLNamedIndividual tInferredIndiv : tInferredIndivSet) {

            MORFullIndividual localIndivFull = new MORFullIndividual(tInferredIndiv, ontoRef);
            localIndivFull.readSemantic();
            //Breaker of old knowledge:
            try {
                System.out.println("============= Removing OLD Knowledge ============");
                System.out.println(toRemoveIndivA);
                //toRemoveIndivA.readSemantic();
                System.out.println("THE SAME: "+toRemoveIndivA);
                localIndivFull.removeObject(objPropBefore,ontoRef.getOWLIndividual(temporalObj.recallTimeIntervalT2Indiv()));
                System.out.println(toRemoveIndivA);
                localIndivFull.writeSemantic();
                synchronizeAndSaveOnto();
            } catch (NullPointerException a) {
                System.out.println("no knowledge to be removed (Null pointer exception)");
            }
        }
//        synchronizeAndSaveOnto();


        MORFullIndividual tInferredIndivFull = getIndividual(getObjPropInference(getIndividual(tIndiv, ontoRef), tObjProp), ontoRef);//AT THIS STAGE THERE SHOULD BE A SINGLE INFERENCE (Because influence of rules removed)

        //TimeStamp for Inferred Individual obtained by checking its Sensor TimeStamp
        Timestamp tInferredIndivTS;

        String sensorInferredIndiv = getObjPropInference(tInferredIndivFull, "isDetectedBy");

        tInferredIndivTS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(sensorInferredIndiv, ontoRef)));

        String T1Name = temporalObj.recallTimeIntervalT1Indiv();
        String T2Name = temporalObj.recallTimeIntervalT2Indiv();

        if (Objects.equals(T1Name, null)) {

            T2TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T2Name, ontoRef)));

            if (tInferredIndivTS.before(T2TS)) {
                tInferredIndivFull.addObject(objPropBefore, ontoRef.getOWLIndividual(T2Name));
                tInferredIndivFull.writeSemantic();

                toRemoveIndivA=tInferredIndivFull;
                toRemoveObjProp=objPropBefore;
                toRemoveIndivB=ontoRef.getOWLIndividual(T2Name);
            } else {
                System.out.println("--> The TS of inferredIndiv is before timeInterval T2");
            }
        } else if (Objects.equals(T2Name, null)) {

            T1TS = Timestamp.valueOf(getIndividualTimestamp(getIndividual(T1Name, ontoRef)));

            if (tInferredIndivTS.after(T1TS)) {

                tInferredIndivFull.addObject(objPropAfter, ontoRef.getOWLIndividual(T1Name));
                tInferredIndivFull.writeSemantic();
            } else {

                System.out.println("--> The TS of inferredIndiv is after timeInterval T1");
            }
        } else if (Objects.equals(T1Name, null) & Objects.equals(T2Name, null)) {

            System.out.println("--> The inferredIndiv is not limited to the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
        } else {

            System.out.println("--> The inferredIndiv is strictly in the TimeInterval -> From:'" + T1Name + "' To:'" + T2Name + "'");
        }
    }

    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # setTemporalLogic()");
        if (checkHasDuration) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }
    public void setTemporalLogic(Boolean checkHasDuration, TemporalLogic temporalLogicObj, Boolean checkWhetherInTheIntervals) {
        flagCheckWhetherInTheIntervals = checkWhetherInTheIntervals;
        if (checkHasDuration&checkWhetherInTheIntervals) {
            temporalLogicObjectsList.add(temporalLogicObj);
        }
    }
    public void setFlagExistsKnowledgeToActivateTemporalLogic(boolean flagExistsKnowledgeToActivateTemporalLogic) {
        this.flagExistsKnowledgeToActivateTemporalLogic = flagExistsKnowledgeToActivateTemporalLogic;
    }
    public boolean getFlagExistsKnowledgeToActivateTemporalLogic() {
        return flagExistsKnowledgeToActivateTemporalLogic;
    }
    public void setFlagActivateTemporalLogic(boolean flagActivateTemporalLogic) {
        this.flagActivateTemporalLogic = flagActivateTemporalLogic;
    }
    public boolean getFlagActivateTemporalLogic() {
        return flagActivateTemporalLogic;
    }

    //INTERFACE:        CommitToMemory
    public void commitToActivateTemporalLogic(String individualName, String objPropName) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # commitToActivateTemporalLogic()");
        memIndividualToActivateTemporalLogic = individualName;
        memObjPropToActivateTemporalLogic = objPropName;
        if (!Objects.equals(memIndividualToActivateTemporalLogic,null)&!Objects.equals(memObjPropToActivateTemporalLogic,null)) {
            System.out.println("User desired individual and objectProperty saved to memory.");
            setFlagExistsKnowledgeToActivateTemporalLogic(true);
        } else {
            System.out.println("Please enter the parameters properly!");
        }
    }
    public void checkInferenceToActivateTemporalLogic(String indivToActivateTemporalLogic, String objPropToActivateTemporalLogic){
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # checkInferenceToActivateTemporalLogic()");

        if (/**/getFlagExistsKnowledgeToActivateTemporalLogic()) {

            MORFullIndividual localIndiv = this.getIndividual(indivToActivateTemporalLogic, ontoRef);
            String memInferredIndivToActivateTemporalLogic = this.getObjPropInference(localIndiv, objPropToActivateTemporalLogic);
            if (!Objects.equals(memInferredIndivToActivateTemporalLogic,null)) {
                System.out.println("--> INFERENCE EXISTS!! TemporalLogic will be activated!");
                //memInferredIndivThatActivatedTemporalLogic = memInferredIndivToActivateTemporalLogic;
                setFlagActivateTemporalLogic(true);
            } else {
                //memInferredIndivThatActivatedTemporalLogic = null;
                System.out.println("--> For OntoMemory: "+indivToActivateTemporalLogic+" "+objPropToActivateTemporalLogic+" --> "+ memInferredIndivToActivateTemporalLogic +", INFERENCE CHECKED FOR UPDATE of '"+this.getOntoRef().getReferenceName()+" ontology' BASED ON MEMORY AND TEMPORAL LOGIC");
            }
        } else {
            System.out.println("--> For OntoMemory: No desired knowledge to infer the ontology with, hence no modification will be done to '"+this.getOntoRef().getReferenceName()+"' ontology.");
        }
    }

    //INTERFACE:        RecallFromMemory
    public String recallObjPropToActivateTemporalLogic() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallObjPropToActivateTemporalLogic()");
        return memObjPropToActivateTemporalLogic;
    }
    public String recallIndivToActivateTemporalLogic() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallIndivToActivateTemporalLogic()");
        return memIndividualToActivateTemporalLogic;
    }

    public String recallInferrenceThatActivatedTemporalLogic() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallInferredIndivToActivateTemporalLogic()");

        return memInferredIndivThatActivatedTemporalLogic;
    }

    //////////--> Updating ontology with a given frequency

    //INTERFACE: OntologyRunsWithFrequency
    @Override
    public void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # startScheduledOntology()");
        final ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(corePoolSize);
        scheduler.scheduleAtFixedRate(RunnableOntologyObject, initialDelay, period, unit);
    }

    /////////////--> Methods related to: Defining the link between ontologies

    //INTERFACE: EventInitiatorOntology
    public void inferAndTriggerEvents(List<TaskOntology> listOfeventListeners){
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # inferAndTriggerEvents()");
        if(!listOfeventListeners.isEmpty()) {
            for (TaskOntology objTO : listOfeventListeners) {
                if (this.checkEventActivationConditionInference(objTO)) {//Human isStillIn
                    if (Objects.equals(recallInferenceOfActivationCondition(objTO),getCurrentInferenceOfActivationCondition(objTO))) {//make it null
//                        if (Objects.equals(recallOntoObjName(),objTO.getOntoRef().getReferenceName()))
                            objTO.startWithOldMemory();//If memory 'list' here is having memory objTO.getEventActivationConditionIndivB()
                    } else {
                        objTO.startWithFreshMemory();
                        commitInferenceOfActivationCondition(objTO);
                    }//The way this If-Else is working is very specific to the (smart-home)
                } else {
                    System.out.println("--> Did not activate thread -> '"+objTO.getOntoRef()+"'");
                }
            }
        } else {
            System.out.println("--> No eventListeners exist of this Ontology!");
        }
    }

    private void commitOntoObjName(TaskOntology objTO) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # commitOntoObjName()");

        this.ontoObjNameForTrigger = objTO.getOntoRef().getReferenceName();
    }

    private String recallOntoObjName() {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # recallOntoObjNameOntoObjName()");

        return ontoObjNameForTrigger;
    }

    public void commitInferenceOfActivationCondition(TaskOntology objTO) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" commitInferenceOfActivationCondition()");

        memInferenceOfActivationConditionMap.put(objTO.getOntoRef().getReferenceName(),getCurrentInferenceOfActivationCondition(objTO));
        //memInferenceOfActivationCondition = getCurrentInferenceOfActivationCondition(objTO);
    }

    public String recallInferenceOfActivationCondition(TaskOntology objTO) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" recallInferenceOfActivationCondition()");

        return memInferenceOfActivationConditionMap.get(objTO.getOntoRef().getReferenceName());
    }

    public String getCurrentInferenceOfActivationCondition(TaskOntology objTO) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" getCurrentInferenceOfActivationCondition()");

        return getObjPropInference(getIndividual(objTO.getEventActivationConditionIndivA(),ontoRef),objTO.getEventActivationConditionObjProp());
    }

    public boolean checkEventActivationConditionInference(TaskOntology objectOfTO){
        /*
        Confirming if the ontology is actually in this sate (Based on activation condition)
         */

        System.out.println("# "+this.getOntoRef().getReferenceName()+" checkEventActivationConditionInference()");

        MORFullIndividual localIndiv = getIndividual(objectOfTO.getEventActivationConditionIndivA(),ontoRef);
        String inferredIndiv = getObjPropInference(localIndiv,objectOfTO.getEventActivationConditionObjProp());
        return Objects.equals(inferredIndiv,objectOfTO.getEventActivationConditionIndivB());
    }
    @Override
    public void hasEventListener(TaskOntology eventListener) {
        System.out.println("# "+this.getOntoRef().getReferenceName()+" # hasEventListener");
        eventListenersList.add(eventListener);
        System.out.println("--> Listener Added!");
    }

    ///////////////-->      (Task Importer) methods       <--////////////////////////////

    //NONE

    ///////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    //NONE

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
    /////////////-->      (Data Importer) methods        <--///////////////////////////

    INTERFACE: MySqlDBInputLink

    /////////////-->      (Ontology Defining) methods    <--///////////////////////////

    ///////////--> Methods related to: Defining the kind of ontology
    ////////--> Methods that allow: Basic functions to access the ontology
    ////////--> Methods that allow: Modifying the ontology based on 'current moment' update coming from (Data Importer)
    ////////--> Methods that allow: Modifying the ontology based on local-ontology-memory and temporal-logic(which relates 'current-moment' with 'past-moment')

    INTERFACE: OntologyPrototype                          <--/// Has the heart: run() //
    INTERFACE:    Runnable
    INTERFACE:    OntologyHasMemory
    INTERFACE:        CommitToMemory
    INTERFACE:        RecallFromMemory

    ////////--> Updating ontology with a given frequency

    INTERFACE: OntologyRunsWithFrequency

    ///////////--> Methods related to: Defining the link between ontologies

    INTERFACE: EventInitiatorOntology

    /////////////-->      (Task Importer) methods       <--////////////////////////////

    NONE

    /////////////-->      (Task Dispatcher) methods     <--////////////////////////////

    NONE
*/

    public void testing() {

        /* DATE RELATED STUFF FOR TIME INTERVAL FIXING*/
//        Date d = new Date();
//        SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:sss");
//        sdfTime.format(d);//17:21:003
//
//        SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd");
//        sdfDate.format(d);//2017-07-25
//
//        System.out.println("Printting String connection of Date and time: "+sdfDate.format(d)+" "+sdfTime.format(d));
//        System.out.println("Printing Timestamp: "+Timestamp.valueOf(sdfDate.format(d)+" "+sdfTime.format(d)));
        /* MYSQL OUTPUT RELATED*/
        //Use database, if it does not exist create one
        //Use table, if it does not exist create one
        //Put string and TimeStamp

//        System.out.println("##1");
//        mySqlObj.startDBConnectionOrCreateNew("GallieraActivityDB","root","nepo");
//        System.out.println("##2");
//        mySqlObj.setIntoTable("Activities4","Activity_Making_Iftar",new Timestamp(System.currentTimeMillis()));
//        System.out.println("##3");
//        mySqlObj.stopDBConnection();
//        System.out.println("##4");
        //TimeUnit ret = TimeUnit.MINUTES;

//        Timestamp t1 = Timestamp.valueOf("2017-07-25 18:17:00");
//        Timestamp t2 = Timestamp.valueOf("2017-07-25 18:30:30");

//        int T2 = t2.getMinutes();
//        int T1 = t1.getMinutes();
//        int T3 = T2 - T1;
//        System.out.println("t1 minutes: "+t1.getMinutes()+" t2 minutes: "+t2.getMinutes()+" Diff: "+T3);

//        long T2 = t2.getTime();
//        long T1 = t1.getTime();
//        long diff = (T2 - T1);
//        long diffSeconds = diff / 1000 % 60;
//        long diffMinutes = diff / (60 * 1000) % 60;
//        long diffHours = diff / (60 * 60 * 1000) % 24;
//        long diffDays = diff / (24 * 60 * 60 * 1000);
//
//        System.out.print(diffDays + " days, ");
//        System.out.print(diffHours + " hours, ");
//        System.out.print(diffMinutes + " minutes, ");
//        System.out.print(diffSeconds + " seconds.");
//
//        Integer posInt = 6;
//        long timeDiff = 6;
//        System.out.println("Comparative: "+(timeDiff==posInt));
        String a = "A_F_Bed";
        String b = "S_M_LivingRoom";

        System.out.println("Check: "+a.startsWith("S_") );
    }

}
