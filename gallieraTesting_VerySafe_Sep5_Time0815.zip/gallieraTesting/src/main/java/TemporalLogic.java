import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.amor.owlInterface.OWLReferencesInterface;

import java.util.Objects;
import java.util.concurrent.TimeUnit;

public class TemporalLogic implements OntologyHasTemporalLogic {

    String indiv;
    String objProp=null;
    String dataProp=null;

    String timeLogicBiggerTimeIntervalIndiv;

    String timeLogicInterval;
    String timeLogicT1Indiv;
    String timeLogicT2Indiv;

    String comparativeOperator;
    Integer periodOfTimeDuraion;
    TimeUnit unitOfTimeDuration;

    PlacingOntology objOfIncomingOnto;

    OWLReferences ontoRef;

    // REMOVE THE FIRST PARAMETER OF PLACING ONTOLOGY .. NOT USED
    public TemporalLogic(String timeOntoRefName,String timeOntoFilePath,String timeOntoPath,boolean timeOntoBufferingReasoner) {
        System.out.println("# TL # TemporalLogic()");

        this.ontoRef = OWLReferencesInterface.OWLReferencesContainer.newOWLReferenceFromFileWithPellet(
                timeOntoRefName,
                timeOntoFilePath,
                timeOntoPath,
                timeOntoBufferingReasoner
        );
    }

    public Boolean checkInTheDuration(boolean inference, String comparativeOperator, Integer positiveTimeDuration, TimeUnit unit) {
        System.out.println("# TL # checkInTheDuration()");
        if (inference) {

            if (Objects.equals(comparativeOperator,"<")) {
                System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, 'within'/before '" + positiveTimeDuration + "' '" + unit + "' (always checking), it will cause activity recognition and save to DB");
                this.comparativeOperator = comparativeOperator;
                this.periodOfTimeDuraion = positiveTimeDuration;
                this.unitOfTimeDuration = unit;
            } else if (Objects.equals(comparativeOperator,"=") & !Objects.equals(positiveTimeDuration,0)) {
                System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, every '" + positiveTimeDuration + "' '" + unit + "' (there is a check), it will cause activity recognition and save to DB");
                this.comparativeOperator = comparativeOperator;
                this.periodOfTimeDuraion = positiveTimeDuration;
                this.unitOfTimeDuration = unit;
            } else if (Objects.equals(comparativeOperator,"=") & Objects.equals(positiveTimeDuration,0)) {
                System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, always checking (ie, checking every 'instant' as duration is 'zero'), it will cause activity recognition and save to DB");
                this.comparativeOperator = comparativeOperator;
                this.periodOfTimeDuraion = positiveTimeDuration;
                this.unitOfTimeDuration = unit;
            } else if (Objects.equals(comparativeOperator,">")) {
                System.out.println("--> TemporalLogic: Whenever there is 'inference' of this temporal object, 'without'/after '" + positiveTimeDuration + "' '" + unit + "' (always checking), it will cause activity recognition and save to DB");
                this.comparativeOperator = comparativeOperator;
                this.periodOfTimeDuraion = positiveTimeDuration;
                this.unitOfTimeDuration = unit;
            } else {
                System.out.println("--> TemporalLogic: Comparative operator provided, is not part of the system defined set of operators! Please check!");
            }
        }
        return true;
    }


    public TemporalLogic isInTimeInterval(String indivNameTimeInstantT1, String indivNameTimeInstantT2) {
        System.out.println("# TL # isInTimeInterval()");
        if (!Objects.equals(indivNameTimeInstantT1,null)){
            System.out.println("--> TemporalLogic: The inferred individual linked with temporal-logic 'checkInTheDuration' will be set 'After' the 'time-instant' -> "+indivNameTimeInstantT1);
        } else if (!Objects.equals(indivNameTimeInstantT2,null)){
            System.out.println("-->TemporalLogic: The inferred individual linked with temporal-logic 'checkInTheDuration' will be set 'Before' the 'time-instant' -> "+indivNameTimeInstantT2);
        } else {
            System.out.println("--> TemporalLogic: Time Interval not defined");
        }
        this.timeLogicT1Indiv = indivNameTimeInstantT1;
        this.timeLogicT2Indiv = indivNameTimeInstantT2;
        return this;
    }

    public TemporalLogic isInTimeInterval(String indivNameTimeInterval, String indivNameTimeInstantT1, String indivNameTimeInstantT2) {
        System.out.println("# TL # isInTimeInterval()");
        if (!Objects.equals(indivNameTimeInstantT1,null)){
            System.out.println("--> TemporalLogic: The inferred individual linked with temporal-logic 'checkInTheDuration' will be set 'After' the 'time-instant' -> "+indivNameTimeInstantT1);
        } else if (!Objects.equals(indivNameTimeInstantT2,null)){
            System.out.println("--> TemporalLogic: The inferred individual linked with temporal-logic 'checkInTheDuration' will be set 'Before' the 'time-instant' -> "+indivNameTimeInstantT2);
        } else {
            System.out.println("--> TemporalLogic: Time Interval not defined");
        }
        this.timeLogicT1Indiv = indivNameTimeInstantT1;
        this.timeLogicT2Indiv = indivNameTimeInstantT2;
        this.timeLogicInterval = indivNameTimeInterval;
        return this;
    }

    public Boolean isInABiggerTimeInterval(String indivHoldingBigTimeIntervals) {
        System.out.println("# TL # isInABiggerTimeInterval()");
        boolean flag = false;
        if (!Objects.equals(indivHoldingBigTimeIntervals,null)) {
            this.timeLogicBiggerTimeIntervalIndiv = indivHoldingBigTimeIntervals;
            flag = true;
        }
        return flag;
    }

    public boolean inferenceOf(String desiredIndivName, String desiredObjPropName, String desiredDataPropName) {
        System.out.println("# TL # inferenceOf()");
        boolean flag = false;
        if (!Objects.equals(desiredIndivName,null)&!Objects.equals(desiredObjPropName,null)&Objects.equals(desiredDataPropName,null)) {
            this.indiv = desiredIndivName;
            this.objProp = desiredObjPropName;
            flag = true;
        } else if (!Objects.equals(desiredIndivName,null)&Objects.equals(desiredObjPropName,null)&!Objects.equals(desiredDataPropName,null)) {
            this.indiv = desiredIndivName;
            this.dataProp = desiredDataPropName;
            flag = true;
        } else {
            System.out.println("--> TemporalLogic: Proper parameters not entered for checkInTheDuration(inferenceOf(___,___),,)");
        }
        return flag;
    }

    public String recallIndiv() {
        System.out.println("# TL # recallIndiv()");
        return indiv;}

    public String recallObjProp() {
        System.out.println("# TL # recallObjProp()");
        return objProp;}

    public String recallDataProp() {
        System.out.println("# TL # recallDataProp()");
        return dataProp;}

    public String recallComparativeOperator() {
        System.out.println("# TL # recallComparativeOperator()");
        return comparativeOperator;
    }

    public Integer recallPositiveTimeDuration() {
        System.out.println("# TL # recallPositiveTimeDuration()");
        return periodOfTimeDuraion;
    }

    public TimeUnit recallUnitOfTimeDuration() {
        System.out.println("# TL # recallUnitOfTimeDuration()");
        return unitOfTimeDuration;
    }

    public String recallTimeIntervalT1Indiv() {
        System.out.println("# TL # recallTimeIntervalT1Indiv()");
        return timeLogicT1Indiv;
    }

    public String recallTimeIntervalT2Indiv() {
        System.out.println("# TL # recallTimeIntervalT2Indiv()");
        return timeLogicT2Indiv;
    }

    public String recallTimeIntervalIndiv() {
        System.out.println("# TL # recallIndivHoldingBigTimeIntervals()");

        return timeLogicInterval;
    }

    public String recallIndivHoldingBigTimeIntervals() {
        System.out.println("# TL # recallIndivHoldingBigTimeIntervals()");

        return timeLogicBiggerTimeIntervalIndiv;
    }

    public OWLReferences getTimeOntoRef() {
        System.out.println("# TL # getTimeOntoRef()");
        return ontoRef;}

//    public Boolean timeIntervalInBiggerTimeInterval(String individualName, String objPropName) {
//        System.out.println("# TL # timeIntervalInBiggerTimeInterval");
//        boolean flag = false;
//        if (!Objects.equals(individualName,null)&!Objects.equals(objPropName,null)) {
//            timeLogicBiggerTimeIntervalIndiv = individualName;
//            objPropForIntervalCheck = objPropName;
//            flag = true;
//        }
//        return flag;
//    }
}
