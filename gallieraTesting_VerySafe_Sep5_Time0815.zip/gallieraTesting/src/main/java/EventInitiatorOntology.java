import java.util.List;

public interface EventInitiatorOntology {

    void hasEventListener(TaskOntology eventListener);
    void inferAndTriggerEvents(List<TaskOntology> listOfeventListeners);
    boolean checkEventActivationConditionInference(TaskOntology objectOfTO);
}
