public interface MySqlDBOutputLink {

    void setMySqlDBOutputInfo(String Activity_database_Name, String Activity_mysql_UserName, String Activity_mysql_Password);
    void setOutputLinkFromOntoToDB(String individualName, String objPropName);
    void startOutputFromOntoToDB(String indivForInfer, String objPropForInfer);
}
