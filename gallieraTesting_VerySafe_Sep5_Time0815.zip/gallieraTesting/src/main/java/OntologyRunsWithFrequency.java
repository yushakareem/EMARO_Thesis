import java.util.concurrent.TimeUnit;

public interface OntologyRunsWithFrequency {

    void startScheduledOntology(Runnable RunnableOntologyObject, long initialDelay, long period, TimeUnit unit, int corePoolSize);
}
