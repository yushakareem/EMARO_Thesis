import java.sql.SQLException;
import java.util.List;

public interface MySqlDBInputLink {

    void setMySqlDBInputInfo(String DataBase_Name, String MySQL_UserName, String MySQL_Password);
    void setInputLinkFromDBtoOnto(String Sensor_IndividualName_InOntology, String Sensor_ItemName_InDataBase);

    void startInputFromDBtoOnto(List<String> listOfSensorItemsInDB);
}
