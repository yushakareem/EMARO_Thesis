import java.util.Map;

public interface OntoRecievesIndividualsFromOnto {

    void setInputLinkFromOntoToOnto(String sensorIndividual,OntologyPrototype ontologyObject);
    void startInputFromOntoToOnto(Map<String, OntologyPrototype> ontoToOntoInputMap);
}
