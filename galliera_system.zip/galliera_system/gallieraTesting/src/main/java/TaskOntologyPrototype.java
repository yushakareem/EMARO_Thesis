import java.util.EventListener;

public interface TaskOntologyPrototype extends OntologyPrototype,MySqlDBOutputLink,EventListenerOntology,OntoRecievesIndividualsFromOnto {
}
