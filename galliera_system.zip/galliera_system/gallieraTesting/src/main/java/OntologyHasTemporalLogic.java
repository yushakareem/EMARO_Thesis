import it.emarolab.amor.owlInterface.OWLReferences;

import java.util.concurrent.TimeUnit;

public interface OntologyHasTemporalLogic {

    Boolean checkInTheDuration(boolean inference, String comparativeOperator, Integer periodOfTimeDuration, TimeUnit unit);

    TemporalLogic isInTimeInterval(String interval_is_in_kitchen, String individualNameWithT1, String individualNameWithT2);

    boolean inferenceOf(String desiredIndivName, String desiredObjPropName, String desiredDataPropName);

    String recallIndiv();
    String recallObjProp();
    String recallTimeIntervalT1Indiv();
    String recallTimeIntervalT2Indiv();

    OWLReferences getTimeOntoRef();

}
