import it.emarolab.amor.owlInterface.OWLReferences;
import it.emarolab.owloop.aMORDescriptor.utility.individual.MORFullIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface OntologyPrototype extends OntologyHasMemory,Runnable {

    void setSensorIndivTimeStamp(String sensorIndividual, String timestamp);
    void setIndividualWithTimestamp(MORFullIndividual individual, String timeStamp);
    void setSensorIndivBoolValue(String sensorIndividual, String dataPropName, boolean boolDataValue);
    void setIndividualWithDataPropBool(MORFullIndividual individual, String dataPropName, boolean boolDataValue);

    void synchronizeAndSaveOnto();

    void updateBasedOnCurrentSensoryState(List<String> sensorItemsInDBList);
    void updateBasedOnCurrentSensoryState(Map<String,OntologyPrototype> ontoToOntoInputMap);

    MORFullIndividual getIndividual(String individualName, OWLReferences ontoRef);

    boolean getSensorIndivBoolValue(String sensorIndividual, String dataPropName);
    String getDataPropInference(MORFullIndividual individual, String dataPropName);

    String getSensorIndivTimeStamp(String sensorIndividual);
    String getObjPropInference(MORFullIndividual individual, String objectPropertyName);
    String getIndividualTimestamp(MORFullIndividual individual);

    Set<OWLNamedIndividual> getObjPropInferences(MORFullIndividual individual, String objectPropertyName);

    OWLReferences getOntoRef();
}
